<?php

// ---------------------------
// БАЗОВАЯ ДИАГНОСТИКА
// ---------------------------
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

$logDir = __DIR__ . '/logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0775, true);
}

ini_set('error_log', $logDir . '/php_error.log');

// Ловим фатальные ошибки
register_shutdown_function(function () use ($logDir) {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_COMPILE_ERROR, E_CORE_ERROR], true)) {
        $msg = date('c') . " FATAL: {$e['message']} in {$e['file']}:{$e['line']}\n";
        @file_put_contents($logDir . '/php_fatal.log', $msg, FILE_APPEND);
    }
});

// ---------------------------
// GET — проверка доступности
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    file_put_contents($logDir . '/webhook_ping.log', date('c') . " GET ping\n", FILE_APPEND);
    header('Content-Type: text/plain; charset=utf-8');
    echo "OK\n";
    exit;
}

// ---------------------------
// POST — входящие обновления Telegram
// ---------------------------
$raw = file_get_contents('php://input');
file_put_contents($logDir . '/webhook_raw.log', date('c') . "\n" . $raw . "\n\n", FILE_APPEND);

if (!$raw) {
    http_response_code(200);
    exit;
}

$update = json_decode($raw, true);
if (!$update) {
    file_put_contents($logDir . '/webhook_json_error.log', date('c') . " JSON ERROR\n", FILE_APPEND);
    http_response_code(200);
    exit;
}

// ---------------------------
// ПОДКЛЮЧАЕМ ОСНОВНОЙ БОТ
// ---------------------------

// Путь к твоему основному проекту (проверь, что папка реально называется farm-bot)
$projectRoot = __DIR__ . '/../farm-bot';

if (!is_dir($projectRoot)) {
    file_put_contents($logDir . '/path_error.log', date('c') . " PROJECT NOT FOUND: $projectRoot\n", FILE_APPEND);
    http_response_code(200);
    exit;
}

require $projectRoot . '/router.php';

// ---------------------------
// Передаём апдейт в бот
// ---------------------------

if (function_exists('handle_update')) {
    handle_update($update);
} elseif (function_exists('router_handle')) {
    router_handle($update);
} elseif (function_exists('route_update')) {
    route_update($update);
} else {
    // Если нет явной функции — просто передаём глобально
    if (isset($GLOBALS['router'])) {
        $GLOBALS['router']->handle($update);
    }
}

http_response_code(200);
exit;