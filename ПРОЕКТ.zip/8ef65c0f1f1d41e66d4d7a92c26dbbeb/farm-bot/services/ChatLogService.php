<?php

class ChatLogService
{
    public function __construct(private PDO $pdo) {}

    public function logMessage(array $msg): void
    {
        $chatId = (int)($msg['chat']['id'] ?? 0);
        $msgId  = (int)($msg['message_id'] ?? 0);
        $userId = (int)($msg['from']['id'] ?? 0);
        if ($chatId === 0 || $msgId === 0) return;

        $username = $msg['from']['username'] ?? ($msg['from']['first_name'] ?? null);
        $senderTag = (string)($msg['sender_tag'] ?? '');
        $msgType = 'other';
        $text = null;
        $caption = null;
        $fileId = null;

        if (!empty($msg['text'])) {
            $msgType = 'text';
            $text = (string)$msg['text'];
        } elseif (!empty($msg['voice']['file_id'])) {
            $msgType = 'voice';
            $fileId = (string)$msg['voice']['file_id'];
        } elseif (!empty($msg['photo']) && is_array($msg['photo'])) {
            $msgType = 'photo';
            $sizes = $msg['photo'];
            $best = end($sizes);
            if (is_array($best) && !empty($best['file_id'])) {
                $fileId = (string)$best['file_id'];
            }
            $caption = (string)($msg['caption'] ?? '');
        } elseif (!empty($msg['document']['file_id'])) {
            $msgType = 'document';
            $fileId = (string)$msg['document']['file_id'];
            $caption = (string)($msg['caption'] ?? '');
        } elseif (!empty($msg['audio']['file_id'])) {
            $msgType = 'audio';
            $fileId = (string)$msg['audio']['file_id'];
            $caption = (string)($msg['caption'] ?? '');
        } elseif (!empty($msg['video_note']['file_id'])) {
            $msgType = 'video_note';
            $fileId = (string)$msg['video_note']['file_id'];
        }

        $st = $this->pdo->prepare("
            INSERT INTO chat_messages(chat_id,message_id,user_id,username,sender_tag,msg_type,text,caption,file_id,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,NOW())
            ON DUPLICATE KEY UPDATE
                username=VALUES(username),
                sender_tag=VALUES(sender_tag),
                msg_type=VALUES(msg_type),
                text=VALUES(text),
                caption=VALUES(caption),
                file_id=VALUES(file_id)
        ");
        $st->execute([
            $chatId,
            $msgId,
            $userId,
            $username,
            $senderTag !== '' ? $senderTag : null,
            $msgType,
            $text,
            $caption,
            $fileId,
        ]);
    }

    public function saveTranscript(int $chatId, int $messageId, string $transcript): void
    {
        $st = $this->pdo->prepare("UPDATE chat_messages SET transcript=? WHERE chat_id=? AND message_id=?");
        $st->execute([$transcript, $chatId, $messageId]);
    }

    public function getRecentContext(int $chatId, int $limit = 60): array
    {
        $limit = max(30, min(200, $limit));
        $st = $this->pdo->prepare("
            SELECT created_at, username, sender_tag, msg_type, text, caption, transcript
            FROM chat_messages
            WHERE chat_id=?
            ORDER BY id DESC
            LIMIT {$limit}
        ");
        $st->execute([$chatId]);
        $rows = array_reverse($st->fetchAll());
        return $rows ?: [];
    }

    public function findLastMediaMessage(int $chatId, int $userId, array $types, int $secondsBack = 600): ?array
    {
        $typesIn = implode(',', array_fill(0, count($types), '?'));
        $params = [$chatId, $userId];
        foreach ($types as $t) $params[] = $t;
        $params[] = $secondsBack;

        $st = $this->pdo->prepare("
            SELECT * FROM chat_messages
            WHERE chat_id=? AND user_id=? AND msg_type IN ({$typesIn})
              AND created_at >= (NOW() - INTERVAL ? SECOND)
            ORDER BY id DESC
            LIMIT 1
        ");
        $st->execute($params);
        $row = $st->fetch();
        return $row ?: null;
    }

    public function getSummary(int $chatId): ?string
    {
        $st = $this->pdo->prepare("SELECT summary FROM chat_summaries WHERE chat_id=?");
        $st->execute([$chatId]);
        $s = $st->fetchColumn();
        return $s ? (string)$s : null;
    }

    public function setSummary(int $chatId, string $summary): void
    {
        $st = $this->pdo->prepare("
            INSERT INTO chat_summaries(chat_id,summary,updated_at)
            VALUES (?,?,NOW())
            ON DUPLICATE KEY UPDATE summary=VALUES(summary), updated_at=NOW()
        ");
        $st->execute([$chatId, $summary]);
    }
}
