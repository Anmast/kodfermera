<?php

class Parser
{
    private static function normalizeButtonText(string $text): string
    {
        $text = trim($text);
        $text = preg_replace('/[\x{FE0E}\x{FE0F}]/u', '', $text);
        $text = preg_replace('/[\x{1F000}-\x{1FAFF}\x{2600}-\x{27BF}]/u', ' ', $text);
        $text = preg_replace('/\s+/u', ' ', $text);
        return trim(mb_strtolower($text));
    }

    public static function parseText(string $text): array
    {
        $text = trim($text);
        $text = preg_replace('/\s+/u', ' ', $text);
        $lower = mb_strtolower($text);
        $btn = self::normalizeButtonText($text);

        if ($btn === 'крс') {
            return ['type' => 'sys', 'cmd' => 'krs_menu'];
        }
        if ($btn === 'найти') {
            return ['type' => 'sys', 'cmd' => 'krs_find'];
        }
        if ($btn === 'внести данные') {
            return ['type' => 'sys', 'cmd' => 'krs_data'];
        }
        if ($btn === 'ии') {
            return ['type' => 'sys', 'cmd' => 'ai_help'];
        }
        if ($btn === 'расходы') {
            return ['type' => 'sys', 'cmd' => 'finance_menu'];
        }
        if ($btn === 'зарплата') {
            return ['type' => 'sys', 'cmd' => 'payroll_menu'];
        }
        if ($btn === 'панель') {
            return ['type' => 'sys', 'cmd' => 'panel'];
        }
        if ($btn === 'скрыть клавиатуру') {
            return ['type' => 'sys', 'cmd' => 'hide_keyboard'];
        }

        // ===== SYS команды (учитываем /cmd@BotName) =====
        if (preg_match('/^\/id(@\w+)?$/ui', $text)) {
            return ['type' => 'sys', 'cmd' => 'id'];
        }

        if (preg_match('/^\/menu(@\w+)?$/ui', $text) || $lower === 'меню' || $lower === 'menu') {
            return ['type' => 'sys', 'cmd' => 'menu'];
        }
        if (preg_match('/^\/resetmenu(@\w+)?$/ui', $text)) {
            return ['type' => 'sys', 'cmd' => 'resetmenu'];
        }

        if (preg_match('/^\/panel(@\w+)?$/ui', $text) || $lower === 'панель' || $lower === 'panel') {
            return ['type' => 'sys', 'cmd' => 'panel'];
        }

        if (preg_match('/^\/cancel(@\w+)?$/ui', $text) || $lower === 'отмена' || $lower === 'cancel') {
            return ['type' => 'sys', 'cmd' => 'cancel'];
        }

        if (preg_match('/^\/start(@\w+)?(?:\s+(.+))?$/ui', $text, $m)) {
            $payload = trim((string)($m[2] ?? ''));
            return ['type' => 'sys', 'cmd' => 'start', 'payload' => $payload];
        }

        // Member tags (Bot API 9.5): reply-based or args-based
        // Usage examples:
        //   reply to user message: /tag Вет
        //   /tag 123456789 Вет
        //   /tagclear (reply)
        if (preg_match('/^\/(tag|tagclear)(@\w+)?(?:\s+(.+))?$/ui', $text, $m)) {
            $cmd = mb_strtolower((string)$m[1]);
            $payload = trim((string)($m[3] ?? ''));
            return ['type' => 'sys', 'cmd' => $cmd, 'payload' => $payload];
        }

        if ($lower === 'ping') {
            return ['type' => 'sys', 'cmd' => 'ping'];
        }

        // ===== Быстрые текстовые команды (на всякий) =====

        // статус 249
        if (preg_match('/^статус\s+(\d+)$/ui', $text, $m)) {
            return ['type' => 'query', 'cmd' => 'status', 'calf' => (int)$m[1]];
        }

        // #темп 249 39.8  (или темп 249 39,8)
        if (preg_match('/^#?темп\s+(\d+)\s+([0-9]+(?:[.,][0-9]+)?)$/ui', $text, $m)) {
            return [
                'type' => 'temp',
                'calf' => (int)$m[1],
                'value' => (float)str_replace(',', '.', $m[2]),
            ];
        }

        // #укол 249 азитронит 3мл
        if (preg_match('/^#?укол\s+(\d+)\s+(.+)$/ui', $text, $m)) {
            return [
                'type' => 'treatment',
                'calf' => (int)$m[1],
                'value' => trim($m[2]),
            ];
        }

        // #заметка 249 плохо ест
        if (preg_match('/^#?заметка\s+(\d+)\s+(.+)$/ui', $text, $m)) {
            return [
                'type' => 'note',
                'calf' => (int)$m[1],
                'value' => trim($m[2]),
            ];
        }

        // ===== Свободный текст =====
        return ['type' => 'free', 'value' => $text];
    }
}
