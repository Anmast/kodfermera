<?php

class StateService
{
    public function __construct(private PDO $pdo) {}

    public function set(int $chatId, int $userId, string $action, int $step, ?int $calf = null, ?array $payload = null): void {
        $st = $this->pdo->prepare("
      INSERT INTO user_states (chat_id, user_id, action, step, calf_number, payload)
      VALUES (?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        action=VALUES(action),
        step=VALUES(step),
        calf_number=VALUES(calf_number),
        payload=VALUES(payload),
        updated_at=CURRENT_TIMESTAMP
    ");
        $st->execute([$chatId, $userId, $action, $step, $calf, $payload ? json_encode($payload, JSON_UNESCAPED_UNICODE) : null]);
    }

    public function get(int $chatId, int $userId): ?array {
        $st = $this->pdo->prepare("SELECT * FROM user_states WHERE chat_id=? AND user_id=? LIMIT 1");
        $st->execute([$chatId, $userId]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) return null;

        $row['payload'] = $row['payload'] ? json_decode($row['payload'], true) : null;
        return $row;
    }

    public function clear(int $chatId, int $userId): void {
        $st = $this->pdo->prepare("DELETE FROM user_states WHERE chat_id=? AND user_id=?");
        $st->execute([$chatId, $userId]);
    }
}
