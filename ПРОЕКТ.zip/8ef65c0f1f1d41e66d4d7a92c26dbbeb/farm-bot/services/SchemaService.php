<?php

class SchemaService
{
    public function __construct(private PDO $pdo) {}

    public function ensure(): void
    {
        // ===== Core tables (KRS) =====
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS calves (
                number INT NOT NULL PRIMARY KEY,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS events (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                calf_number INT NULL,
                type VARCHAR(32) NOT NULL,
                value VARCHAR(255) NOT NULL,
                source_chat_id BIGINT NULL,
                source_user VARCHAR(191) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_calf_time (calf_number, created_at),
                KEY idx_type_time (type, created_at),
                KEY idx_qr (type, value)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        // user_states for step-by-step flows
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS user_states (
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                action VARCHAR(32) NOT NULL,
                step INT NOT NULL DEFAULT 0,
                calf_number INT NULL,
                payload MEDIUMTEXT NULL,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (chat_id, user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        // reminders for cron job
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS reminders (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                calf_number INT NULL,
                due_at DATETIME NOT NULL,
                text VARCHAR(255) NOT NULL,
                sent TINYINT(1) NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_rem_due (sent, due_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        // small key-value storage (UI state, pinned panel ids, keyboard timestamps)
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS bot_kv (
                k VARCHAR(64) NOT NULL PRIMARY KEY,
                v TEXT NULL,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        // AI pending DB mutations (confirmation step)
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS ai_mutations (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                request_text MEDIUMTEXT NULL,
                plan_json MEDIUMTEXT NOT NULL,
                status VARCHAR(16) NOT NULL DEFAULT 'pending',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                applied_at DATETIME NULL,
                error MEDIUMTEXT NULL,
                KEY idx_mut (chat_id, user_id, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        // If old schema used ENUM for events.type, try to soften it to VARCHAR(32)
        $this->softenEventsTypeEnum();

        // Chat messages for /ask context and media lookup
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS chat_messages (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                chat_id BIGINT NOT NULL,
                message_id INT NOT NULL,
                user_id BIGINT NOT NULL,
                username VARCHAR(191) NULL,
                sender_tag VARCHAR(64) NULL,
                msg_type VARCHAR(16) NOT NULL,
                text MEDIUMTEXT NULL,
                caption MEDIUMTEXT NULL,
                file_id VARCHAR(255) NULL,
                transcript MEDIUMTEXT NULL,
                created_at DATETIME NOT NULL,
                KEY idx_chat_time (chat_id, created_at),
                UNIQUE KEY uq_chat_msg (chat_id, message_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS chat_summaries (
                chat_id BIGINT NOT NULL PRIMARY KEY,
                summary MEDIUMTEXT NOT NULL,
                updated_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS ai_pending (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                source_message_id INT NOT NULL,
                kind VARCHAR(16) NOT NULL,
                transcript MEDIUMTEXT NULL,
                file_id VARCHAR(255) NULL,
                created_at DATETIME NOT NULL,
                KEY idx_pending (chat_id, user_id, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        // Finance (expenses) — used by the bot UI and public dashboard
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS finance_categories (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(191) NOT NULL,
                type ENUM('expense','income') NOT NULL DEFAULT 'expense',
                is_system TINYINT(1) NOT NULL DEFAULT 0,
                UNIQUE KEY uq_fin_cat (type, name)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS finance_transactions (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                tx_date DATETIME NOT NULL,
                type ENUM('expense','income') NOT NULL DEFAULT 'expense',
                category_id INT UNSIGNED NULL,
                amount DECIMAL(12,2) NOT NULL,
                comment VARCHAR(255) NULL,
                employee_id INT UNSIGNED NULL,
                calf_number INT NULL,
                source_type VARCHAR(32) NULL,
                source_id BIGINT UNSIGNED NULL,
                created_by BIGINT NOT NULL,
                KEY idx_fin_date (tx_date),
                KEY idx_fin_type (type),
                KEY idx_fin_cat (category_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        // Payroll (optional). If you already have these tables, CREATE IF NOT EXISTS is safe.
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS employees (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(191) NOT NULL,
                phone VARCHAR(64) NULL,
                note VARCHAR(255) NULL,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS payroll_accruals (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                employee_id INT UNSIGNED NOT NULL,
                work_date DATE NOT NULL,
                amount DECIMAL(12,2) NOT NULL,
                comment VARCHAR(255) NULL,
                created_by BIGINT NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_pay_acc_emp (employee_id, work_date)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS payroll_payouts (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                employee_id INT UNSIGNED NOT NULL,
                payout_date DATE NOT NULL,
                amount DECIMAL(12,2) NOT NULL,
                comment VARCHAR(255) NULL,
                created_by BIGINT NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_pay_out_emp (employee_id, payout_date)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
    }

    private function softenEventsTypeEnum(): void
    {
        try {
            $st = $this->pdo->prepare("SELECT data_type, column_type FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name='events' AND column_name='type' LIMIT 1");
            $st->execute();
            $row = $st->fetch(PDO::FETCH_ASSOC);
            if (!$row) return;
            $dt = (string)($row['data_type'] ?? '');
            if (function_exists('mb_strtolower')) $dt = mb_strtolower($dt);
            else $dt = strtolower($dt);
            if ($dt !== 'enum') return;
            // Try to alter, ignore failures (shared hosting permissions)
            $this->pdo->exec("ALTER TABLE events MODIFY type VARCHAR(32) NOT NULL");
        } catch (Throwable $e) {
            // ignore
        }
    }
}
