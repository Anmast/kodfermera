<?php

class AiService
{
    public function __construct(private array $config) {}

    private function apiKey(): string {
        return (string)($this->config['openai']['api_key'] ?? '');
    }

    private function requestJson(string $url, array $payload): array
    {
        $key = $this->apiKey();
        if ($key === '') return ['ok'=>false,'error'=>'NO_API_KEY'];

        $ch = curl_init($url);
        $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer {$key}",
                "Content-Type: application/json",
            ],
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 60,
        ]);
        $res = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($res === false) return ['ok'=>false,'error'=>"CURL:{$err}"];
        $data = json_decode($res, true);
        if (!is_array($data)) return ['ok'=>false,'error'=>"HTTP{$http}:BAD_JSON", 'raw'=>$res];

        if ($http < 200 || $http >= 300) {
            $msg = $data['error']['message'] ?? ($data['message'] ?? 'HTTP_ERROR');
            return ['ok'=>false,'error'=>"HTTP{$http}:{$msg}", 'data'=>$data];
        }
        return ['ok'=>true,'data'=>$data];
    }

    public function answerText(string $system, string $user, ?array $imageDataUrl = null): array
    {
        $model = (string)($this->config['openai']['model'] ?? 'gpt-4o-mini');
        $input = [
            [
                'role' => 'system',
                'content' => $system,
            ],
        ];

        $userContent = [];
        $userContent[] = ['type'=>'input_text', 'text'=>$user];
        if ($imageDataUrl) {
            $userContent[] = ['type'=>'input_image', 'image_url'=>$imageDataUrl['image_url'], 'detail'=>'auto'];
        }
        $input[] = [
            'role' => 'user',
            'content' => $userContent,
        ];

        $payload = [
            'model' => $model,
            'input' => $input,
        ];

        $r = $this->requestJson('https://api.openai.com/v1/responses', $payload);
        if (!$r['ok']) return $r;

        $data = $r['data'];
        $text = '';
        // Responses API: output is array of content blocks.
        if (!empty($data['output']) && is_array($data['output'])) {
            foreach ($data['output'] as $out) {
                if (!empty($out['content']) && is_array($out['content'])) {
                    foreach ($out['content'] as $c) {
                        if (($c['type'] ?? '') === 'output_text') {
                            $text .= (string)($c['text'] ?? '');
                        }
                    }
                }
            }
        }
        return ['ok'=>true,'text'=>trim($text)];
    }

    public function transcribe(string $filePath, string $prompt = ''): array
    {
        $key = $this->apiKey();
        if ($key === '') return ['ok'=>false,'error'=>'NO_API_KEY'];

        $model = (string)($this->config['openai']['stt_model'] ?? 'gpt-4o-mini-transcribe');

        $ch = curl_init('https://api.openai.com/v1/audio/transcriptions');
        $post = [
            'model' => $model,
            'file' => new CURLFile($filePath),
        ];
        if ($prompt !== '') $post['prompt'] = $prompt;

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer {$key}",
            ],
            CURLOPT_POSTFIELDS => $post,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 120,
        ]);
        $res = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($res === false) return ['ok'=>false,'error'=>"CURL:{$err}"];
        $data = json_decode($res, true);
        if (!is_array($data)) return ['ok'=>false,'error'=>"HTTP{$http}:BAD_JSON", 'raw'=>$res];

        if ($http < 200 || $http >= 300) {
            $msg = $data['error']['message'] ?? 'HTTP_ERROR';
            return ['ok'=>false,'error'=>"HTTP{$http}:{$msg}", 'data'=>$data];
        }
        $text = (string)($data['text'] ?? '');
        return ['ok'=>true,'text'=>trim($text)];
    }

    public function dataUrlFromImage(string $filePath): array
    {
        $bin = file_get_contents($filePath);
        $b64 = base64_encode($bin === false ? '' : $bin);
        $mime = 'image/jpeg';
        $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        if ($ext === 'png') $mime = 'image/png';
        elseif ($ext === 'webp') $mime = 'image/webp';
        elseif ($ext === 'gif') $mime = 'image/gif';
        return ['image_url'=>"data:{$mime};base64,{$b64}"];
    }
}
