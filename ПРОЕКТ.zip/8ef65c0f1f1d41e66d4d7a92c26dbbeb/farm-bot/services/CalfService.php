<?php

class CalfService
{
    public function __construct(private PDO $pdo) {}

    // Supported birth types for backward compatibility (old ENUM versions)
    private array $birthTypes = ['birth','dob','born'];

    public function existsCalf(int $number): bool {
        $st = $this->pdo->prepare("SELECT 1 FROM calves WHERE number=? LIMIT 1");
        $st->execute([$number]);
        return (bool)$st->fetchColumn();
    }

    public function ensureCalf(int $number): void {
        $st = $this->pdo->prepare("INSERT IGNORE INTO calves(number) VALUES (?)");
        $st->execute([$number]);
    }

    /**
     * QR code is stored as latest event type 'qr'.
     */
    public function getQrCode(int $calf): ?string {
        return $this->lastValueByType($calf, 'qr');
    }

    public function setQrCode(int $calf, string $code, int $chatId, ?string $user): void {
        $code = trim($code);
        if ($code === '') return;
        $this->ensureCalf($calf);
        $this->addEvent($calf, 'qr', $code, $chatId, $user);
    }

    public function findCalfByQr(string $code): ?int {
        $code = trim($code);
        if ($code === '') return null;
        $st = $this->pdo->prepare(
            "SELECT calf_number FROM events WHERE type='qr' AND value=? ORDER BY created_at DESC LIMIT 1"
        );
        $st->execute([$code]);
        $n = $st->fetchColumn();
        return $n !== false ? (int)$n : null;
    }

    public function addEvent(?int $calf, string $type, string $value, int $chatId, ?string $user): void {
        $st = $this->pdo->prepare(
            "INSERT INTO events(calf_number,type,value,source_chat_id,source_user) VALUES (?,?,?,?,?)"
        );
        $st->execute([$calf, $type, $value, $chatId, $user]);
    }

    /**
     * Date of birth is stored as latest event with type birth|dob|born.
     * Returns raw DB value (YYYY-MM-DD or any string) or null.
     */
    public function getBirthDate(int $calf): ?string {
        $in = "'" . implode("','", $this->birthTypes) . "'";
        $st = $this->pdo->prepare(
            "SELECT value FROM events WHERE calf_number=? AND type IN ({$in}) ORDER BY created_at DESC LIMIT 1"
        );
        $st->execute([$calf]);
        $v = $st->fetchColumn();
        return $v !== false ? (string)$v : null;
    }

    /**
     * Writes birth date into a compatible type (birth/dob/born).
     * If events.type is still ENUM without those values, picks the first allowed.
     */
    public function setBirthDate(int $calf, string $date, int $chatId, ?string $user): void {
        $date = trim($date);
        if ($date === '') return;
        $type = $this->detectBirthWriteType();
        if ($type === '') {
            // Fallback: store as note to avoid losing info
            $this->ensureCalf($calf);
            $this->addEvent($calf, 'note', 'birth:' . $date, $chatId, $user);
            return;
        }
        $this->ensureCalf($calf);
        $this->addEvent($calf, $type, $date, $chatId, $user);
    }

    private function detectBirthWriteType(): string {
        // If column is VARCHAR (recommended), we can safely use 'birth'
        try {
            $st = $this->pdo->prepare("SELECT data_type, column_type FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='events' AND column_name='type' LIMIT 1");
            $st->execute();
            $row = $st->fetch(PDO::FETCH_ASSOC);
            if (!$row) return 'birth';
            $dt = (string)($row['data_type'] ?? '');
            $dt = function_exists('mb_strtolower') ? mb_strtolower($dt) : strtolower($dt);
            if ($dt !== 'enum') return 'birth';

            $ct = (string)($row['column_type'] ?? '');
            // Parse enum('a','b',...)
            $allowed = [];
            if (preg_match_all("/'([^']+)'/", $ct, $m)) {
                $allowed = $m[1] ?? [];
            }
            foreach ($this->birthTypes as $t) {
                if (in_array($t, $allowed, true)) return $t;
            }
            // If none allowed, return empty -> will fallback to note
            return '';
        } catch (Throwable $e) {
            return 'birth';
        }
    }

    public function lastTemp(int $calf): ?float {
        $st = $this->pdo->prepare(
            "SELECT value FROM events WHERE calf_number=? AND type='temp' ORDER BY created_at DESC LIMIT 1"
        );
        $st->execute([$calf]);
        $v = $st->fetchColumn();
        return $v !== false ? (float)$v : null;
    }

    public function lastEvents(int $calf, int $limit = 8): array {
        $limit = max(1, min(30, (int)$limit));
        $st = $this->pdo->prepare(
            "SELECT id,type,value,created_at,source_user FROM events WHERE calf_number=? ORDER BY created_at DESC LIMIT {$limit}"
        );
        $st->execute([$calf]);
        return $st->fetchAll();
    }

    // Backward-compat alias (some parts of the code used this name)
    public function lastTwoWeight(int $calf): array {
        return $this->lastTwoWeights($calf);
    }

    public function listEvents(int $calf, int $limit = 10, int $offset = 0, ?string $type = null): array {
        $limit = max(1, min(30, (int)$limit));
        $offset = max(0, (int)$offset);
        if ($type !== null && $type !== '') {
            // Special filter: birth shows all compatible types
            if ($type === 'birth') {
                $in = "'" . implode("','", $this->birthTypes) . "'";
                $st = $this->pdo->prepare(
                    "SELECT id,type,value,created_at,source_user FROM events WHERE calf_number=? AND type IN ({$in}) ORDER BY created_at DESC LIMIT {$limit} OFFSET {$offset}"
                );
                $st->execute([$calf]);
            } else {
                $st = $this->pdo->prepare(
                    "SELECT id,type,value,created_at,source_user FROM events WHERE calf_number=? AND type=? ORDER BY created_at DESC LIMIT {$limit} OFFSET {$offset}"
                );
                $st->execute([$calf, $type]);
            }
        } else {
            $st = $this->pdo->prepare(
                "SELECT id,type,value,created_at,source_user FROM events WHERE calf_number=? ORDER BY created_at DESC LIMIT {$limit} OFFSET {$offset}"
            );
            $st->execute([$calf]);
        }
        return $st->fetchAll();
    }

    public function tempStats24h(int $calf): array {
        $st = $this->pdo->prepare(
            "SELECT COUNT(*) AS cnt, AVG(CAST(value AS DECIMAL(10,3))) AS avg_v, MIN(CAST(value AS DECIMAL(10,3))) AS min_v, MAX(CAST(value AS DECIMAL(10,3))) AS max_v
             FROM events
             WHERE calf_number=? AND type='temp' AND created_at >= (NOW() - INTERVAL 24 HOUR)"
        );
        $st->execute([$calf]);
        $row = $st->fetch(PDO::FETCH_ASSOC) ?: [];
        return [
            'count' => (int)($row['cnt'] ?? 0),
            'avg' => isset($row['avg_v']) ? (float)$row['avg_v'] : null,
            'min' => isset($row['min_v']) ? (float)$row['min_v'] : null,
            'max' => isset($row['max_v']) ? (float)$row['max_v'] : null,
        ];
    }

    public function lastTwoWeights(int $calf): array {
        $st = $this->pdo->prepare(
            "SELECT value, created_at FROM events WHERE calf_number=? AND type='weight' ORDER BY created_at DESC LIMIT 2"
        );
        $st->execute([$calf]);
        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function getEvent(int $eventId): ?array {
        $st = $this->pdo->prepare("SELECT id, calf_number, type, value, created_at, source_user FROM events WHERE id=? LIMIT 1");
        $st->execute([$eventId]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function updateEventValue(int $eventId, string $value): bool {
        $st = $this->pdo->prepare("UPDATE events SET value=? WHERE id=?");
        $st->execute([$value, $eventId]);
        return $st->rowCount() > 0;
    }

    public function deleteEvent(int $eventId): bool {
        $st = $this->pdo->prepare("DELETE FROM events WHERE id=?");
        $st->execute([$eventId]);
        return $st->rowCount() > 0;
    }

    public function lastValueByType(int $calf, string $type): ?string {
        $st = $this->pdo->prepare(
            "SELECT value FROM events WHERE calf_number=? AND type=? ORDER BY created_at DESC LIMIT 1"
        );
        $st->execute([$calf, $type]);
        $v = $st->fetchColumn();
        return $v !== false ? (string)$v : null;
    }

    /**
     * Lifecycle status: active|sold|dead|removed
     */
    public function getLifeStatus(int $calf): string {
        $v = $this->lastValueByType($calf, 'life');
        $v = $v !== null ? trim(mb_strtolower($v)) : '';
        if (in_array($v, ['active','sold','dead','removed'], true)) return $v;
        return 'active';
    }

    public function setLifeStatus(int $calf, string $status, int $chatId, ?string $user): void {
        $status = trim(mb_strtolower($status));
        if (!in_array($status, ['active','sold','dead','removed'], true)) {
            $status = 'active';
        }
        $this->ensureCalf($calf);
        $this->addEvent($calf, 'life', $status, $chatId, $user);
    }

    /**
     * Returns list of calves with derived status (from last 'life' event).
     */
    public function listCalves(int $limit = 20, int $offset = 0, bool $showAll = false): array {
        $limit = max(1, min(50, (int)$limit));
        $offset = max(0, (int)$offset);

        $sql = "SELECT c.number,
                COALESCE((SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='life' ORDER BY e.created_at DESC LIMIT 1), 'active') AS status
                FROM calves c";

        if (!$showAll) {
            $sql .= " WHERE COALESCE((SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='life' ORDER BY e.created_at DESC LIMIT 1), 'active') NOT IN ('sold','dead','removed')";
        }
        // In Telegram UI we want natural order by number (ascending)
        $sql .= " ORDER BY c.number ASC LIMIT {$limit} OFFSET {$offset}";

        $st = $this->pdo->query($sql);
        return $st->fetchAll();
    }

    /**
     * Export list with latest lifecycle status and latest qr code.
     * Returns rows: number, status, qr
     */
    public function exportCalvesWithQr(bool $includeAll = true): array {
        $sql = "SELECT c.number,
                COALESCE((SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='life' ORDER BY e.created_at DESC LIMIT 1), 'active') AS status,
                (SELECT e2.value FROM events e2 WHERE e2.calf_number=c.number AND e2.type='qr' ORDER BY e2.created_at DESC LIMIT 1) AS qr
                FROM calves c";
        if (!$includeAll) {
            $sql .= " WHERE COALESCE((SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='life' ORDER BY e.created_at DESC LIMIT 1), 'active') NOT IN ('sold','dead','removed')";
        }
        $sql .= " ORDER BY c.number ASC";
        $st = $this->pdo->query($sql);
        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }
}
