<?php

class AlertService
{
    public function __construct(private array $config) {}

    public function checkTemp(int $calf, float $temp): ?string {
        if ($temp >= (float)$this->config['temp_crit']) {
            return "🚨 №{$calf} температура {$temp} — КРИТИЧНО.";
        }
        if ($temp >= (float)$this->config['temp_warn']) {
            return "⚠️ №{$calf} температура {$temp} — выше нормы.";
        }
        return null;
    }
}
