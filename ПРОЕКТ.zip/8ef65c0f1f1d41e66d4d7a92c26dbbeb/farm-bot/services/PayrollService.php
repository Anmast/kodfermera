<?php

class PayrollService
{
    public function __construct(private PDO $pdo) {}

    private function tableExists(string $table): bool {
        try {
            $st = $this->pdo->prepare("SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1");
            $st->execute([$table]);
            return (bool)$st->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    }

    public function isInstalled(): bool {
        return $this->tableExists('employees') && $this->tableExists('payroll_accruals') && $this->tableExists('payroll_payouts');
    }

    public function addEmployee(string $name, ?string $phone = null, ?string $note = null): ?int {
        $name = trim($name);
        if ($name === '') return null;
        $phone = $phone !== null ? trim($phone) : null;
        $note  = $note !== null ? trim($note) : null;
        $st = $this->pdo->prepare("INSERT INTO employees(name, phone, note, is_active) VALUES (?,?,?,1)");
        $st->execute([$name, $phone, $note]);
        return (int)$this->pdo->lastInsertId();
    }

    public function listEmployees(bool $activeOnly = true): array {
        if (!$this->tableExists('employees')) return [];
        $sql = "SELECT id, name, phone, note, is_active FROM employees";
        if ($activeOnly) $sql .= " WHERE is_active=1";
        $sql .= " ORDER BY name ASC";
        $st = $this->pdo->query($sql);
        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function getEmployee(int $id): ?array {
        if (!$this->tableExists('employees')) return null;
        $st = $this->pdo->prepare("SELECT id, name, phone, note, is_active FROM employees WHERE id=? LIMIT 1");
        $st->execute([$id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function addAccrual(int $employeeId, float $amount, string $comment, int $createdBy, ?string $workDate = null): int {
        $amount = round($amount, 2);
        if ($amount <= 0) return 0;
        $comment = trim($comment);
        $workDate = $workDate ?: date('Y-m-d');
        $st = $this->pdo->prepare("INSERT INTO payroll_accruals(employee_id, work_date, amount, comment, created_by) VALUES (?,?,?,?,?)");
        $st->execute([$employeeId, $workDate, $amount, $comment, $createdBy]);
        return (int)$this->pdo->lastInsertId();
    }

    public function addPayout(int $employeeId, float $amount, string $comment, int $createdBy, ?string $payoutDate = null): int {
        $amount = round($amount, 2);
        if ($amount <= 0) return 0;
        $comment = trim($comment);
        $payoutDate = $payoutDate ?: date('Y-m-d');
        $st = $this->pdo->prepare("INSERT INTO payroll_payouts(employee_id, payout_date, amount, comment, created_by) VALUES (?,?,?,?,?)");
        $st->execute([$employeeId, $payoutDate, $amount, $comment, $createdBy]);
        return (int)$this->pdo->lastInsertId();
    }

    public function getBalance(int $employeeId): float {
        if (!$this->isInstalled()) return 0.0;
        $st1 = $this->pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM payroll_accruals WHERE employee_id=?");
        $st1->execute([$employeeId]);
        $accr = (float)$st1->fetchColumn();

        $st2 = $this->pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM payroll_payouts WHERE employee_id=?");
        $st2->execute([$employeeId]);
        $pay = (float)$st2->fetchColumn();

        return round($accr - $pay, 2);
    }

    public function listDebts(): array {
        if (!$this->isInstalled()) return [];
        $sql = "
            SELECT e.id, e.name,
              (SELECT COALESCE(SUM(a.amount),0) FROM payroll_accruals a WHERE a.employee_id=e.id) AS accrued,
              (SELECT COALESCE(SUM(p.amount),0) FROM payroll_payouts p WHERE p.employee_id=e.id) AS paid
            FROM employees e
            WHERE e.is_active=1
            ORDER BY e.name ASC
        ";
        $st = $this->pdo->query($sql);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($rows as &$r) {
            $r['accrued'] = (float)($r['accrued'] ?? 0);
            $r['paid']    = (float)($r['paid'] ?? 0);
            $r['debt']    = round(((float)$r['accrued']) - ((float)$r['paid']), 2);
        }
        unset($r);
        return $rows;
    }
}
