<?php

class FinanceService
{
    public function __construct(private PDO $pdo) {}

    private function tableExists(string $table): bool {
        try {
            $st = $this->pdo->prepare("SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1");
            $st->execute([$table]);
            return (bool)$st->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    }

    public function isInstalled(): bool {
        return $this->tableExists('finance_transactions') && $this->tableExists('finance_categories');
    }

    /**
     * Creates base categories if tables exist.
     */
    public function ensureBaseCategories(): void {
        if (!$this->tableExists('finance_categories')) return;

        $base = [
            ['Корма', 'expense', 0],
            ['Ветпрепараты', 'expense', 0],
            ['ГСМ', 'expense', 0],
            ['Электричество', 'expense', 0],
            ['Ремонт/стройка', 'expense', 0],
            ['Инструмент/хозтовары', 'expense', 0],
            ['Транспорт', 'expense', 0],
            ['Зарплата', 'expense', 1],
            ['Прочее', 'expense', 0],
        ];

        $st = $this->pdo->prepare("INSERT IGNORE INTO finance_categories(name, type, is_system) VALUES (?,?,?)");
        foreach ($base as $row) {
            $st->execute([$row[0], $row[1], $row[2]]);
        }
    }

    public function listCategories(string $type = 'expense'): array {
        if (!$this->tableExists('finance_categories')) return [];
        $type = ($type === 'income') ? 'income' : 'expense';
        $st = $this->pdo->prepare("SELECT id, name, type, is_system FROM finance_categories WHERE type=? ORDER BY is_system DESC, name ASC");
        $st->execute([$type]);
        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function addCategory(string $name, string $type = 'expense'): ?int {
        $name = trim($name);
        if ($name === '') return null;
        $type = ($type === 'income') ? 'income' : 'expense';
        $st = $this->pdo->prepare("INSERT INTO finance_categories(name, type, is_system) VALUES (?,?,0)");
        $st->execute([$name, $type]);
        return (int)$this->pdo->lastInsertId();
    }

    public function ensureExpenseCategory(string $name): ?int {
        $name = trim($name);
        if ($name === '') return null;
        $this->ensureBaseCategories();
        $id = $this->getCategoryIdByName($name, 'expense');
        if ($id) return $id;
        return $this->addCategory($name, 'expense');
    }

    public function getCategoryIdByName(string $name, string $type = 'expense'): ?int {
        if (!$this->tableExists('finance_categories')) return null;
        $type = ($type === 'income') ? 'income' : 'expense';
        $st = $this->pdo->prepare("SELECT id FROM finance_categories WHERE type=? AND name=? LIMIT 1");
        $st->execute([$type, $name]);
        $id = $st->fetchColumn();
        return $id !== false ? (int)$id : null;
    }

    public function addExpense(
        int $categoryId,
        float $amount,
        string $comment,
        int $createdBy,
        ?int $employeeId = null,
        ?int $calfNumber = null,
        ?string $sourceType = null,
        ?int $sourceId = null
    ): int {
        $amount = round($amount, 2);
        if ($amount <= 0) return 0;
        $comment = trim($comment);
        $st = $this->pdo->prepare(
            "INSERT INTO finance_transactions(tx_date, type, category_id, amount, comment, employee_id, calf_number, source_type, source_id, created_by)
             VALUES (NOW(), 'expense', ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $st->execute([$categoryId, $amount, $comment, $employeeId, $calfNumber, $sourceType, $sourceId, $createdBy]);
        return (int)$this->pdo->lastInsertId();
    }

    public function listTransactions(string $type = 'expense', int $days = 7, int $limit = 20, int $offset = 0, ?int $categoryId = null): array {
        if (!$this->tableExists('finance_transactions')) return [];
        $type = ($type === 'income') ? 'income' : 'expense';
        $days = max(1, min(365, (int)$days));
        $limit = max(1, min(50, (int)$limit));
        $offset = max(0, (int)$offset);

        $args = [$type];
        $filterFinance = '';
        if ($categoryId) {
            $filterFinance = ' AND t.category_id=?';
            $args[] = $categoryId;
        }

        if ($type !== 'expense') {
            $sql = "SELECT t.id, t.tx_date, t.type, t.amount, t.comment, c.name AS category
                    FROM finance_transactions t
                    LEFT JOIN finance_categories c ON c.id = t.category_id
                    WHERE t.type=? AND t.tx_date >= (NOW() - INTERVAL {$days} DAY){$filterFinance}
                    ORDER BY t.tx_date DESC, t.id DESC LIMIT {$limit} OFFSET {$offset}";
            $st = $this->pdo->prepare($sql);
            $st->execute($args);
            return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
        }

        $salaryCatId = $this->ensureExpenseCategory('Зарплата');
        $union = '';
        if ($this->tableExists('payroll_payouts') && $this->tableExists('employees')) {
            $includeSalaryFallback = true;
            if ($categoryId && $salaryCatId && $categoryId !== $salaryCatId) {
                $includeSalaryFallback = false;
            }
            if ($includeSalaryFallback) {
                $union = "
                    UNION ALL
                    SELECT
                        CAST(CONCAT('payroll_', p.id) AS CHAR(32)) AS id,
                        COALESCE(p.created_at, CONCAT(p.payout_date,' 00:00:00')) AS tx_date,
                        'expense' AS type,
                        p.amount AS amount,
                        TRIM(CONCAT('Выплата зарплаты', CASE WHEN e.name IS NOT NULL AND e.name <> '' THEN CONCAT(': ', e.name) ELSE '' END, CASE WHEN p.comment IS NOT NULL AND p.comment <> '' THEN CONCAT(' — ', p.comment) ELSE '' END)) AS comment,
                        'Зарплата' AS category
                    FROM payroll_payouts p
                    LEFT JOIN employees e ON e.id = p.employee_id
                    WHERE COALESCE(p.created_at, CONCAT(p.payout_date,' 00:00:00')) >= (NOW() - INTERVAL {$days} DAY)
                      AND NOT EXISTS (
                          SELECT 1 FROM finance_transactions t2
                          WHERE t2.source_type='payroll_payout' AND t2.source_id=p.id
                      )
                ";
            }
        }

        $sql = "SELECT x.id, x.tx_date, x.type, x.amount, x.comment, x.category
                FROM (
                    SELECT CAST(t.id AS CHAR(32)) AS id, t.tx_date, t.type, t.amount, t.comment, COALESCE(c.name, 'Без категории') AS category
                    FROM finance_transactions t
                    LEFT JOIN finance_categories c ON c.id = t.category_id
                    WHERE t.type=? AND t.tx_date >= (NOW() - INTERVAL {$days} DAY){$filterFinance}
                    {$union}
                ) x
                ORDER BY x.tx_date DESC, x.id DESC
                LIMIT {$limit} OFFSET {$offset}";
        $st = $this->pdo->prepare($sql);
        $st->execute($args);
        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }
}

