<?php

/**
 * AiDbAgent: "Full DB access" for AI with controlled writes.
 *
 * Design:
 *  - AI never executes raw INSERT/UPDATE/DELETE SQL.
 *  - For reads, AI can propose SELECT queries (validated + limited).
 *  - For writes, AI must propose structured actions (whitelisted) which are applied
 *    only after user confirmation (inline buttons).
 */
class AiDbAgent
{
    private int $maxQueries = 5;
    private int $maxRowsPerQuery = 50;
    private int $maxLimit = 200;

    public function __construct(
        private PDO $pdo,
        private AiService $ai,
        private CalfService $calves,
        private ?FinanceService $finance,
        private array $config
    ) {}

    // -------- Public API --------

    /**
     * Returns:
     *  - ['mode'=>'answer','text'=>string]
     *  - ['mode'=>'confirm','text'=>string,'mutation_id'=>int]
     *  - ['mode'=>'error','error'=>string]
     */
    public function handleText(int $chatId, string $chatType, int $userId, ?string $userName, string $question, array $context = []): array
    {
        $question = trim($question);
        if ($question === '') return ['mode'=>'error','error'=>'EMPTY_QUESTION'];

        $quick = $this->quickAnswer($question, $context);
        if ($quick !== null) {
            return ['mode'=>'answer','text'=>$quick];
        }

        $schema = $this->describeSchema();
        $plan = $this->plan($question, $schema, $context);
        if (!$plan['ok']) return ['mode'=>'error','error'=>($plan['error'] ?? 'PLAN_ERROR')];

        $planObj = $plan['plan'];
        $actions = is_array($planObj['actions'] ?? null) ? $planObj['actions'] : [];
        $queries = is_array($planObj['queries'] ?? null) ? $planObj['queries'] : [];

        // If write actions exist -> require confirmation
        if ($actions) {
            if (!$this->canWrite($chatId, $chatType, $userId)) {
                return ['mode'=>'answer','text'=>'⛔️ Запись в базу доступна только администраторам (в группах) или в личке.'];
            }

            $mutId = $this->storeMutation($chatId, $userId, $question, $planObj);
            $preview = $this->renderPlanForUser($planObj);
            $txt = "🧠 Я понял задачу как изменение данных.\n\n".
                   "Вот что собираюсь записать (проверь):\n".
                   $preview.
                   "\n\nНажми ✅ *Подтвердить*, чтобы применить, или ✖️ *Отмена*.";
            return ['mode'=>'confirm','text'=>$txt,'mutation_id'=>$mutId];
        }

        // Read-only path: execute SELECTs and ask AI to answer based on results
        $results = [];
        $qCount = 0;
        foreach ($queries as $q) {
            if ($qCount >= $this->maxQueries) break;
            if (!is_array($q)) continue;
            $sql = (string)($q['sql'] ?? '');
            if (!$this->isSafeSelect($sql)) continue;
            $sql = $this->enforceLimit($sql);
            $res = $this->runSelect($sql);
            $results[] = [
                'purpose' => (string)($q['purpose'] ?? ''),
                'sql' => $sql,
                'rows' => $res,
            ];
            $qCount++;
        }

        $answer = $this->answerFromResults($question, $schema, $results, $context);
        if (!$answer['ok']) return ['mode'=>'error','error'=>($answer['error'] ?? 'ANSWER_ERROR')];
        return ['mode'=>'answer','text'=>(string)$answer['text']];
    }

    public function applyMutation(int $mutationId, int $chatId, int $userId): array
    {
        $st = $this->pdo->prepare("SELECT * FROM ai_mutations WHERE id=? AND chat_id=? AND user_id=? LIMIT 1");
        $st->execute([$mutationId, $chatId, $userId]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) return ['ok'=>false,'error'=>'NOT_FOUND'];
        if ((string)($row['status'] ?? '') !== 'pending') return ['ok'=>false,'error'=>'ALREADY_HANDLED'];

        $plan = json_decode((string)($row['plan_json'] ?? ''), true);
        if (!is_array($plan)) return ['ok'=>false,'error'=>'BAD_PLAN_JSON'];

        $actions = is_array($plan['actions'] ?? null) ? $plan['actions'] : [];
        if (!$actions) {
            $this->markMutation($mutationId, 'failed', 'NO_ACTIONS');
            return ['ok'=>false,'error'=>'NO_ACTIONS'];
        }

        $applied = [];
        $errors = [];

        foreach ($actions as $a) {
            if (!is_array($a)) continue;
            $action = (string)($a['action'] ?? '');
            $args = is_array($a['args'] ?? null) ? $a['args'] : [];
            try {
                $r = $this->applyOneAction($action, $args, $chatId, $userId);
                if ($r['ok']) {
                    $applied[] = $r['msg'];
                } else {
                    $errors[] = $r['error'];
                }
            } catch (Throwable $e) {
                $errors[] = $action . ': ' . $e->getMessage();
            }
        }

        if ($errors) {
            $this->markMutation($mutationId, 'failed', implode("\n", $errors));
            return ['ok'=>false,'error'=>implode("\n", $errors), 'applied'=>$applied];
        }

        $this->markMutation($mutationId, 'applied', null);
        return ['ok'=>true,'applied'=>$applied];
    }

    public function cancelMutation(int $mutationId, int $chatId, int $userId): bool
    {
        $st = $this->pdo->prepare("UPDATE ai_mutations SET status='canceled', applied_at=NOW() WHERE id=? AND chat_id=? AND user_id=? AND status='pending'");
        $st->execute([$mutationId, $chatId, $userId]);
        return $st->rowCount() > 0;
    }


    private function quickAnswer(string $question, array $context = []): ?string
    {
        $q = trim($question);
        if ($q === '') return null;
        $q = function_exists('mb_strtolower') ? mb_strtolower($q, 'UTF-8') : strtolower($q);

        $asksCount = (bool)preg_match('~(сколько|количеств|голов|крс|телят)~u', $q);
        $asksNumbers = (bool)preg_match('~(какие|перечисли|номера|список)~u', $q);
        $asksOldest = (bool)preg_match('~(сам(ый|ая)?\s+стар|кто\s+старш)~u', $q);
        $asksYoungest = (bool)preg_match('~(сам(ый|ая)?\s+млад|кто\s+младш)~u', $q);
        $asksHeaviest = (bool)preg_match('~(сам(ый|ая)?\s+тяж|кто\s+тяжел)~u', $q);

        if (!$asksCount && !$asksNumbers && !$asksOldest && !$asksYoungest && !$asksHeaviest) {
            return null;
        }

        $rows = $this->pdo->query("SELECT c.number,
                COALESCE((SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='life' ORDER BY e.created_at DESC, e.id DESC LIMIT 1), 'active') AS status,
                (SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type IN ('birth','dob','born') ORDER BY e.created_at DESC, e.id DESC LIMIT 1) AS birth,
                (SELECT CAST(e.value AS DECIMAL(10,3)) FROM events e WHERE e.calf_number=c.number AND e.type='weight' ORDER BY e.created_at DESC, e.id DESC LIMIT 1) AS last_weight,
                (SELECT e.created_at FROM events e WHERE e.calf_number=c.number ORDER BY e.created_at ASC, e.id ASC LIMIT 1) AS first_seen
            FROM calves c ORDER BY c.number ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];

        $items = [];
        foreach ($rows as $r) {
            $birthRaw = trim((string)($r['birth'] ?? ''));
            $birthTs = null;
            if ($birthRaw !== '') {
                $ts = strtotime($birthRaw);
                if ($ts !== false) $birthTs = $ts;
            }
            if ($birthTs === null && !empty($r['first_seen'])) {
                $ts = strtotime((string)$r['first_seen']);
                if ($ts !== false) $birthTs = $ts;
            }
            $items[] = [
                'number' => (int)$r['number'],
                'status' => (string)($r['status'] ?? 'active'),
                'birth_ts' => $birthTs,
                'birth' => $birthRaw,
                'last_weight' => isset($r['last_weight']) ? (float)$r['last_weight'] : null,
            ];
        }

        $byStatus = ['active'=>[], 'sold'=>[], 'dead'=>[], 'removed'=>[]];
        foreach ($items as $it) {
            $st = in_array($it['status'], ['active','sold','dead','removed'], true) ? $it['status'] : 'active';
            $byStatus[$st][] = $it['number'];
        }
        $total = count($items);

        if ($asksCount) {
            if (preg_match('~актив~u', $q)) return 'Сейчас активных голов: ' . count($byStatus['active']) . '.';
            if (preg_match('~продан~u', $q)) return 'Проданных: ' . count($byStatus['sold']) . '.';
            if (preg_match('~падеж|пало|мертв~u', $q)) return 'Падёж: ' . count($byStatus['dead']) . '.';
            if (preg_match('~архив|убран|removed~u', $q)) return 'В архиве: ' . count($byStatus['removed']) . '.';
            return 'Всего голов: ' . $total . '. Активных: ' . count($byStatus['active']) . ', проданных: ' . count($byStatus['sold']) . ', падёж: ' . count($byStatus['dead']) . ', архив: ' . count($byStatus['removed']) . '.';
        }

        if ($asksNumbers) {
            $nums = $byStatus['active'];
            $label = 'активных';
            if (preg_match('~продан~u', $q)) { $nums = $byStatus['sold']; $label = 'проданных'; }
            elseif (preg_match('~падеж|пало|мертв~u', $q)) { $nums = $byStatus['dead']; $label = 'падежа'; }
            elseif (preg_match('~архив~u', $q)) { $nums = $byStatus['removed']; $label = 'архива'; }
            elseif (preg_match('~все|всех~u', $q)) { $nums = array_map(fn($x) => $x['number'], $items); $label = 'всех'; }
            if (!$nums) return 'Номеров ' . $label . ' сейчас нет.';
            return 'Номера ' . $label . ': ' . implode(', ', $nums) . '.';
        }

        $dated = array_values(array_filter($items, fn($x) => $x['birth_ts'] !== null));
        if ($asksOldest) {
            if (!$dated) return 'Не могу определить самого старшего: в базе нет дат рождения.';
            usort($dated, fn($a,$b) => $a['birth_ts'] <=> $b['birth_ts']);
            $it = $dated[0];
            return 'Самый старший — №' . $it['number'] . ($it['birth'] !== '' ? ' (дата рождения ' . $it['birth'] . ')' : '') . '.';
        }
        if ($asksYoungest) {
            if (!$dated) return 'Не могу определить самого младшего: в базе нет дат рождения.';
            usort($dated, fn($a,$b) => $b['birth_ts'] <=> $a['birth_ts']);
            $it = $dated[0];
            return 'Самый младший — №' . $it['number'] . ($it['birth'] !== '' ? ' (дата рождения ' . $it['birth'] . ')' : '') . '.';
        }
        if ($asksHeaviest) {
            $weighted = array_values(array_filter($items, fn($x) => $x['last_weight'] !== null));
            if (!$weighted) return 'Не могу определить самого тяжёлого: в базе нет записей по весу.';
            usort($weighted, fn($a,$b) => $b['last_weight'] <=> $a['last_weight']);
            $it = $weighted[0];
            return 'Самый тяжёлый — №' . $it['number'] . ' (' . rtrim(rtrim(number_format((float)$it['last_weight'], 2, '.', ''), '0'), '.') . ' кг).';
        }

        return null;
    }

    // -------- Planning / Answering --------

    private function plan(string $question, array $schema, array $context = []): array
    {
        $allowedActions = $this->allowedActionsSpec();

        $system = "Ты — DB-агент фермерского бота. Твоя задача — помочь ответить на вопрос пользователя, используя базу данных.\n".
                  "Правила: (1) Никогда не выдумывай данные. (2) Если данных нет — так и скажи.\n".
                  "(3) Для чтения ты можешь предложить SELECT запросы. (4) Для записи ты НЕ пишешь SQL, а предлагаешь действия (actions).\n".
                  "(5) Вывод — ТОЛЬКО JSON-объект без пояснений вокруг.\n";

        $user = [
            'question' => $question,
            'context' => $context,
            'schema' => $schema,
            'constraints' => [
                'max_queries' => $this->maxQueries,
                'read_only_sql' => 'SELECT only',
                'max_limit' => $this->maxLimit,
            ],
            'allowed_actions' => $allowedActions,
            'output_format' => [
                'mode' => 'read|write|mixed',
                'queries' => [
                    ['sql'=>'SELECT ...','purpose'=>'why this query'],
                ],
                'actions' => [
                    ['action'=>'add_calf','args'=>['number'=>123,'birth_date'=>'YYYY-MM-DD'],'purpose'=>'...'],
                ],
            ],
        ];

        $txt = $this->ai->answerText($system, json_encode($user, JSON_UNESCAPED_UNICODE));
        if (!$txt['ok']) return ['ok'=>false,'error'=>$txt['error'] ?? 'AI_ERROR'];

        $json = $this->extractJson((string)$txt['text']);
        if ($json === null) return ['ok'=>false,'error'=>'AI_RETURNED_NOT_JSON', 'raw'=>$txt['text']];

        // Normalize
        $json['queries'] = is_array($json['queries'] ?? null) ? $json['queries'] : [];
        $json['actions'] = is_array($json['actions'] ?? null) ? $json['actions'] : [];
        return ['ok'=>true,'plan'=>$json];
    }

    private function answerFromResults(string $question, array $schema, array $results, array $context = []): array
    {
        $system = "Ты — помощник фермы. Отвечай по-русски, коротко и по делу.\n".
                  "Тебе дали результаты SELECT-запросов из БД. Используй ТОЛЬКО их.\n".
                  "Если данных недостаточно — предложи, что уточнить.\n";

        $payload = [
            'question' => $question,
            'context' => $context,
            'schema_hint' => $schema,
            'results' => $results,
        ];

        $txt = $this->ai->answerText($system, json_encode($payload, JSON_UNESCAPED_UNICODE));
        if (!$txt['ok']) return ['ok'=>false,'error'=>$txt['error'] ?? 'AI_ERROR'];
        return ['ok'=>true,'text'=>(string)$txt['text']];
    }

    // -------- Actions (writes) --------

    private function applyOneAction(string $action, array $args, int $chatId, int $userId): array
    {
        $action = trim($action);
        $user = $this->resolveUserName($userId);

        if ($action === 'add_calf') {
            $num = (int)($args['number'] ?? 0);
            if ($num <= 0) return ['ok'=>false,'error'=>'add_calf: bad number'];
            $this->calves->ensureCalf($num);

            $birth = trim((string)($args['birth_date'] ?? ''));
            if ($birth !== '') {
                $birth = $this->normalizeDate($birth);
                if ($birth !== '') $this->calves->setBirthDate($num, $birth, $chatId, $user);
            }

            $status = trim((string)($args['status'] ?? ''));
            if ($status !== '') {
                $this->calves->setLifeStatus($num, $status, $chatId, $user);
            }

            return ['ok'=>true,'msg'=>"✅ Добавил/обновил телёнка №{$num}" . ($birth ? " (🎂 {$birth})" : "") . ($status ? " (статус {$status})" : "")];
        }

        if ($action === 'add_event') {
            $num = (int)($args['calf_number'] ?? 0);
            $type = trim((string)($args['type'] ?? ''));
            $value = trim((string)($args['value'] ?? ''));
            if ($num <= 0 || $type === '' || $value === '') return ['ok'=>false,'error'=>'add_event: bad args'];

            $type = $this->normalizeEventType($type);
            if ($type === '') return ['ok'=>false,'error'=>'add_event: unsupported type'];

            // Normalize numeric values for temp/weight
            if ($type === 'temp' || $type === 'weight') {
                $value = str_replace(',', '.', $value);
            }

            // Birth goes through setBirthDate to support enum/varchar variants
            if (in_array($type, ['birth','dob','born'], true)) {
                $birth = $this->normalizeDate($value);
                if ($birth === '') return ['ok'=>false,'error'=>'add_event: bad birth date'];
                $this->calves->setBirthDate($num, $birth, $chatId, $user);
                return ['ok'=>true,'msg'=>"✅ Записал 🎂 для №{$num}: {$birth}"]; 
            }

            $this->calves->ensureCalf($num);
            $this->calves->addEvent($num, $type, $value, $chatId, $user);
            return ['ok'=>true,'msg'=>"✅ Записал событие: №{$num}, {$type} = {$value}"]; 
        }

        if ($action === 'set_qr') {
            $num = (int)($args['calf_number'] ?? 0);
            $code = trim((string)($args['qr'] ?? ''));
            if ($num <= 0 || $code === '') return ['ok'=>false,'error'=>'set_qr: bad args'];
            $this->calves->setQrCode($num, $code, $chatId, $user);
            return ['ok'=>true,'msg'=>"✅ Привязал QR для №{$num}: {$code}"]; 
        }

        if ($action === 'set_status') {
            $num = (int)($args['calf_number'] ?? 0);
            $st = trim((string)($args['status'] ?? ''));
            if ($num <= 0 || $st === '') return ['ok'=>false,'error'=>'set_status: bad args'];
            $this->calves->setLifeStatus($num, $st, $chatId, $user);
            return ['ok'=>true,'msg'=>"✅ Статус №{$num}: {$st}"]; 
        }

        if ($action === 'add_finance_expense') {
            if (!($this->finance instanceof FinanceService) || !$this->finance->isInstalled()) {
                return ['ok'=>false,'error'=>'finance module not installed'];
            }
            $amount = (float)str_replace(',', '.', (string)($args['amount'] ?? '0'));
            if ($amount <= 0) return ['ok'=>false,'error'=>'finance: bad amount'];
            $catName = trim((string)($args['category'] ?? ''));
            $comment = trim((string)($args['comment'] ?? ''));
            if ($catName === '') $catName = 'Прочее';

            $catId = $this->finance->getCategoryIdByName($catName, 'expense');
            if (!$catId) {
                $catId = $this->finance->addCategory($catName, 'expense');
            }
            $calfNumber = isset($args['calf_number']) ? (int)$args['calf_number'] : null;
            $txId = $this->finance->addExpense((int)$catId, $amount, $comment, $userId, null, $calfNumber, 'ai', null);
            if ($txId <= 0) return ['ok'=>false,'error'=>'finance: insert failed'];
            return ['ok'=>true,'msg'=>"✅ Расход добавлен: {$amount} ₽, {$catName}" . ($comment ? " ({$comment})" : "")];
        }

        if ($action === 'add_reminder') {
            $text = trim((string)($args['text'] ?? ''));
            $due = trim((string)($args['due_at'] ?? ''));
            if ($text === '' || $due === '') return ['ok'=>false,'error'=>'reminder: bad args'];
            $dueNorm = $this->normalizeDateTime($due);
            if ($dueNorm === '') return ['ok'=>false,'error'=>'reminder: bad due_at'];
            $calfNumber = isset($args['calf_number']) ? (int)$args['calf_number'] : null;

            $st = $this->pdo->prepare("INSERT INTO reminders(calf_number,due_at,text,sent,created_at) VALUES (?,?,?,?,NOW())");
            $st->execute([$calfNumber ?: null, $dueNorm, $text, 0]);
            return ['ok'=>true,'msg'=>"✅ Напоминание добавлено на {$dueNorm}" . ($calfNumber ? " (№{$calfNumber})" : "")];
        }

        return ['ok'=>false,'error'=>'UNKNOWN_ACTION: ' . $action];
    }

    // -------- Validation helpers --------

    private function isSafeSelect(string $sql): bool
    {
        $s = trim($sql);
        if ($s === '') return false;
        // one statement
        if (strpos($s, ';') !== false) return false;
        // No comments
        if (preg_match('~(--|/\*|\*/)#?~', $s)) return false;
        return (bool)preg_match('~^select\b~i', $s);
    }

    private function enforceLimit(string $sql): string
    {
        $s = trim($sql);
        // If query already has LIMIT, cap it.
        if (preg_match('~\blimit\s+(\d+)~i', $s, $m)) {
            $n = (int)$m[1];
            if ($n > $this->maxLimit) {
                $s = preg_replace('~\blimit\s+\d+~i', 'LIMIT ' . $this->maxLimit, $s, 1);
            }
            return $s;
        }
        return $s . ' LIMIT ' . $this->maxLimit;
    }

    private function runSelect(string $sql): array
    {
        try {
            $st = $this->pdo->query($sql);
            $rows = $st ? $st->fetchAll(PDO::FETCH_ASSOC) : [];
            if (!is_array($rows)) $rows = [];
            // Cap rows
            if (count($rows) > $this->maxRowsPerQuery) {
                $rows = array_slice($rows, 0, $this->maxRowsPerQuery);
            }
            return $rows;
        } catch (Throwable $e) {
            return [['error' => $e->getMessage()]];
        }
    }

    private function extractJson(string $text): ?array
    {
        $text = trim($text);
        if ($text === '') return null;
        // direct
        $d = json_decode($text, true);
        if (is_array($d)) return $d;
        // try to extract first {...}
        if (preg_match('~\{.*\}~s', $text, $m)) {
            $d = json_decode($m[0], true);
            if (is_array($d)) return $d;
        }
        return null;
    }

    private function normalizeEventType(string $type): string
    {
        $t = function_exists('mb_strtolower') ? mb_strtolower($type) : strtolower($type);
        $map = [
            'укол' => 'treatment',
            'препарат' => 'treatment',
            'лечение' => 'treatment',
            'treat' => 'treatment',
            'shot' => 'treatment',
            'treatment' => 'treatment',
            'note' => 'note',
            'заметка' => 'note',
            'temp' => 'temp',
            'темп' => 'temp',
            'температура' => 'temp',
            'weight' => 'weight',
            'вес' => 'weight',
            'qr' => 'qr',
            'бирка' => 'qr',
            'life' => 'life',
            'статус' => 'life',
            'birth' => 'birth',
            'dob' => 'dob',
            'born' => 'born',
            'дата рождения' => 'birth',
            'рождение' => 'birth',
        ];
        if (isset($map[$t])) return $map[$t];
        // Keep safe defaults
        if (in_array($t, ['temp','weight','treatment','note','qr','life','birth','dob','born'], true)) return $t;
        return '';
    }

    private function normalizeDate(string $s): string
    {
        $s = trim($s);
        if ($s === '') return '';
        // Accept YYYY-MM-DD
        if (preg_match('~^\d{4}-\d{2}-\d{2}$~', $s)) return $s;
        // Accept DD.MM.YYYY
        if (preg_match('~^(\d{1,2})\.(\d{1,2})\.(\d{4})$~', $s, $m)) {
            return sprintf('%04d-%02d-%02d', (int)$m[3], (int)$m[2], (int)$m[1]);
        }
        // Accept DD/MM/YYYY
        if (preg_match('~^(\d{1,2})/(\d{1,2})/(\d{4})$~', $s, $m)) {
            return sprintf('%04d-%02d-%02d', (int)$m[3], (int)$m[2], (int)$m[1]);
        }
        // Try strtotime
        $ts = strtotime($s);
        if ($ts) return date('Y-m-d', $ts);
        return '';
    }

    private function normalizeDateTime(string $s): string
    {
        $s = trim($s);
        if ($s === '') return '';
        // Accept YYYY-MM-DD HH:MM
        if (preg_match('~^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}(:\d{2})?$~', $s)) {
            return strlen($s) === 16 ? ($s . ':00') : $s;
        }
        // Accept DD.MM.YYYY HH:MM
        if (preg_match('~^(\d{1,2})\.(\d{1,2})\.(\d{4})\s+(\d{1,2}):(\d{2})$~', $s, $m)) {
            return sprintf('%04d-%02d-%02d %02d:%02d:00', (int)$m[3], (int)$m[2], (int)$m[1], (int)$m[4], (int)$m[5]);
        }
        $ts = strtotime($s);
        if ($ts) return date('Y-m-d H:i:s', $ts);
        return '';
    }

    private function resolveUserName(int $userId): ?string
    {
        // In this codebase we store source_user as username/first name.
        // In callbacks we don't always have it; keep as "ID xxxx".
        return 'ID ' . $userId;
    }

    private function allowedActionsSpec(): array
    {
        return [
            [
                'action' => 'add_calf',
                'args' => [
                    'number' => 'int (required)',
                    'birth_date' => 'YYYY-MM-DD or DD.MM.YYYY (optional)',
                    'status' => 'active|sold|dead|removed (optional)',
                ],
                'description' => 'Добавить телёнка/КРС по номеру (и опционально дату рождения/статус).',
            ],
            [
                'action' => 'add_event',
                'args' => [
                    'calf_number' => 'int (required)',
                    'type' => 'temp|weight|treatment|note|qr|life|birth|dob|born (required)',
                    'value' => 'string (required)',
                ],
                'description' => 'Добавить событие в журнал телёнка.',
            ],
            [
                'action' => 'set_qr',
                'args' => [
                    'calf_number' => 'int (required)',
                    'qr' => 'string (required)',
                ],
                'description' => 'Привязать QR к телёнку (как событие qr).',
            ],
            [
                'action' => 'set_status',
                'args' => [
                    'calf_number' => 'int (required)',
                    'status' => 'active|sold|dead|removed (required)',
                ],
                'description' => 'Установить статус (life).',
            ],
            [
                'action' => 'add_finance_expense',
                'args' => [
                    'amount' => 'number (required)',
                    'category' => 'string (optional, default Прочее)',
                    'comment' => 'string (optional)',
                    'calf_number' => 'int (optional)',
                ],
                'description' => 'Добавить расход (если установлен модуль финансов).',
            ],
            [
                'action' => 'add_reminder',
                'args' => [
                    'text' => 'string (required)',
                    'due_at' => 'YYYY-MM-DD HH:MM or DD.MM.YYYY HH:MM (required)',
                    'calf_number' => 'int (optional)',
                ],
                'description' => 'Добавить напоминание (таблица reminders).',
            ],
        ];
    }

    private function renderPlanForUser(array $plan): string
    {
        $lines = [];
        $actions = is_array($plan['actions'] ?? null) ? $plan['actions'] : [];
        foreach ($actions as $a) {
            if (!is_array($a)) continue;
            $action = (string)($a['action'] ?? '');
            $purpose = (string)($a['purpose'] ?? '');
            $args = is_array($a['args'] ?? null) ? $a['args'] : [];
            $lines[] = "• {$action}" . ($purpose ? " — {$purpose}" : '');
            if ($args) {
                $pairs = [];
                foreach ($args as $k=>$v) {
                    if (is_array($v) || is_object($v)) continue;
                    $pairs[] = $k . '=' . (string)$v;
                }
                if ($pairs) $lines[] = "  " . implode(', ', $pairs);
            }
        }
        return $lines ? implode("\n", $lines) : '—';
    }

    private function storeMutation(int $chatId, int $userId, string $requestText, array $plan): int
    {
        $st = $this->pdo->prepare("INSERT INTO ai_mutations(chat_id,user_id,request_text,plan_json,status,created_at) VALUES (?,?,?,?, 'pending', NOW())");
        $st->execute([$chatId, $userId, $requestText, json_encode($plan, JSON_UNESCAPED_UNICODE)]);
        return (int)$this->pdo->lastInsertId();
    }

    private function markMutation(int $id, string $status, ?string $error): void
    {
        $st = $this->pdo->prepare("UPDATE ai_mutations SET status=?, applied_at=NOW(), error=? WHERE id=?");
        $st->execute([$status, $error, $id]);
    }

    private function canWrite(int $chatId, string $chatType, int $userId): bool
    {
        if ($chatType === 'private') return true;
        if (!in_array($chatType, ['group','supergroup'], true)) return false;

        // Admin check
        try {
            $cm = tg_get_chat_member($this->config['bot_token'], $chatId, $userId);
            $m = is_array($cm) ? ($cm['result'] ?? null) : null;
            $status = is_array($m) ? (string)($m['status'] ?? '') : '';
            if ($status === 'creator') return true;
            if ($status === 'administrator') return true;
        } catch (Throwable $e) {
            return false;
        }
        return false;
    }

    private function describeSchema(): array
    {
        // Return list: table => [columns]
        $out = [];
        try {
            $st = $this->pdo->query("SELECT table_name, column_name, data_type FROM information_schema.columns WHERE table_schema = DATABASE() ORDER BY table_name, ordinal_position");
            $rows = $st ? $st->fetchAll(PDO::FETCH_ASSOC) : [];
            foreach ($rows as $r) {
                $t = (string)($r['table_name'] ?? '');
                $c = (string)($r['column_name'] ?? '');
                $dt = (string)($r['data_type'] ?? '');
                if ($t === '' || $c === '') continue;
                // Skip system-like
                if (in_array($t, ['information_schema','mysql','performance_schema','sys'], true)) continue;
                if (!isset($out[$t])) $out[$t] = [];
                $out[$t][] = $c . ':' . $dt;
            }
        } catch (Throwable $e) {
            // minimal hint
            $out = [
                'calves' => ['number:int','created_at:datetime'],
                'events' => ['id:bigint','calf_number:int','type:varchar','value:varchar','created_at:datetime'],
            ];
        }
        return $out;
    }
}
