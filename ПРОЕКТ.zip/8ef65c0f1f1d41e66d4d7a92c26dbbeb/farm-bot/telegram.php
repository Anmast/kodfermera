<?php

function ensure_utf8(string $s): string {
    // No mbstring dependency. Telegram строго требует UTF-8.

    // Quick check: valid UTF-8?
    $isUtf8 = (preg_match('//u', $s) === 1);

    // If it already looks like UTF-8 — just strip invalid bytes (if any).
    if ($isUtf8) {
        $clean = function_exists('iconv') ? @iconv('UTF-8', 'UTF-8//IGNORE', $s) : $s;
        return ($clean !== false && $clean !== '') ? $clean : $s;
    }

    // Try common Cyrillic encodings.
    if (function_exists('iconv')) {
        foreach (['Windows-1251', 'CP1251', 'ISO-8859-5'] as $enc) {
            $converted = @iconv($enc, 'UTF-8//IGNORE', $s);
            if ($converted !== false && $converted !== '') {
                $converted2 = @iconv('UTF-8', 'UTF-8//IGNORE', $converted);
                return $converted2 !== false ? $converted2 : $converted;
            }
        }
    }

    // Fallback: remove invalid bytes best-effort.
    return preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', (string)$s);
}

function tg_sanitize_params($v) {
    if (is_string($v)) return ensure_utf8($v);
    if (is_array($v)) {
        foreach ($v as $k => $vv) $v[$k] = tg_sanitize_params($vv);
        return $v;
    }
    return $v;
}

function tg_api(string $token, string $method, array $params = []) {
    $params = tg_sanitize_params($params);

    $url = "https://api.telegram.org/bot{$token}/{$method}";
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $params,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 20,
    ]);

    $res = curl_exec($ch);
    $err = curl_error($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($res === false) {
        file_put_contents(__DIR__.'/logs/tg.log', date('c')." CURL_ERROR {$method}: {$err}\n", FILE_APPEND);
        return null;
    }

    $data = json_decode($res, true);
    $ok = (is_array($data) && (($data['ok'] ?? false) === true));

    // Telegram иногда отвечает 400 "message is not modified" — это не ошибка для нашего master-post подхода.
    $isNotModified = (
        is_array($data)
        && (($data['ok'] ?? false) === false)
        && isset($data['description'])
        && is_string($data['description'])
        && str_contains($data['description'], 'message is not modified')
    );

    if (!$ok && !$isNotModified) {
        file_put_contents(__DIR__.'/logs/tg.log', date('c')." TG_FAIL {$method} HTTP={$http} RES={$res}\n", FILE_APPEND);
    }

    return $data;
}

function tg_send(string $token, int|string $chatId, string $text, array $extra = []) {
    $params = array_merge([
        'chat_id' => $chatId,
        'text' => ensure_utf8($text),
        'disable_web_page_preview' => true,
    ], $extra);

    return tg_api($token, 'sendMessage', $params);
}

function tg_edit(string $token, int|string $chatId, int $messageId, string $text, array $extra = []) {
    $params = array_merge([
        'chat_id' => $chatId,
        'message_id' => $messageId,
        'text' => ensure_utf8($text),
        'disable_web_page_preview' => true,
    ], $extra);

    $r = tg_api($token, 'editMessageText', $params);
    // Treat "not modified" as success to avoid sending a duplicate message.
    if (is_array($r) && (($r['ok'] ?? false) === false) && isset($r['description']) && is_string($r['description']) && str_contains($r['description'], 'message is not modified')) {
        return ['ok' => true, 'result' => ['message_id' => $messageId]];
    }
    return $r;
}

function tg_answer_callback(string $token, string $callbackId, string $text = '') {
    $params = [
        'callback_query_id' => $callbackId,
        'text' => ensure_utf8($text),
        'show_alert' => false,
    ];
    return tg_api($token, 'answerCallbackQuery', $params);
}
function tg_delete(string $token, int|string $chatId, int $messageId) {
    return tg_api($token, 'deleteMessage', [
        'chat_id' => $chatId,
        'message_id' => $messageId,
    ]);
}

function tg_send_document(string $token, int|string $chatId, string $filePath, string $filename, string $caption = '') {
    if (!is_file($filePath)) return null;
    $params = [
        'chat_id' => $chatId,
        'caption' => ensure_utf8($caption),
        'document' => new CURLFile($filePath, 'text/csv', $filename),
        'disable_content_type_detection' => false,
    ];
    return tg_api($token, 'sendDocument', $params);
}

// ===== Bot API 9.5 (Mar 1, 2026) helpers =====

/**
 * Stream a partial message to a *private* chat while it is being generated.
 * Bot API: sendMessageDraft
 */
function tg_send_draft(string $token, int $chatId, int $draftId, string $text, array $extra = []) {
    $params = array_merge([
        'chat_id' => $chatId,
        'draft_id' => ($draftId === 0 ? 1 : $draftId),
        'text' => ensure_utf8($text),
    ], $extra);
    return tg_api($token, 'sendMessageDraft', $params);
}

/**
 * Get chat member info (used for permissions checks).
 */
function tg_get_chat_member(string $token, int|string $chatId, int $userId) {
    return tg_api($token, 'getChatMember', [
        'chat_id' => $chatId,
        'user_id' => $userId,
    ]);
}

/**
 * Set (or clear) a tag for a regular member in a group/supergroup.
 * Bot API: setChatMemberTag
 */
function tg_set_chat_member_tag(string $token, int|string $chatId, int $userId, ?string $tag) {
    $params = [
        'chat_id' => $chatId,
        'user_id' => $userId,
    ];
    // tag is optional. Empty string clears the tag.
    if ($tag !== null) $params['tag'] = ensure_utf8($tag);
    return tg_api($token, 'setChatMemberTag', $params);
}

/**
 * Convenience: protect message content from forwarding/copying.
 */
function tg_send_protected(string $token, int|string $chatId, string $text, array $extra = []) {
    $extra['protect_content'] = $extra['protect_content'] ?? true;
    return tg_send($token, $chatId, $text, $extra);
}

/**
 * HTML tag for localized date/time rendering.
 * Example: <tg-time unix="1647531900" format="wDT">22:45 tomorrow</tg-time>
 */
function tg_time_html(int $unix, string $format = 'wDT', string $fallback = ''): string {
    if ($fallback === '') {
        $fallback = date('Y-m-d H:i', $unix);
    }
    $format = preg_replace('/[^rwdtDT]/', '', $format);
    // Note: Telegram requires a valid fallback text inside the tag.
    $fallback = htmlspecialchars(ensure_utf8($fallback), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $u = (string)$unix;
    if ($format === '') return "<tg-time unix=\"{$u}\">{$fallback}</tg-time>";
    return "<tg-time unix=\"{$u}\" format=\"{$format}\">{$fallback}</tg-time>";
}



function tg_get_file(string $token, string $fileId): ?array {
    $res = tg_api($token, 'getFile', ['file_id' => $fileId]);
    if (!is_array($res) || !($res['ok'] ?? false)) return null;
    return $res['result'] ?? null;
}

function tg_download_file(string $token, string $filePath, string $destPath): bool {
    $url = "https://api.telegram.org/file/bot{$token}/{$filePath}";
    $fp = fopen($destPath, 'wb');
    if (!$fp) return false;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_FILE => $fp,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 60,
    ]);
    $ok = curl_exec($ch);
    curl_close($ch);
    fclose($fp);

    return $ok !== false && file_exists($destPath) && filesize($destPath) > 0;
}
