-- Finance + Payroll tables (MySQL, utf8mb4)

CREATE TABLE IF NOT EXISTS finance_categories (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  type ENUM('expense','income') NOT NULL DEFAULT 'expense',
  is_system TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_name_type (name, type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS finance_transactions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tx_date DATETIME NOT NULL,
  type ENUM('expense','income') NOT NULL DEFAULT 'expense',
  category_id INT UNSIGNED NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  comment VARCHAR(255) NOT NULL DEFAULT '',
  employee_id INT UNSIGNED NULL,
  calf_number INT NULL,
  source_type VARCHAR(40) NULL,
  source_id BIGINT UNSIGNED NULL,
  created_by BIGINT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_type_date (type, tx_date),
  KEY idx_cat_date (category_id, tx_date),
  KEY idx_employee (employee_id),
  CONSTRAINT fk_fin_cat FOREIGN KEY (category_id) REFERENCES finance_categories(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS employees (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  phone VARCHAR(60) NULL,
  note VARCHAR(255) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payroll_accruals (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  employee_id INT UNSIGNED NOT NULL,
  work_date DATE NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  comment VARCHAR(255) NOT NULL DEFAULT '',
  created_by BIGINT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_emp_date (employee_id, work_date),
  CONSTRAINT fk_pay_acc_emp FOREIGN KEY (employee_id) REFERENCES employees(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payroll_payouts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  employee_id INT UNSIGNED NOT NULL,
  payout_date DATE NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  comment VARCHAR(255) NOT NULL DEFAULT '',
  created_by BIGINT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_emp_date (employee_id, payout_date),
  CONSTRAINT fk_pay_pay_emp FOREIGN KEY (employee_id) REFERENCES employees(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed базовых категорий (можно запускать повторно)
INSERT IGNORE INTO finance_categories(name, type, is_system) VALUES
('Корма','expense',0),
('Ветпрепараты','expense',0),
('ГСМ','expense',0),
('Электричество','expense',0),
('Ремонт/стройка','expense',0),
('Инструмент/хозтовары','expense',0),
('Транспорт','expense',0),
('Зарплата','expense',1),
('Прочее','expense',0);
