<?php

/**
 * Единый реестр действий бота.
 *
 * Как добавить новую функцию:
 * 1) Добавь новый ключ в actions_registry()
 * 2) (опционально) добавь правило в kb_menu_groups() чтобы разместить кнопку в меню
 * 3) Реализуй поведение через конфиг (prompt/validate/save) — без правок в handlers.
 */

function actions_registry(): array {
    return [
        'temp' => [
            'title' => '🌡 Температура',
            'step1' => fn(int $calf) => "🌡 Температура\n\nВведи номер телёнка (например 249)",
            'step2' => fn(int $calf) => "🌡 Температура\n\nВведи температуру для №{$calf} (например 39.8)",
            'validate2' => function(string $value): array {
                $v = norm($value);
                if (!preg_match('/^[0-9]+([.,][0-9]+)?$/', $v)) return [false, 'Температура должна быть числом, например 39.8'];
                $t = (float)str_replace(',', '.', $v);
                return [true, (string)$t];
            },
            'save' => function(array $ctx, int $calf, string $value): void {
                $ctx['calves']->ensureCalf($calf);
                $ctx['calves']->addEvent($calf, 'temp', $value, $ctx['chatId'], $ctx['user']);

                $temp = (float)$value;
                $alert = $ctx['alerts']->checkTemp($calf, $temp);
                if ($alert && (int)$ctx['config']['chat_control'] !== 0) {
                    // Protect sensitive health info from forwarding/copying
                    tg_send($ctx['config']['bot_token'], (int)$ctx['config']['chat_control'], $alert, [
                        'protect_content' => true,
                    ]);
                }
            },
            'success' => fn(int $calf, string $value) => "✅ Записал: №{$calf} температура {$value}",
            'auto_delete' => 5,
        ],

        'treat' => [
            'title' => '💉 Укол',
            'step1' => fn(int $calf) => "💉 Укол\n\nВведи номер телёнка (например 249)",
            'step2' => fn(int $calf) => "💉 Укол\n\nВведи препарат и дозу для №{$calf} (например: азитронит 3мл)",
            'validate2' => function(string $value): array {
                $v = norm($value);
                if (u_strlen($v) < 2) return [false, 'Слишком коротко. Пример: азитронит 3мл'];
                return [true, $v];
            },
            // Укол — особый сценарий: после ввода препарата спрашиваем повтор кнопкой.
            'needs_repeat' => true,
        ],

        'note' => [
            'title' => '📝 Заметка',
            'step1' => fn(int $calf) => "📝 Заметка\n\nВведи номер телёнка (например 249)",
            'step2' => fn(int $calf) => "📝 Заметка\n\nВведи заметку для №{$calf} (например: плохо ест)",
            'validate2' => fn(string $value) => [true, norm($value)],
            'save' => function(array $ctx, int $calf, string $value): void {
                $ctx['calves']->ensureCalf($calf);
                $ctx['calves']->addEvent($calf, 'note', $value, $ctx['chatId'], $ctx['user']);
            },
            'success' => fn(int $calf, string $value) => "✅ Заметка по №{$calf} сохранена.",
            'auto_delete' => 5,
        ],

        'weight' => [
            'title' => '⚖️ Вес',
            'step1' => fn(int $calf) => "⚖️ Вес\n\nВведи номер телёнка (например 249)",
            'step2' => fn(int $calf) => "⚖️ Вес\n\nВведи вес для №{$calf} (например 42.5)",
            'validate2' => function(string $value): array {
                $v = norm($value);
                if (!preg_match('/^[0-9]+([.,][0-9]+)?$/', $v)) return [false, 'Вес должен быть числом, например 42.5'];
                $w = (float)str_replace(',', '.', $v);
                return [true, (string)$w];
            },
            'save' => function(array $ctx, int $calf, string $value): void {
                $ctx['calves']->ensureCalf($calf);
                $ctx['calves']->addEvent($calf, 'weight', $value, $ctx['chatId'], $ctx['user']);
            },
            'success' => fn(int $calf, string $value) => "✅ Вес №{$calf}: {$value}",
            'auto_delete' => 5,
        ],

        'birth' => [
            'title' => '🎂 Дата рождения',
            'step1' => fn(int $calf) => "🎂 Дата рождения\n\nВведи номер телёнка (например 249)",
            'step2' => fn(int $calf) => "🎂 Дата рождения\n\nВведи дату рождения для №{$calf}\nНапример: 2026-02-20 или 20.02.2026",
            'validate2' => function(string $value): array {
                $v = norm($value);
                $dt = DateTime::createFromFormat('Y-m-d', $v) ?: DateTime::createFromFormat('d.m.Y', $v);
                if (!$dt) return [false, 'Дата должна быть в формате 2026-02-20 или 20.02.2026'];
                return [true, $dt->format('Y-m-d')];
            },
            'save' => function(array $ctx, int $calf, string $value): void {
                $ctx['calves']->setBirth($calf, $value, $ctx['chatId'], $ctx['user']);
            },
            'success' => fn(int $calf, string $value) => "✅ Записал: №{$calf} дата рождения {$value}",
            'auto_delete' => 5,
        ],

        'status' => [
            'title' => '📋 Статус',
            'step1' => fn(int $calf) => "📋 Статус\n\nВведи номер телёнка (например 249)",
            'status_mode' => true,
        ],
    ];
}

/**
 * Раскладка кнопок главного меню.
 * Возвращает массив рядов, где каждый ряд — список action key.
 */
function kb_menu_groups(): array {
    return [
        ['temp', 'treat'],
        ['note', 'weight'],
        ['status'],
    ];
}
