<?php

function flow_show(array $config, int $chatId, int $flowMsgId, string $text, ?array $replyMarkup = null): int {
    $extra = [];

    if ($replyMarkup) {
        // Protect against invalid UTF-8 inside button titles/values.
        if (function_exists('tg_sanitize_params')) {
            $replyMarkup = tg_sanitize_params($replyMarkup);
        }
        $extra['reply_markup'] = json_encode(
            $replyMarkup,
            JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
        );
    }

    if ($flowMsgId > 0) {
        $edit = tg_edit($config['bot_token'], $chatId, $flowMsgId, $text, $extra);
        if (is_array($edit) && (($edit['ok'] ?? false) === true)) {
            return $flowMsgId;
        }
        // If edit failed (message deleted / not found / etc.) — fall back to new master message.
    }

    $res = tg_send($config['bot_token'], $chatId, $text, $extra);
    return (int)($res['result']['message_id'] ?? 0);
}

function screen_show(array $config, int $chatId, int $flowMsgId, string $screenName, array $ctx = [], array $params = []): int {
    $fn = screen_get($screenName);
    if (!$fn) {
        return flow_show($config, $chatId, $flowMsgId, "Экран не найден: {$screenName}");
    }
    $res = $fn($ctx, $params);
    $text = (string)($res['text'] ?? '');
    $kb   = $res['kb'] ?? null;
    $mid = flow_show($config, $chatId, $flowMsgId, $text, is_array($kb) ? $kb : null);
    if (isset($ctx['pdo']) && $ctx['pdo'] instanceof PDO) {
        ui_sync_reply_keyboard_for_screen($ctx['pdo'], $config, $chatId, $screenName);
    }
    return $mid;
}

function show_menu(array $config, PDO $pdo, StateService $states, CalfService $calves, int $chatId, int $userId, string $chatType = '', bool $forceNew = false): int {
    // Inject optional services without changing all call sites.
    global $alerts, $finance, $payroll;

    $st = $states->get($chatId, $userId);
    $flowId = $forceNew ? 0 : get_flow_id($st);

    $ctx = [
        'config' => $config,
        'pdo' => $pdo,
        'states' => $states,
        'calves' => $calves,
        'alerts' => $alerts ?? null,
        'finance' => $finance ?? null,
        'payroll' => $payroll ?? null,
        'chatId' => $chatId,
        'userId' => $userId,
        'chatType' => $chatType,
    ];

    // IMPORTANT: screen_show may fallback to sending a NEW message when edit fails.
    // We must store the returned message_id back into state, otherwise the bot will keep editing a dead message
    // and spam new messages (and can hit flood limits on bad internet / duplicate updates).
    $actualFlowId = screen_show($config, $chatId, $flowId, 'menu', $ctx);

    if ($actualFlowId > 0) {
        $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $actualFlowId]);
    }

    return $actualFlowId;
}

