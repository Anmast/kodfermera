<?php
function norm(string $s): string {
    $s = trim($s);
    $s = preg_replace('/\s+/u', ' ', $s);
    return $s;
}

// UTF-8 safe string helpers without mandatory mbstring.
// mbstring is great but not always enabled on shared hosting.
function u_strlen(string $s): int {
    if (function_exists('mb_strlen')) {
        return (int)mb_strlen($s, 'UTF-8');
    }
    // Count UTF-8 characters via regex.
    $n = preg_match_all('/./us', $s, $m);
    return $n === false ? strlen($s) : (int)$n;
}

function u_substr(string $s, int $start, ?int $len = null): string {
    if (function_exists('mb_substr')) {
        return (string)mb_substr($s, $start, $len, 'UTF-8');
    }
    // Split into Unicode chars and slice.
    $chars = preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY);
    if (!is_array($chars)) {
        return $len === null ? substr($s, $start) : substr($s, $start, $len);
    }
    $slice = $len === null ? array_slice($chars, $start) : array_slice($chars, $start, $len);
    return implode('', $slice);
}

function u_lower(string $s): string {
    if (function_exists('mb_strtolower')) {
        return (string)mb_strtolower($s, 'UTF-8');
    }
    return strtolower($s);
}

function safe_delete(array $config, int $chatId, int $messageId): void {
    if ($messageId <= 0) return;
    try { tg_delete($config['bot_token'], $chatId, $messageId); }
    catch (\Throwable $e) {}
}

function delete_later(array $config, int $chatId, array $messageIds, int $seconds = 5): void {
    if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request();
    sleep(max(0, $seconds));
    foreach ($messageIds as $mid) safe_delete($config, $chatId, (int)$mid);
}

function get_flow_id(?array $state): int {
    if (!$state) return 0;
    $payload = $state['payload'] ?? null;
    if (!is_array($payload)) return 0;
    return (int)($payload['flow_msg_id'] ?? 0);
}

/**
 * Unified callback format:
 *   cb:<route>|k=v&k2=v2
 */
function cb_pack(string $route, array $params = []): string {
    $route = trim($route);
    if ($route === '') return '';
    if (!$params) return 'cb:' . $route;
    // RFC3986: compact and safe. Keep params short: Telegram callback_data limit is 64 bytes.
    $qs = http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    return 'cb:' . $route . '|' . $qs;
}

function cb_parse(string $data): ?array {
    if (!str_starts_with($data, 'cb:')) return null;
    $rest = substr($data, 3);
    $route = $rest;
    $qs = '';
    if (strpos($rest, '|') !== false) {
        [$route, $qs] = explode('|', $rest, 2);
    }
    $route = trim((string)$route);
    if ($route === '') return null;
    $params = [];
    if ($qs !== '') {
        parse_str($qs, $params);
        if (!is_array($params)) $params = [];
    }
    return ['route' => $route, 'params' => $params];
}

// Date format helper (dd.mm.yyyy [hh:mm])
function format_dt($datetime, bool $withTime = true): string {
    if (!$datetime) return '';
    $ts = strtotime((string)$datetime);
    if (!$ts) return (string)$datetime;
    return $withTime ? date('d.m.Y H:i', $ts) : date('d.m.Y', $ts);
}

function kv_get(PDO $pdo, string $key, ?string $default = null): ?string {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS bot_kv (k VARCHAR(64) PRIMARY KEY, v TEXT NULL, updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)");
        $st = $pdo->prepare("SELECT v FROM bot_kv WHERE k=? LIMIT 1");
        $st->execute([$key]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) return $default;
        return isset($row['v']) ? (string)$row['v'] : $default;
    } catch (Throwable $e) {
        return $default;
    }
}

function kv_set(PDO $pdo, string $key, string $value): bool {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS bot_kv (k VARCHAR(64) PRIMARY KEY, v TEXT NULL, updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)");
        return (bool)$pdo->prepare("REPLACE INTO bot_kv(k,v) VALUES(?,?)")->execute([$key, $value]);
    } catch (Throwable $e) {
        return false;
    }
}

function throttle_allow(PDO $pdo, int $chatId, string $action, int $seconds = 2, int $userId = 0): bool {
    $seconds = max(1, min(300, $seconds));
    $key = 'throttle:' . $chatId . ':' . $userId . ':' . trim($action);
    $now = time();
    $last = (int)(kv_get($pdo, $key, '0') ?? '0');
    if ($last > 0 && ($now - $last) < $seconds) {
        return false;
    }
    kv_set($pdo, $key, (string)$now);
    return true;
}

function send_reply_menu_keyboard(PDO $pdo, array $config, int $chatId, bool $force = false): void {
    if (!function_exists('kb_reply_root')) return;

    $key = 'reply_kb:' . $chatId;
    $last = (int)(kv_get($pdo, $key, '0') ?? '0');
    $now = time();

    if ($force) {
        if ($last > 0 && ($now - $last) < 8) return;
    } else {
        if ($last > 0 && ($now - $last) < 43200) return;
    }

    $kb = kb_reply_root();
    $carrier = "ㅤ";
    $res = tg_send($config['bot_token'], $chatId, $carrier, [
        'reply_markup' => json_encode($kb, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
        'protect_content' => true,
    ]);

    if (is_array($res) && (($res['ok'] ?? false) === true)) {
        kv_set($pdo, $key, (string)$now);
        $mid = (int)($res['result']['message_id'] ?? 0);
        if ($mid > 0) kv_set($pdo, 'reply_kb_msg:' . $chatId, (string)$mid);
    }
}


function ui_reply_keyboard_mode_for_screen(string $screenName): string {
    $screenName = trim($screenName);
    return match ($screenName) {
        'menu', 'reports_menu' => 'root',
        'menu_krs', 'krs_find', 'krs_data', 'calves_list', 'calves_archive', 'calf_view', 'calf_edit' => 'krs',
        'finance_menu', 'finance_categories', 'finance_journal' => 'finance',
        'payroll_menu', 'payroll_employees', 'payroll_debts' => 'payroll',
        'ai_help' => 'ai',
        default => 'root',
    };
}

function ui_reply_keyboard_markup_by_mode(string $mode): array {
    return match ($mode) {
        'krs' => kb_reply_krs(),
        'finance' => kb_reply_finance(),
        'payroll' => kb_reply_payroll(),
        'ai' => kb_reply_ai(),
        default => kb_reply_root(),
    };
}

function ui_sync_reply_keyboard_for_screen(PDO $pdo, array $config, int $chatId, string $screenName, bool $force = false): void {
    if (!function_exists('tg_send') || !function_exists('ui_reply_keyboard_markup_by_mode')) return;

    $mode = ui_reply_keyboard_mode_for_screen($screenName);
    $modeKey = 'reply_kb_mode:' . $chatId;
    $msgKey = 'reply_kb_msg:' . $chatId;
    $tsKey = 'reply_kb:' . $chatId;

    $prevMode = (string)(kv_get($pdo, $modeKey, '') ?? '');
    $lastTs = (int)(kv_get($pdo, $tsKey, '0') ?? '0');
    $now = time();

    if (!$force && $prevMode === $mode && $lastTs > 0 && ($now - $lastTs) < 43200) {
        return;
    }

    $kb = ui_reply_keyboard_markup_by_mode($mode);
    $carrier = 'ㅤ';
    $res = tg_send($config['bot_token'], $chatId, $carrier, [
        'reply_markup' => json_encode($kb, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
        'protect_content' => true,
    ]);

    if (is_array($res) && (($res['ok'] ?? false) === true)) {
        kv_set($pdo, $modeKey, $mode);
        kv_set($pdo, $tsKey, (string)$now);
        $mid = (int)($res['result']['message_id'] ?? 0);
        if ($mid > 0) {
            kv_set($pdo, $msgKey, (string)$mid);
        }
    }
}

function hide_reply_menu_keyboard(PDO $pdo, array $config, int $chatId): void {
    if (!function_exists('kb_reply_remove')) return;
    tg_send($config['bot_token'], $chatId, '⌨️', [
        'reply_markup' => json_encode(kb_reply_remove(), JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
        'protect_content' => true,
    ]);
    kv_set($pdo, 'reply_kb:' . $chatId, '0');
    kv_set($pdo, 'reply_kb_msg:' . $chatId, '0');
}

// ---------- Group UX helpers ----------
function is_ai_trigger_text(string $text): bool {
    $t = trim($text);
    if ($t === '' || str_starts_with($t, '/')) return false;
    $lt = mb_strtolower($t, 'UTF-8');

    // Explicit phrases
    if (mb_strpos($lt, 'спроси у ии') !== false) return true;
    if (mb_strpos($lt, 'спроси у ai') !== false) return true;

    // Mentions/keywords
    if (mb_strpos($lt, 'макс') !== false) return true;

    // standalone words "ии" / "бот" to avoid matching inside other words
    if (preg_match('~(^|[^\p{L}])ии([^\p{L}]|$)~u', $lt)) return true;
    if (preg_match('~(^|[^\p{L}])бот([^\p{L}]|$)~u', $lt)) return true;
    return false;
}

/**
 * Ensure Telegram UI for groups is configured (menu button + commands).
 * Uses DB key-value storage to avoid spamming API calls.
 */
function ensure_group_ui_installed(PDO $pdo, string $botToken): void {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS bot_kv (k VARCHAR(64) PRIMARY KEY, v TEXT NULL, updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)");
    } catch (Throwable $e) {
        // ignore
    }

    $key = 'ui_groups_v2_installed';
    try {
        $st = $pdo->prepare("SELECT v FROM bot_kv WHERE k=? LIMIT 1");
        $st->execute([$key]);
        $row = $st->fetch();
        if ($row && (string)($row['v'] ?? '') === '1') return;
    } catch (Throwable $e) {
        // continue
    }

    // 1) Global menu button: show commands
    tg_api($botToken, 'setChatMenuButton', [
        'menu_button' => json_encode(['type' => 'commands'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
    ]);

    // 2) Commands for all groups
    tg_api($botToken, 'setMyCommands', [
        'commands' => json_encode([
            ['command' => 'menu',  'description' => 'Открыть меню'],
            ['command' => 'panel', 'description' => 'Панель (закреп)'],
            ['command' => 'ask',   'description' => 'Вопрос ИИ'],
        ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
        'scope' => json_encode(['type' => 'all_group_chats'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
    ]);

    try {
        $pdo->prepare("REPLACE INTO bot_kv(k,v) VALUES(?,?)")->execute([$key, '1']);
    } catch (Throwable $e) {
        // ignore
    }
}


// ---------- AI /ask helpers ----------
function strip_bot_username(string $cmd): string {
    // /ask@BotName -> /ask
    $cmd = trim($cmd);
    if (preg_match('~^/([a-zA-Z0-9_]+)@([a-zA-Z0-9_]+)~', $cmd, $m)) {
        return '/' . $m[1];
    }
    return $cmd;
}

function is_ask_command_text(string $text): bool {
    $t = ltrim($text);
    if ($t === '') return false;
    if ($t[0] !== '/') return false;
    $first = strtok($t, " \n\t");
    $first = strip_bot_username($first);
    return ($first === '/ask');
}

function get_ask_query(string $text): string {
    $t = ltrim($text);
    $first = strtok($t, " \n\t");
    $rest = trim(substr($t, strlen($first)));
    return $rest;
}

function extract_calf_number(string $s): ?int {
    // Prefer patterns with "теленок/телёнок/№"
    if (preg_match('~(?:теленок|телёнок|тёл[её]нок)\s*#?\s*(\d{1,6})~iu', $s, $m)) return (int)$m[1];
    if (preg_match('~№\s*(\d{1,6})~u', $s, $m)) return (int)$m[1];
    if (preg_match('~\b(\d{1,6})\b~u', $s, $m)) return (int)$m[1];
    return null;
}

function ai_extract_temp(string $s): ?float {
    if (preg_match('~\b(3[5-9]|4[0-2])([.,]\d)?\b~u', $s, $m)) {
        $v = str_replace(',', '.', $m[0]);
        return (float)$v;
    }
    return null;
}

function ai_extract_weight(string $s): ?float {
    if (preg_match('~(?:вес|взвесил[аи]?|масса)\s*(?:=|:)?\s*(\d{1,4})([.,]\d)?\s*(?:кг)?~iu', $s, $m)) {
        $v = $m[1] . ($m[2] ?? '');
        $v = str_replace(',', '.', $v);
        return (float)$v;
    }
    if (preg_match('~\b(\d{2,4})([.,]\d)?\s*кг\b~iu', $s, $m)) {
        $v = $m[1] . ($m[2] ?? '');
        $v = str_replace(',', '.', $v);
        return (float)$v;
    }
    return null;
}

function build_chat_context_text(array $rows): string {
    $out = [];
    foreach ($rows as $r) {
        $who = (string)($r['username'] ?? 'user');
        $tag = (string)($r['sender_tag'] ?? '');
        if ($tag !== '') $who .= " ({$tag})";

        $type = (string)($r['msg_type'] ?? 'text');
        $text = (string)($r['text'] ?? '');
        $caption = (string)($r['caption'] ?? '');
        $tr = (string)($r['transcript'] ?? '');

        if ($type === 'text' && $text !== '') {
            $out[] = "{$who}: {$text}";
        } elseif ($type === 'voice' && $tr !== '') {
            $out[] = "{$who} (voice): {$tr}";
        } elseif ($type === 'photo' && $caption !== '') {
            $out[] = "{$who} (photo caption): {$caption}";
        }
    }
    return implode("\n", $out);
}


function is_question_like(string $text): bool {
    $t = trim($text);
    if ($t === '') return false;
    if (str_contains($t, '?')) return true;
    $lt = function_exists('mb_strtolower') ? mb_strtolower($t, 'UTF-8') : strtolower($t);
    foreach (['сколько','количество','какие','какой','какая','кто','где','когда','покажи','перечисли','назови','есть ли','осталось ли','каких','какую'] as $w) {
        if (str_starts_with($lt, $w) || preg_match('~(^|\s)' . preg_quote($w, '~') . '(\s|$)~u', $lt)) return true;
    }
    return false;
}

function normalize_ai_query_text(string $text): string {
    $q = trim($text);
    $q = preg_replace('~^\s*(макс|ии|бот)\s*[,!:.-]*\s*~iu', '', $q);
    $q = preg_replace('~^\s*спроси\s+у\s+(?:ии|ai)\s*[,!:.-]*\s*~iu', '', $q);
    return trim((string)$q);
}

function build_ai_context_payload(?ChatLogService $chatlog, int $chatId, int $limit = 14, ?array $msg = null): array {
    $payload = ['summary' => '', 'recent' => [], 'reply_to_text' => ''];
    if ($chatlog instanceof ChatLogService) {
        $payload['summary'] = (string)($chatlog->getSummary($chatId) ?? '');
        $rows = $chatlog->getRecentContext($chatId, max(8, min(40, $limit)));
        foreach ($rows as $r) {
            $who = (string)($r['username'] ?? 'user');
            $type = (string)($r['msg_type'] ?? 'text');
            $body = '';
            if ($type === 'text') $body = (string)($r['text'] ?? '');
            elseif ($type === 'voice') $body = (string)($r['transcript'] ?? '');
            elseif ($type === 'photo') $body = (string)($r['caption'] ?? '');
            if ($body !== '') $payload['recent'][] = $who . ': ' . $body;
        }
    }
    if (is_array($msg) && !empty($msg['reply_to_message'])) {
        $src = $msg['reply_to_message'];
        $payload['reply_to_text'] = trim((string)($src['text'] ?? ($src['caption'] ?? '')));
    }
    return $payload;
}
