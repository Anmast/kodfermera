<?php
$config = require __DIR__ . '/../config.php';
$pdo    = require __DIR__ . '/../db.php';

require __DIR__ . '/../telegram.php';
require __DIR__ . '/../services/Parser.php';
require __DIR__ . '/../services/CalfService.php';
require __DIR__ . '/../services/AlertService.php';
require __DIR__ . '/../services/StateService.php';
require __DIR__ . '/../services/FinanceService.php';
require __DIR__ . '/../services/PayrollService.php';

require __DIR__ . '/../services/SchemaService.php';
require __DIR__ . '/../services/ChatLogService.php';
require __DIR__ . '/../services/AiService.php';
require __DIR__ . '/../services/AiDbAgent.php';

require __DIR__ . '/utils.php';
require __DIR__ . '/ui.php';
require __DIR__ . '/screens.php';
require __DIR__ . '/flow.php';

$calves = new CalfService($pdo);
$alerts = new AlertService($config);
$states = new StateService($pdo);
$finance = new FinanceService($pdo);
$payroll = new PayrollService($pdo);

$schema = new SchemaService($pdo);
$schema->ensure();
$chatlog = new ChatLogService($pdo);
$ai = new AiService($config);

// AI DB Agent (read + controlled write with confirmation)
$dbAgent = new AiDbAgent($pdo, $ai, $calves, $finance ?? null, $config);

// Seed base categories if finance tables are installed.
$finance->ensureBaseCategories();
