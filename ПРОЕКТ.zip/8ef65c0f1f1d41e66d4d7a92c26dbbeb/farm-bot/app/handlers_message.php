<?php
function handle_message(array $msg): void {
    global $config, $pdo, $states, $calves, $alerts, $finance, $payroll, $chatlog, $ai, $dbAgent;

    $chatId    = (int)$msg['chat']['id'];
    $chatType  = (string)($msg['chat']['type'] ?? '');
    $userId    = (int)($msg['from']['id'] ?? 0);
    $userMsgId = (int)($msg['message_id'] ?? 0);
    $text      = (string)($msg['text'] ?? '');
    $user      = $msg['from']['username'] ?? ($msg['from']['first_name'] ?? null);
    $senderTag = (string)($msg['sender_tag'] ?? ''); // Bot API 9.5: member tags
    if ($user !== null && $senderTag !== '') {
        $user = (string)$user . " ({$senderTag})";
    }

    // Save message for /ask context
    if (isset($chatlog)) { $chatlog->logMessage($msg); }


    // Telegram WebApp data (QR scan)
    if (!empty($msg['web_app_data']['data'])) {
        if (empty($msg['photo'])) { safe_delete($config, $chatId, $userMsgId); }
        $raw = (string)$msg['web_app_data']['data'];
        $data = json_decode($raw, true);
        if (is_array($data) && ($data['t'] ?? '') === 'qr') {
            $code = norm((string)($data['code'] ?? ''));
            if ($code !== '') {
                $st0 = $states->get($chatId, $userId);
                $flowId0 = get_flow_id($st0);
                if ($flowId0 <= 0) {
                    show_menu($config, $pdo, $states, $calves, $chatId, $userId, $chatType);
                    $st0 = $states->get($chatId, $userId);
                    $flowId0 = get_flow_id($st0);
                }

                // If we are in QR bind flow — treat scan as "got QR code"
                if ($st0 && (string)($st0['action'] ?? '') === 'qr_bind' && (int)($st0['step'] ?? 0) === 1) {
                    $payload = is_array($st0['payload'] ?? null) ? $st0['payload'] : [];
                    $payload['qr_code'] = $code;
                    $payload['flow_msg_id'] = $flowId0;
                    $states->set($chatId, $userId, 'qr_bind', 2, null, $payload);
                    flow_show($config, $chatId, $flowId0, "🔗 Привязка бирки (QR)\n\nКод считан ✅\n\nТеперь введи номер телёнка, которому принадлежит эта бирка (например 249)\n\n/cancel — отмена | /menu — меню");
                    return;
                }

                // Default: search by QR
                $n = $calves->findCalfByQr($code);
                if (!$n || !$calves->existsCalf($n)) {
                    $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId0]);
                    flow_show($config, $chatId, $flowId0, "Не нашёл телёнка по QR. Проверь бирку/код и попробуй ещё раз.\n\n/menu — меню");
                    return;
                }


// If scan was initiated from a group: send result back to origin chat
$originChatId = 0;
$originUser = $user ? '@'.$user : ('ID '.$userId);
if ($st0 && (string)($st0['action'] ?? '') === 'scan_qr') {
    $pl = is_array($st0['payload'] ?? null) ? $st0['payload'] : [];
    $originChatId = (int)($pl['origin_chat_id'] ?? 0);
    if ($originChatId !== 0) {
        $btn = null;
        if (!empty($config['bot_username'])) {
            $btn = [
                'inline_keyboard' => [[
                    ['text' => "Открыть карточку №{$n}", 'url' => 'https://t.me/' . (string)$config['bot_username'] . '?start=calf_' . (int)$n]
                ]]
            ];
        }
        $msgText = "📷 QR считан ({$originUser})\nНайден телёнок №{$n}.";
        $extra = [];
        if (is_array($btn)) $extra['reply_markup'] = json_encode($btn, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        tg_send($config['bot_token'], $originChatId, $msgText, $extra);
    }
}

                $states->clear($chatId, $userId);
                $ctx = [
                    'config' => $config,
                    'pdo' => $pdo,
                    'states' => $states,
                    'calves' => $calves,
                    'alerts' => $alerts,
                    'chatId' => $chatId,
                    'userId' => $userId,
                    'user' => $user,
                ];
                $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId0]);
                screen_show($config, $chatId, $flowId0, 'calf_view', $ctx, ['n' => $n]);
                return;
            }
        }
        // if something else came, ignore
        return;
    }

    // ---------- /ask (AI assistant) ----------
    // Supports:
    //  - /ask <question>
    //  - /ask as reply to message (text/voice/photo)
    //  - photo with caption "/ask ..."
    //  - voice -> transcript + buttons to save event
    if (!empty($msg['caption']) && is_ask_command_text((string)$msg['caption'])) {
        // Photo with caption command
        $text = (string)$msg['caption'];
    }

    if ($text !== '' && is_ask_command_text($text)) {
        if (empty($msg['photo'])) { safe_delete($config, $chatId, $userMsgId); }

        $query = get_ask_query($text);

        // Determine source message for media or text
        $src = $msg['reply_to_message'] ?? null;

        // If no reply and query empty, use last user media/text from log (within 10 minutes)
        if (!$src && trim($query) === '' && isset($chatlog)) {
            $last = $chatlog->findLastMediaMessage($chatId, $userId, ['voice','photo','text'], 600);
            if ($last) {
                $src = [
                    'message_id' => (int)$last['message_id'],
                    'voice' => ($last['msg_type']==='voice') ? ['file_id'=>$last['file_id']] : null,
                    'photo' => ($last['msg_type']==='photo') ? [['file_id'=>$last['file_id']]] : null,
                    'text'  => ($last['msg_type']==='text') ? $last['text'] : null,
                    'caption' => $last['caption'] ?? null,
                ];
            }
        }

        $sourceText = '';
        $imageDataUrl = null;

        // Voice source
        if ($src && !empty($src['voice']['file_id'])) {
            $fid = (string)$src['voice']['file_id'];
            $file = tg_get_file($config['bot_token'], $fid);
            if (!$file || empty($file['file_path'])) {
                tg_send($config['bot_token'], $chatId, "Не смог получить голосовое.");
                return;
            }
            $tmp = sys_get_temp_dir() . '/tg_voice_' . $chatId . '_' . time() . '.ogg';
            if (!tg_download_file($config['bot_token'], (string)$file['file_path'], $tmp)) {
                tg_send($config['bot_token'], $chatId, "Не смог скачать голосовое.");
                return;
            }

            if (empty($config['openai']['api_key'])) {
                tg_send($config['bot_token'], $chatId, "Для расшифровки голосовых нужен ключ OpenAI (openai.api_key в config.php).");
                @unlink($tmp);
                return;
            }

            $tr = $ai->transcribe($tmp, 'ферма, телёнок, температура, вес, укол');
            @unlink($tmp);
            if (!$tr['ok']) {
                tg_send($config['bot_token'], $chatId, "Ошибка расшифровки: " . ($tr['error'] ?? ''));
                return;
            }
            $sourceText = $tr['text'] ?? '';
            if (isset($chatlog)) $chatlog->saveTranscript($chatId, (int)($src['message_id'] ?? 0), $sourceText);
            if (trim($query) === '') $query = $sourceText;
        }

        // Photo source
        if ($src && !empty($src['photo']) && is_array($src['photo'])) {
            $sizes = $src['photo'];
            $best = end($sizes);
            $fid = is_array($best) ? (string)($best['file_id'] ?? '') : '';
            if ($fid !== '') {
                $file = tg_get_file($config['bot_token'], $fid);
                if ($file && !empty($file['file_path'])) {
                    $ext = pathinfo((string)$file['file_path'], PATHINFO_EXTENSION);
                    $tmp = sys_get_temp_dir() . '/tg_photo_' . $chatId . '_' . time() . '.' . ($ext ?: 'jpg');
                    if (tg_download_file($config['bot_token'], (string)$file['file_path'], $tmp)) {
                        if (empty($config['openai']['api_key'])) {
                            tg_send($config['bot_token'], $chatId, "Для анализа фото нужен ключ OpenAI (openai.api_key в config.php).");
                            @unlink($tmp);
                            return;
                        }
                        $imageDataUrl = $ai->dataUrlFromImage($tmp);
                        @unlink($tmp);
                    }
                }
            }
        }

        // Reply text source
        if ($src && empty($sourceText)) {
            $sourceText = (string)($src['text'] ?? ($src['caption'] ?? ''));
            if (trim($query) === '') $query = $sourceText;
        }

        // If image is present, keep classic AI path (no DB agent)
        if ($imageDataUrl) {
            $system = "Ты — помощник фермы. Отвечай по-русски, чётко и по делу.\n";
            if (empty($config['openai']['api_key'])) {
                tg_send($config['bot_token'], $chatId, "⚠️ AI не подключён (openai.api_key пустой в config.php).\nВопрос: {$query}");
                return;
            }
            $ans = $ai->answerText($system, $query, $imageDataUrl);
            if (!$ans['ok']) {
                tg_send($config['bot_token'], $chatId, "Ошибка AI: " . ($ans['error'] ?? ''));
                return;
            }
            $reply = trim((string)($ans['text'] ?? ''));
            if ($reply === '') $reply = 'Пустой ответ.';
            tg_send($config['bot_token'], $chatId, $reply, ['protect_content' => true]);
            return;
        }

        // DB agent for text questions (read + controlled writes)
        if (!isset($dbAgent) || empty($config['openai']['api_key'])) {
            tg_send($config['bot_token'], $chatId, "⚠️ AI/DB агент не подключён. Проверь openai.api_key в config.php.");
            return;
        }

        $aiCtx = build_ai_context_payload($chatlog ?? null, $chatId, 14, $msg);
        $r = $dbAgent->handleText($chatId, $chatType, $userId, $user ? ('@'.$user) : null, $query, $aiCtx);
        if (($r['mode'] ?? '') === 'confirm') {
            $mid = (int)($r['mutation_id'] ?? 0);
            $kbd = [
                'inline_keyboard' => [
                    [
                        ['text' => '✅ Подтвердить', 'callback_data' => "ai_apply|{$mid}"],
                        ['text' => '✖️ Отмена', 'callback_data' => "ai_cancel|{$mid}"],
                    ],
                ],
            ];
            tg_send($config['bot_token'], $chatId, (string)$r['text'], [
                'reply_markup' => json_encode($kbd, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
                'protect_content' => true,
            ]);
            return;
        }

        if (($r['mode'] ?? '') === 'answer') {
            tg_send($config['bot_token'], $chatId, (string)$r['text'], ['protect_content' => true]);
            return;
        }

        tg_send($config['bot_token'], $chatId, "Ошибка AI/DB: " . (string)($r['error'] ?? ''));
        return;
    }

    // ---------- Voice: answer question with AI or propose save event ----------
    if (!empty($msg['voice']['file_id']) && (
        $chatType === 'private'
        || in_array($chatId, [$config['chat_work'], $config['chat_control'], $config['chat_dialog']], true)
        || in_array($chatType, ['group', 'supergroup'], true)
    )) {
        if (!empty($config['openai']['api_key'])) {
            $fid = (string)$msg['voice']['file_id'];
            $file = tg_get_file($config['bot_token'], $fid);
            if ($file && !empty($file['file_path'])) {
                $tmp = sys_get_temp_dir() . '/tg_voice_' . $chatId . '_' . time() . '.ogg';
                if (tg_download_file($config['bot_token'], (string)$file['file_path'], $tmp)) {
                    $tr = $ai->transcribe($tmp, 'ферма, телёнок, температура, вес, укол');
                    @unlink($tmp);
                    if ($tr['ok']) {
                        $textTr = trim((string)($tr['text'] ?? ''));
                        if ($textTr !== '') {
                            if (isset($chatlog)) $chatlog->saveTranscript($chatId, $userMsgId, $textTr);

                            $aiQuery = normalize_ai_query_text($textTr);
                            if ($aiQuery === '') $aiQuery = $textTr;

                            if (isset($dbAgent) && is_question_like($textTr)) {
                                $aiCtx = build_ai_context_payload($chatlog ?? null, $chatId, 14, $msg, $textTr);
                                $r = $dbAgent->handleText($chatId, $chatType, $userId, $user ? ('@'.$user) : null, $aiQuery, $aiCtx);
                                if (($r['mode'] ?? '') === 'confirm') {
                                    $mid = (int)($r['mutation_id'] ?? 0);
                                    $kbd = [
                                        'inline_keyboard' => [
                                            [
                                                ['text' => '✅ Подтвердить', 'callback_data' => "ai_apply|{$mid}"],
                                                ['text' => '✖️ Отмена', 'callback_data' => "ai_cancel|{$mid}"],
                                            ],
                                        ],
                                    ];
                                    tg_send($config['bot_token'], $chatId, (string)$r['text'], [
                                        'reply_markup' => json_encode($kbd, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
                                        'protect_content' => true,
                                    ]);
                                    return;
                                }
                                if (($r['mode'] ?? '') === 'answer') {
                                    tg_send($config['bot_token'], $chatId, (string)$r['text'], ['protect_content' => true]);
                                    return;
                                }
                            }

                            $st = $pdo->prepare("INSERT INTO ai_pending(chat_id,user_id,source_message_id,kind,transcript,created_at) VALUES (?,?,?,?,?,NOW())");
                            $st->execute([$chatId, $userId, $userMsgId, 'voice', $textTr]);
                            $pid = (int)$pdo->lastInsertId();

                            $kbd = [
                                'inline_keyboard' => [
                                    [
                                        ['text'=>'✅ Темп', 'callback_data'=>"ai_evt|temp|{$pid}"],
                                        ['text'=>'✅ Вес',  'callback_data'=>"ai_evt|weight|{$pid}"],
                                    ],
                                    [
                                        ['text'=>'✅ Укол', 'callback_data'=>"ai_evt|treatment|{$pid}"],
                                        ['text'=>'✅ Заметка','callback_data'=>"ai_evt|note|{$pid}"],
                                    ],
                                    [
                                        ['text'=>'✖️ Не записывать', 'callback_data'=>'noop'],
                                    ],
                                ],
                            ];

                            tg_send($config['bot_token'], $chatId, "🎙 Расшифровка: {$textTr}

Записать в журнал?", [
                                'reply_markup' => json_encode($kbd, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
                                'protect_content' => true,
                            ]);
                        }
                    }
                }
            }
        }
    }

    $parsed = Parser::parseText($text);
    @file_put_contents(__DIR__.'/../logs/parsed.log', date('c')." chat={$chatId} text=[".$text."] parsed=".json_encode($parsed, JSON_UNESCAPED_UNICODE)."\n", FILE_APPEND);

    // Удаляем команды пользователя, чтобы было чисто
    if ($parsed['type'] === 'sys') safe_delete($config, $chatId, $userMsgId);

    // ===== Bot API 9.5: Member tags (/tag, /tagclear) =====
    if ($parsed['type'] === 'sys' && in_array($parsed['cmd'], ['tag','tagclear'], true)) {
        // Only makes sense in groups/supergroups
        if (!in_array($chatType, ['group','supergroup'], true)) {
            tg_send($config['bot_token'], $chatId, "Команда доступна только в группах.");
            return;
        }

        // Permission check: caller must be admin and have can_manage_tags
        $cm = tg_get_chat_member($config['bot_token'], $chatId, $userId);
        $m = is_array($cm) ? ($cm['result'] ?? null) : null;
        $status = is_array($m) ? (string)($m['status'] ?? '') : '';
        $can = false;
        if ($status === 'creator') {
            $can = true;
        } elseif ($status === 'administrator') {
            // Bot API docs: needs can_manage_tags right
            $can = (bool)($m['can_manage_tags'] ?? false);
        }

        if (!$can) {
            tg_send($config['bot_token'], $chatId, "Нет прав. Нужны права администратора (can_manage_tags).", [
                'protect_content' => true,
            ]);
            return;
        }

        // Determine target user
        $targetId = 0;
        if (!empty($msg['reply_to_message']['from']['id'])) {
            $targetId = (int)$msg['reply_to_message']['from']['id'];
        } else {
            // Optional: /tag <user_id> <tag>
            $p = trim((string)($parsed['payload'] ?? ''));
            if (preg_match('/^(\d+)\s+(.+)$/u', $p, $mm)) {
                $targetId = (int)$mm[1];
                $parsed['payload'] = trim((string)$mm[2]);
            }
        }

        if ($targetId <= 0) {
            tg_send($config['bot_token'], $chatId, "Использование: ответь на сообщение человека и напиши /tag Роль (например /tag Вет).\nЛибо /tag 123456789 Роль", [
                'protect_content' => true,
            ]);
            return;
        }

        $tag = null;
        if ($parsed['cmd'] === 'tagclear') {
            $tag = '';
        } else {
            $tag = trim((string)($parsed['payload'] ?? ''));
            if ($tag === '' || $tag === '-' || mb_strtolower($tag) === 'clear') {
                $tag = '';
            }
            // Hard limit: 0-16 chars, emoji not allowed (Telegram will reject anyway)
            if (mb_strlen($tag) > 16) {
                $tag = mb_substr($tag, 0, 16);
            }
        }

        $res = tg_set_chat_member_tag($config['bot_token'], $chatId, $targetId, $tag);
        if (is_array($res) && ($res['ok'] ?? false) === true) {
            $txt = ($tag === '') ? '✅ Тег очищен.' : "✅ Тег установлен: {$tag}";
            tg_send($config['bot_token'], $chatId, $txt);
        } else {
            tg_send($config['bot_token'], $chatId, "Не получилось установить тег. Проверь, что бот — админ с can_manage_tags.", [
                'protect_content' => true,
            ]);
        }
        return;
    }

    // sys команды
    if ($parsed['type'] === 'sys' && in_array($parsed['cmd'], ['menu','krs_menu','krs_find','krs_data','finance_menu','payroll_menu','report_menu','ai_help','resetmenu'], true)) {
        if ($parsed['cmd'] === 'menu') {
            if (!throttle_allow($pdo, $chatId, 'menu', 2)) {
                return;
            }
            show_menu($config, $pdo, $states, $calves, $chatId, $userId, $chatType);
            ensure_reply_menu_keyboard($pdo, $config, $chatId);
            return;
        }

        if ($parsed['cmd'] === 'resetmenu') {
            $states->clear($chatId, $userId);
            show_menu($config, $pdo, $states, $calves, $chatId, $userId, $chatType, true);
            ensure_reply_menu_keyboard($pdo, $config, $chatId);
            return;
        }

        $st0 = $states->get($chatId, $userId);
        $flowId0 = get_flow_id($st0);
        if ($flowId0 <= 0) {
            show_menu($config, $pdo, $states, $calves, $chatId, $userId, $chatType);
            $st0 = $states->get($chatId, $userId);
            $flowId0 = get_flow_id($st0);
        }

        $ctx = [
            'config' => $config,
            'pdo' => $pdo,
            'states' => $states,
            'calves' => $calves,
            'alerts' => $alerts,
            'finance' => $finance ?? null,
            'payroll' => $payroll ?? null,
            'chatId' => $chatId,
            'chatType' => $chatType,
            'userId' => $userId,
            'user' => $user,
        ];

        $map = [
            'krs_menu' => 'menu_krs',
            'krs_find' => 'krs_find',
            'krs_data' => 'krs_data',
            'finance_menu' => 'finance_menu',
            'payroll_menu' => 'payroll_menu',
            'report_menu' => 'report_menu',
            'ai_help' => 'ai_help',
        ];
        $screen = $map[$parsed['cmd']] ?? 'menu';

        $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId0]);
        screen_show($config, $chatId, $flowId0, $screen, $ctx);
        ensure_reply_menu_keyboard($pdo, $config, $chatId);
        return;
    }

    // AI triggers in free text: Макс / ИИ / спроси у ИИ / бот
    if ($parsed['type'] === 'free' && (
        is_ai_trigger_text($text)
        || ($chatType === 'private' && is_question_like($text))
        || (!empty($msg['reply_to_message']['from']['is_bot']) && is_question_like($text))
    )) {
        $stAi = $states->get($chatId, $userId);
        $actionAi = (string)($stAi['action'] ?? '');
        if ($actionAi === '' || $actionAi === 'idle') {
            if (!isset($dbAgent) || empty($config['openai']['api_key'])) {
                tg_send($config['bot_token'], $chatId, "⚠️ AI/DB агент не подключён. Проверь openai.api_key в config.php.");
                return;
            }
            $queryAi = normalize_ai_query_text($text);
            if ($queryAi === '') $queryAi = $text;
            $aiCtx = build_ai_context_payload($chatlog ?? null, $chatId, 14, $msg);
            $r = $dbAgent->handleText($chatId, $chatType, $userId, $user ? ('@'.$user) : null, $queryAi, $aiCtx);
            if (($r['mode'] ?? '') === 'confirm') {
                $mid = (int)($r['mutation_id'] ?? 0);
                $kbd = [
                    'inline_keyboard' => [
                        [
                            ['text' => '✅ Подтвердить', 'callback_data' => "ai_apply|{$mid}"],
                            ['text' => '✖️ Отмена', 'callback_data' => "ai_cancel|{$mid}"],
                        ],
                    ],
                ];
                tg_send($config['bot_token'], $chatId, (string)$r['text'], [
                    'reply_markup' => json_encode($kbd, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
                    'protect_content' => true,
                ]);
                return;
            }
            if (($r['mode'] ?? '') === 'answer') {
                tg_send($config['bot_token'], $chatId, (string)$r['text'], ['protect_content' => true]);
                return;
            }
            tg_send($config['bot_token'], $chatId, "Ошибка AI/DB: " . (string)($r['error'] ?? ''));
            return;
        }
    }

    if ($parsed['type'] === 'sys' && $parsed['cmd'] === 'panel') {
        $textPanel = "📌 Панель фермы\n\nБыстрые кнопки ниже.";
        $markup = json_encode(kb_group_panel(), JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        $kvKey = 'panel_msg:' . $chatId;
        $msgId = (int)(kv_get($pdo, $kvKey, '0') ?? '0');

        $ok = false;
        if ($msgId > 0) {
            $edit = tg_edit($config['bot_token'], $chatId, $msgId, $textPanel, ['reply_markup' => $markup]);
            $ok = is_array($edit) && (($edit['ok'] ?? false) === true);
        }

        if (!$ok) {
            $sent = tg_send($config['bot_token'], $chatId, $textPanel, ['reply_markup' => $markup, 'protect_content' => true]);
            if (is_array($sent) && (($sent['ok'] ?? false) === true)) {
                $msgId = (int)($sent['result']['message_id'] ?? 0);
                if ($msgId > 0) {
                    kv_set($pdo, $kvKey, (string)$msgId);
                    if (in_array($chatType, ['group', 'supergroup'], true)) {
                        tg_api($config['bot_token'], 'pinChatMessage', [
                            'chat_id' => $chatId,
                            'message_id' => $msgId,
                            'disable_notification' => true,
                        ]);
                    }
                }
            }
        } else {
            if (in_array($chatType, ['group', 'supergroup'], true) && $msgId > 0) {
                tg_api($config['bot_token'], 'pinChatMessage', [
                    'chat_id' => $chatId,
                    'message_id' => $msgId,
                    'disable_notification' => true,
                ]);
            }
        }

        ensure_reply_menu_keyboard($pdo, $config, $chatId);
        return;
    }

    if ($parsed['type'] === 'sys' && $parsed['cmd'] === 'hide_keyboard') {
        hide_reply_menu_keyboard($pdo, $config, $chatId);
        return;
    }

    if ($parsed['type'] === 'sys' && $parsed['cmd'] === 'start') {
        // Support deep-link QR payloads: /start qr_<code>
        $payload = (string)($parsed['payload'] ?? '');
        if ($payload !== '' && str_starts_with($payload, 'qr_')) {
            $code = substr($payload, 3);
            $n = $calves->findCalfByQr($code);
            if ($n && $calves->existsCalf($n)) {
                $states->clear($chatId, $userId);
                $ctx = [
                    'config' => $config,
                    'pdo' => $pdo,
                    'states' => $states,
                    'calves' => $calves,
                    'alerts' => $alerts,
                    'chatId' => $chatId,
                    'userId' => $userId,
                    'user' => $user,
                ];
                // Show via master flow
                $st0 = $states->get($chatId, $userId);
                $flowId0 = get_flow_id($st0);
                if ($flowId0 <= 0) {
                    // create menu flow first
                    show_menu($config, $pdo, $states, $calves, $chatId, $userId, $chatType);
                    $st0 = $states->get($chatId, $userId);
                    $flowId0 = get_flow_id($st0);
                }
                $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId0]);
                screen_show($config, $chatId, $flowId0, 'calf_view', $ctx, ['n' => $n]);
                return;
            }
            tg_send($config['bot_token'], $chatId, "Не нашёл телёнка по этому QR. Нажми /menu");
            return;
        }

        // Bridge: /start scanqr (from group -> open private -> show WebApp scanner)
        if ($payload === 'scanqr' || str_starts_with($payload, 'scanqr')) {
            // ensure we are in private chat
            if ($chatType !== '' && $chatType !== 'private') {
                tg_send($config['bot_token'], $chatId, "Для скана QR открой личный чат с ботом.");
                return;
            }

            $st = $states->get($chatId, $userId);
            $flowId = get_flow_id($st);
            if ($flowId <= 0) {
                show_menu($config, $pdo, $states, $calves, $chatId, $userId, $chatType);
                $st = $states->get($chatId, $userId);
                $flowId = get_flow_id($st);
            }

            if (empty($config['webapp_qr_url'])) {
                flow_show($config, $chatId, $flowId, "Сканер не настроен (webapp_qr_url пустой). Нажми /menu");
                return;
            }

            // Keep current state payload (origin chat) if already stored by group button
            $payloadArr = is_array($st['payload'] ?? null) ? $st['payload'] : [];
            $payloadArr['flow_msg_id'] = $flowId;

            $states->set($chatId, $userId, 'scan_qr', 1, null, $payloadArr);
            flow_show(
                $config,
                $chatId,
                $flowId,
                "📷 Скан QR

Нажми кнопку ниже и отсканируй бирку.
После скана результат отправлю обратно (если запускали из группы).

/cancel — отмена | /menu — меню",
                ['inline_keyboard' => [[['text' => '📷 Открыть сканер', 'web_app' => ['url' => (string)$config['webapp_qr_url']]]]]]
            );
            return;
        }

        // Deep-link: /start calf_<number>
        if ($payload !== '' && str_starts_with($payload, 'calf_')) {
            $n = (int)substr($payload, 5);
            if ($n > 0 && $calves->existsCalf($n)) {
                $states->clear($chatId, $userId);
                $ctx = [
                    'config' => $config,
                    'pdo' => $pdo,
                    'states' => $states,
                    'calves' => $calves,
                    'alerts' => $alerts,
                    'chatId' => $chatId,
                    'chatType' => $chatType,
                    'userId' => $userId,
                    'user' => $user,
                ];
                $st0 = $states->get($chatId, $userId);
                $flowId0 = get_flow_id($st0);
                if ($flowId0 <= 0) {
                    show_menu($config, $pdo, $states, $calves, $chatId, $userId, $chatType);
                    $st0 = $states->get($chatId, $userId);
                    $flowId0 = get_flow_id($st0);
                }
                $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId0]);
                screen_show($config, $chatId, $flowId0, 'calf_view', $ctx, ['n' => $n]);
                return;
            }
            tg_send($config['bot_token'], $chatId, "Не нашёл телёнка. Нажми /menu");
            return;
        }

        // default start
        if ((int)$config['chat_work'] !== 0 && $chatId === (int)$config['chat_work']) {
            // in work chat we keep quiet; use /menu only
            return;
        }
        tg_send($config['bot_token'], $chatId, "Нажми /menu");
        ensure_reply_menu_keyboard($pdo, $config, $chatId);
        return;
    }

    if ($parsed['type'] === 'sys' && $parsed['cmd'] === 'cancel') {
        $st = $states->get($chatId, $userId);
        $flowId = get_flow_id($st);
        $states->clear($chatId, $userId);
        if ($flowId > 0) flow_show($config, $chatId, $flowId, "Ок, отменил ✅\n\n/menu — меню");
        return;
    }

    // шаговый режим
    $st = $states->get($chatId, $userId);
    if ($st) {
        // удаляем ввод пользователя в сессии
        if (empty($msg['photo'])) { safe_delete($config, $chatId, $userMsgId); }

        $action  = (string)$st['action'];
        $step    = (int)$st['step'];
        $payload = is_array($st['payload'] ?? null) ? $st['payload'] : [];
        $flowId  = (int)($payload['flow_msg_id'] ?? 0);

        // --- Special flows (not in actions_registry) ---

        // ===== Finance: add expense =====
        if ($action === 'fin_add' && $step === 2) {
            // amount
            $v = trim($text);
            if (!preg_match('/^[0-9]+([.,][0-9]+)?$/', $v)) {
                flow_show($config, $chatId, $flowId, "Сумма должна быть числом, например 1200 или 1200.50\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $amount = (float)str_replace(',', '.', $v);
            if ($amount <= 0) {
                flow_show($config, $chatId, $flowId, "Сумма должна быть больше нуля.\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $payload['amount'] = $amount;
            $states->set($chatId, $userId, 'fin_add', 3, null, $payload);
            flow_show($config, $chatId, $flowId, "Комментарий (опционально), например: солярка/корм\n\nМожно пропустить.", kb_finance_comment_skip());
            return;
        }

        if ($action === 'fin_add' && $step === 3) {
            /** @var FinanceService|null $fin */
            $fin = $finance ?? null;
            if (!($fin instanceof FinanceService)) {
                flow_show($config, $chatId, $flowId, "Финансы недоступны. /menu");
                return;
            }
            $catId = (int)($payload['cat_id'] ?? 0);
            $amount = (float)($payload['amount'] ?? 0);
            $comment = norm($text);
            $fin->addExpense($catId, $amount, $comment, $userId);
            $states->clear($chatId, $userId);
            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'finance' => $finance ?? null,
                'payroll' => $payroll ?? null,
                'chatId' => $chatId,
                'chatType' => $chatType,
                'userId' => $userId,
                'user' => $user,
            ];
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            screen_show($config, $chatId, $flowId, 'finance_menu', $ctx);
            return;
        }

        if ($action === 'fin_cat_add' && $step === 1) {
            /** @var FinanceService|null $fin */
            $fin = $finance ?? null;
            if (!($fin instanceof FinanceService) || !$fin->isInstalled()) {
                flow_show($config, $chatId, $flowId, "Финансы недоступны. /menu");
                return;
            }
            $name = norm($text);
            if (u_strlen($name) < 2) {
                flow_show($config, $chatId, $flowId, "Слишком коротко. Введи название категории (например: Солярка)\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $fin->addCategory($name, 'expense');
            $states->clear($chatId, $userId);
            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'finance' => $finance ?? null,
                'payroll' => $payroll ?? null,
                'chatId' => $chatId,
                'chatType' => $chatType,
                'userId' => $userId,
                'user' => $user,
            ];
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            screen_show($config, $chatId, $flowId, 'finance_categories', $ctx);
            return;
        }

        // ===== Payroll =====
        if ($action === 'pay_emp_add' && $step === 1) {
            /** @var PayrollService|null $pay */
            $pay = $payroll ?? null;
            if (!($pay instanceof PayrollService) || !$pay->isInstalled()) {
                flow_show($config, $chatId, $flowId, "Зарплата недоступна. /menu");
                return;
            }
            $name = norm($text);
            if (u_strlen($name) < 2) {
                flow_show($config, $chatId, $flowId, "Слишком коротко. Пример: Иван\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $pay->addEmployee($name, null, null);
            $states->clear($chatId, $userId);
            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'finance' => $finance ?? null,
                'payroll' => $payroll ?? null,
                'chatId' => $chatId,
                'chatType' => $chatType,
                'userId' => $userId,
                'user' => $user,
            ];
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            screen_show($config, $chatId, $flowId, 'payroll_employees', $ctx);
            return;
        }

        if ($action === 'pay_shift' && $step === 3) {
            // other amount input
            $v = trim($text);
            if (!preg_match('/^\d+([.,]\d+)?$/', $v)) {
                flow_show($config, $chatId, $flowId, "Сумма должна быть числом, например 800\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $amount = (float)str_replace(',', '.', $v);
            if ($amount <= 0) {
                flow_show($config, $chatId, $flowId, "Сумма должна быть больше нуля.\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $payload['amount'] = $amount;
            $states->set($chatId, $userId, 'pay_shift', 4, null, $payload);
            flow_show($config, $chatId, $flowId, "Комментарий (опционально), например: чистка/кормёжка\n\nМожно пропустить.", kb_payroll_comment_skip('pay_shift_comment_skip'));
            return;
        }

        if ($action === 'pay_shift' && $step === 4) {
            /** @var PayrollService|null $pay */
            $pay = $payroll ?? null;
            if (!($pay instanceof PayrollService)) { flow_show($config, $chatId, $flowId, "Зарплата недоступна. /menu"); return; }
            $empId = (int)($payload['emp_id'] ?? 0);
            $amount = (float)($payload['amount'] ?? 0);
            $comment = norm($text);
            $pay->addAccrual($empId, $amount, $comment, $userId, date('Y-m-d'));
            $states->clear($chatId, $userId);
            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'finance' => $finance ?? null,
                'payroll' => $payroll ?? null,
                'chatId' => $chatId,
                'chatType' => $chatType,
                'userId' => $userId,
                'user' => $user,
            ];
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            screen_show($config, $chatId, $flowId, 'payroll_menu', $ctx);
            return;
        }

        if ($action === 'pay_payout' && $step === 3) {
            // other amount input
            $v = trim($text);
            if (!preg_match('/^\d+([.,]\d+)?$/', $v)) {
                flow_show($config, $chatId, $flowId, "Сумма должна быть числом, например 1000\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $amount = (float)str_replace(',', '.', $v);
            if ($amount <= 0) {
                flow_show($config, $chatId, $flowId, "Сумма должна быть больше нуля.\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $payload['amount'] = $amount;
            $states->set($chatId, $userId, 'pay_payout', 4, null, $payload);
            flow_show($config, $chatId, $flowId, "Комментарий (опционально), например: аванс/расчёт\n\nМожно пропустить.", kb_payroll_comment_skip('pay_payout_comment_skip'));
            return;
        }

        if ($action === 'pay_payout' && $step === 4) {
            /** @var PayrollService|null $pay */
            $pay = $payroll ?? null;
            /** @var FinanceService|null $fin */
            $fin = $finance ?? null;
            if (!($pay instanceof PayrollService) || !($fin instanceof FinanceService)) { flow_show($config, $chatId, $flowId, "Модуль недоступен. /menu"); return; }
            $empId = (int)($payload['emp_id'] ?? 0);
            $amount = (float)($payload['amount'] ?? 0);
            $comment = norm($text);
            $payoutId = $pay->addPayout($empId, $amount, $comment, $userId, date('Y-m-d'));
            $salaryCat = $fin->ensureExpenseCategory('Зарплата');
            if ($salaryCat) {
                $emp = $pay->getEmployee($empId);
                $empName = trim((string)($emp['name'] ?? ''));
                $baseComment = $comment !== '' ? $comment : 'Выплата зарплаты';
                if ($empName !== '') {
                    $baseComment = 'Выплата зарплаты: ' . $empName . ($comment !== '' ? ' — ' . $comment : '');
                }
                $fin->addExpense((int)$salaryCat, $amount, $baseComment, $userId, $empId, null, 'payroll_payout', $payoutId);
            }
            $states->clear($chatId, $userId);
            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'finance' => $finance ?? null,
                'payroll' => $payroll ?? null,
                'chatId' => $chatId,
                'chatType' => $chatType,
                'userId' => $userId,
                'user' => $user,
            ];
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            screen_show($config, $chatId, $flowId, 'payroll_menu', $ctx);
            return;
        }

        if ($action === 'calf_search' && $step === 1) {
            $num = trim($text);
            if (!preg_match('/^\d+$/', $num)) {
                flow_show($config, $chatId, $flowId, "Нужен номер телёнка цифрами, например: 249\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $calf = (int)$num;

            if (!$calves->existsCalf($calf)) {
                // keep the search state
                flow_show($config, $chatId, $flowId, "Телёнка №{$calf} нет. Проверь номер или добавь телёнка кнопкой ➕\n\n/cancel — отмена | /menu — меню");
                return;
            }

            $states->clear($chatId, $userId);

            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'chatId' => $chatId,
                'userId' => $userId,
                'user' => $user,
            ];

            // keep master flow
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            screen_show($config, $chatId, $flowId, 'calf_view', $ctx, ['n' => $calf]);
            return;
        }

        if ($action === 'calf_qr_search' && $step === 1) {
            $code = norm($text);
            if ($code === '') {
                flow_show($config, $chatId, $flowId, "Пришли QR-код текстом (строкой)\n\n/cancel — отмена | /menu — меню");
                return;
            }
            // Accept deep links too
            if (preg_match('~qr_([A-Za-z0-9_-]+)~', $code, $m)) {
                $code = $m[1];
            }
            $n = $calves->findCalfByQr($code);
            if (!$n || !$calves->existsCalf($n)) {
                flow_show($config, $chatId, $flowId, "Не нашёл телёнка по QR. Проверь код и попробуй ещё раз.\n\n/cancel — отмена | /menu — меню");
                return;
            }

            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'chatId' => $chatId,
                'userId' => $userId,
                'user' => $user,
            ];

            $states->clear($chatId, $userId);
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            screen_show($config, $chatId, $flowId, 'calf_view', $ctx, ['n' => $n]);
            return;
        }

        if ($action === 'qr_bind' && $step === 1) {
            // Manual QR code entry (without camera)
            $code = norm($text);
            if ($code === '') {
                flow_show($config, $chatId, $flowId, "Пришли QR-код текстом (строкой) или нажми 📷 Сканировать бирку.\n\n/cancel — отмена | /menu — меню", kb_qr_bind());
                return;
            }
            if (preg_match('~qr_([A-Za-z0-9_-]+)~', $code, $m)) {
                $code = $m[1];
            }
            $payload['qr_code'] = $code;
            $payload['flow_msg_id'] = $flowId;
            $states->set($chatId, $userId, 'qr_bind', 2, null, $payload);
            flow_show($config, $chatId, $flowId, "🔗 Привязка бирки (QR)\n\nКод получен ✅\n\nТеперь введи номер телёнка, которому принадлежит эта бирка (например 249)\n\n/cancel — отмена | /menu — меню");
            return;
        }

        if ($action === 'qr_bind' && $step === 2) {
            $num = trim($text);
            $code = (string)($payload['qr_code'] ?? '');
            if ($code === '') {
                $states->set($chatId, $userId, 'qr_bind', 1, null, ['flow_msg_id' => $flowId]);
                flow_show($config, $chatId, $flowId, "Сессия сбилась: нет QR кода. Отсканируй/пришли код ещё раз.", kb_qr_bind());
                return;
            }
            if (!preg_match('/^\d+$/', $num)) {
                flow_show($config, $chatId, $flowId, "Нужен номер телёнка цифрами, например: 249\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $calf = (int)$num;

            if (!$calves->existsCalf($calf)) {
                flow_show($config, $chatId, $flowId, "Телёнка №{$calf} нет в базе.\n\nПроверь номер и введи ещё раз.\n\n/cancel — отмена | /menu — меню");
                return;
            }

            $old = $calves->findCalfByQr($code);
            if ($old && $old !== $calf && $calves->existsCalf($old)) {
                // Need confirmation to re-bind
                $payload2 = [
                    'flow_msg_id' => $flowId,
                    'qr_code' => $code,
                    'old_calf' => $old,
                    'new_calf' => $calf,
                ];
                $states->set($chatId, $userId, 'qr_bind_confirm', 1, null, $payload2);
                flow_show(
                    $config,
                    $chatId,
                    $flowId,
                    "⚠️ Этот QR уже привязан к телёнку №{$old}.\n\nПерепривязать к №{$calf}?",
                    kb_qr_bind_confirm($old, $calf)
                );
                return;
            }

            // Bind code to calf
            $calves->setQrCode($calf, $code, $chatId, $user);

            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'chatId' => $chatId,
                'userId' => $userId,
                'user' => $user,
            ];
            $states->clear($chatId, $userId);
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            flow_show($config, $chatId, $flowId, "✅ Привязал QR к телёнку №{$calf}");
            screen_show($config, $chatId, $flowId, 'calf_view', $ctx, ['n' => $calf]);
            return;
        }

        if ($action === 'calf_add' && $step === 1) {
            $num = trim($text);
            if (!preg_match('/^\d+$/', $num)) {
                flow_show($config, $chatId, $flowId, "Нужен номер КРС цифрами, например: 249

/cancel — отмена | /menu — меню");
                return;
            }

            $calf = (int)$num;
            $calves->ensureCalf($calf);
            $calves->setLifeStatus($calf, 'active', $chatId, $user);

            // Auto-generate QR for newly added calf (if missing)
            $qr = $calves->getQrCode($calf);
            if (!$qr) {
                $code = 'C' . $calf . '-' . substr(strtoupper(base_convert((string)random_int(100000, 999999999), 10, 36)), 0, 6);
                $calves->setQrCode($calf, $code, $chatId, $user);
            }

            // Step 2: optional birth date
            $payload['flow_msg_id'] = $flowId;
            $payload['calf'] = $calf;
            $states->set($chatId, $userId, 'calf_add', 2, $calf, $payload);

            flow_show(
                $config,
                $chatId,
                $flowId,
                "🎂 Дата рождения (необязательно)

КРС №{$calf}

Введи дату (2026-02-20 или 20.02.2026)
или нажми «Пропустить».

/cancel — отмена | /menu — меню",
                [
                    'inline_keyboard' => [
                        [
                            ['text' => '⏭ Пропустить', 'callback_data' => cb_pack('calf_add_skip_birth')],
                        ],
                    ],
                ]
            );
            return;
        }

        if ($action === 'calf_add' && $step === 2) {
            $calf = (int)($payload['calf'] ?? 0);
            if ($calf <= 0) {
                $states->clear($chatId, $userId);
                flow_show($config, $chatId, $flowId, "Сессия добавления сбилась. /menu");
                return;
            }

            $raw = norm($text);
            $low = u_lower(trim($raw));
            if ($raw === '' || in_array($low, ['-', '—', 'пропустить', 'skip'], true)) {
                // treat as skip
                $ctx = [
                    'config' => $config,
                    'pdo' => $pdo,
                    'states' => $states,
                    'calves' => $calves,
                    'alerts' => $alerts,
                    'chatId' => $chatId,
                    'userId' => $userId,
                    'user' => $user,
                ];

                $states->clear($chatId, $userId);
                $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
                flow_show($config, $chatId, $flowId, "✅ Добавил КРС №{$calf}");
                screen_show($config, $chatId, $flowId, 'calf_view', $ctx, ['n' => $calf]);
                return;
            }

            $dt = DateTime::createFromFormat('Y-m-d', $raw) ?: DateTime::createFromFormat('d.m.Y', $raw);
            if (!$dt) {
                flow_show($config, $chatId, $flowId, "Дата должна быть в формате 2026-02-20 или 20.02.2026

/cancel — отмена | /menu — меню");
                return;
            }

            $birth = $dt->format('Y-m-d');
            $calves->addEvent($calf, 'birth', $birth, $chatId, $user);

            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'chatId' => $chatId,
                'userId' => $userId,
                'user' => $user,
            ];

            $states->clear($chatId, $userId);
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            flow_show($config, $chatId, $flowId, "✅ Добавил КРС №{$calf} (дата рождения {$birth})");
            screen_show($config, $chatId, $flowId, 'calf_view', $ctx, ['n' => $calf]);
            return;
        }

        if ($action === 'event_edit' && $step === 1) {
            $eventId = (int)($payload['event_id'] ?? 0);
            $returnCalf = (int)($payload['return_calf'] ?? 0);
            $returnPage = (int)($payload['return_page'] ?? 0);

            if ($eventId <= 0) {
                $states->clear($chatId, $userId);
                flow_show($config, $chatId, $flowId, "Сессия сбилась. /menu");
                return;
            }

            $ev = $calves->getEvent($eventId);
            if (!$ev) {
                $states->clear($chatId, $userId);
                flow_show($config, $chatId, $flowId, "Событие не найдено (возможно удалено). /menu");
                return;
            }

            $type = (string)($ev['type'] ?? '');
            $raw  = norm($text);
            if ($raw === '') {
                flow_show($config, $chatId, $flowId, "Пустое значение. Попробуй ещё раз.\n\n/cancel — отмена | /menu — меню");
                return;
            }

            // type-aware validation
            if (in_array($type, ['temp','weight'], true)) {
                if (!preg_match('/^[0-9]+([.,][0-9]+)?$/', $raw)) {
                    flow_show($config, $chatId, $flowId, "Значение должно быть числом (пример: 39.8)\n\n/cancel — отмена | /menu — меню");
                    return;
                }
                $raw = (string)((float)str_replace(',', '.', $raw));
            }

            if ($type === 'life') {
                $v = trim(u_lower($raw));
                if (!in_array($v, ['active','sold','dead','removed'], true)) {
                    flow_show($config, $chatId, $flowId, "Для статуса допустимо: active, sold, dead, removed\n\n/cancel — отмена | /menu — меню");
                    return;
                }
                $raw = $v;
            }

            $calves->updateEventValue($eventId, $raw);

            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'chatId' => $chatId,
                'userId' => $userId,
                'user' => $user,
            ];

            $states->clear($chatId, $userId);
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            flow_show($config, $chatId, $flowId, "✅ Обновил событие #{$eventId}");
            screen_show($config, $chatId, $flowId, 'event_view', $ctx, ['id' => $eventId, 'n' => $returnCalf ?: (int)$ev['calf_number'], 'p' => $returnPage]);
            return;
        }

        // --- Standard actions registry ---
        $reg = actions_registry();
        $def = $reg[$action] ?? null;
        if (!$def) {
            $states->clear($chatId, $userId);
            flow_show($config, $chatId, $flowId, "Сессия сбилась. /menu");
            return;
        }

        if ($step === 1) {
            $num = trim($text);
            if (!preg_match('/^\d+$/', $num)) {
                flow_show($config, $chatId, $flowId, "Нужен номер телёнка цифрами, например: 249\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $calf = (int)$num;
            $payload['flow_msg_id'] = $flowId;
            $states->set($chatId, $userId, $action, 2, $calf, $payload);

            if (!empty($def['status_mode'])) {
                // show full calf card
                $states->clear($chatId, $userId);
                $ctx = [
                    'config' => $config,
                    'pdo' => $pdo,
                    'states' => $states,
                    'calves' => $calves,
                    'alerts' => $alerts,
                    'chatId' => $chatId,
                    'userId' => $userId,
                    'user' => $user,
                ];
                $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
                screen_show($config, $chatId, $flowId, 'calf_view', $ctx, ['n' => $calf]);
                return;
            }

            $prompt = $def['step2']($calf);
            flow_show($config, $chatId, $flowId, $prompt . "\n\n/cancel — отмена | /menu — меню");
            return;
        }

        if ($step === 2) {
            $calf  = (int)$st['calf_number'];

            $valueRaw = (string)$text;
            $validator = $def['validate2'] ?? null;
            if (!is_callable($validator)) {
                $states->clear($chatId, $userId);
                flow_show($config, $chatId, $flowId, "Сессия сбилась. /menu");
                return;
            }

            [$ok, $valOrErr] = $validator($valueRaw);
            if (!$ok) {
                flow_show($config, $chatId, $flowId, $valOrErr . "\n\n/cancel — отмена | /menu — меню");
                return;
            }

            $value = (string)$valOrErr;

            // особый сценарий: укол -> спросить повтор
            if (!empty($def['needs_repeat'])) {
                $payload['flow_msg_id'] = $flowId;
                $payload['drugDose'] = $value;
                $states->set($chatId, $userId, $action, 3, $calf, $payload);
                flow_show($config, $chatId, $flowId, "💉 Укол\n\n№{$calf}: {$value}\n\nНужен повтор?\nВыбери кнопкой:", kb_repeat());
                return;
            }

            // стандартное сохранение
            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'chatId' => $chatId,
                'userId' => $userId,
                'user' => $user,
            ];

            if (isset($def['save']) && is_callable($def['save'])) {
                $def['save']($ctx, $calf, $value);
            }

            $states->clear($chatId, $userId);
            $success = isset($def['success']) && is_callable($def['success']) ? $def['success']($calf, $value) : '✅ Готово';
            flow_show($config, $chatId, $flowId, $success);
            $ttl = (int)($def['auto_delete'] ?? 0);
            if ($ttl > 0) delete_later($config, $chatId, [$flowId], $ttl);
            return;
        }

        if ($step === 3 && $action === 'treat') {
            flow_show($config, $chatId, $flowId, "Выбери повтор кнопкой выше 👆\n\n/cancel — отмена | /menu — меню", kb_repeat());
            return;
        }
    }

    // Не в сессии
    $isWork = ((int)$config['chat_work'] !== 0 && $chatId === (int)$config['chat_work']);
    if ($isWork) return;

    tg_send($config['bot_token'], $chatId, "Нажми /menu");
}
