<?php
function handle_callback(array $cb): void {
    global $config, $pdo, $states, $calves, $alerts, $finance, $payroll, $dbAgent;

    $chatId    = (int)$cb['message']['chat']['id'];
    $chatType  = (string)($cb['message']['chat']['type'] ?? '');
    $userId    = (int)$cb['from']['id'];
    $flowMsgId = (int)$cb['message']['message_id'];
    $data      = (string)$cb['data'];

    tg_answer_callback($config['bot_token'], (string)$cb['id'], '');

    if ($data === 'noop') return;

    // ---------- AI DB mutation confirmation ----------
    if (strpos($data, 'ai_apply|') === 0 || strpos($data, 'ai_cancel|') === 0) {
        $parts = explode('|', $data);
        $cmd = $parts[0] ?? '';
        $mid = (int)($parts[1] ?? 0);
        if ($mid <= 0 || !isset($dbAgent)) {
            tg_edit($config['bot_token'], $chatId, $flowMsgId, "Ошибка подтверждения (нет данных)." );
            return;
        }

        if ($cmd === 'ai_cancel') {
            $ok = $dbAgent->cancelMutation($mid, $chatId, $userId);
            tg_edit($config['bot_token'], $chatId, $flowMsgId, $ok ? "✖️ Отменил." : "Не получилось отменить (возможно уже обработано)." );
            return;
        }

        // apply
        $r = $dbAgent->applyMutation($mid, $chatId, $userId);
        if (!$r['ok']) {
            $txt = "⛔️ Не применил.\n" . (string)($r['error'] ?? '');
            if (!empty($r['applied'])) {
                $txt .= "\n\nЧастично применено:\n" . implode("\n", (array)$r['applied']);
            }
            tg_edit($config['bot_token'], $chatId, $flowMsgId, $txt);
            return;
        }
        $txt = "✅ Готово.\n" . implode("\n", (array)($r['applied'] ?? []));
        tg_edit($config['bot_token'], $chatId, $flowMsgId, $txt);
        return;
    }


    // ---------- AI pending event save ----------
    if (strpos($data, 'ai_evt|') === 0) {
        // ai_evt|<type>|<pendingId>
        $parts = explode('|', $data);
        $etype = $parts[1] ?? '';
        $pid = (int)($parts[2] ?? 0);

        $st = $pdo->prepare("SELECT * FROM ai_pending WHERE id=? AND chat_id=? AND user_id=? LIMIT 1");
        $st->execute([$pid, $chatId, $userId]);
        $row = $st->fetch();
        if (!$row) {
            tg_edit($config['bot_token'], $chatId, $flowMsgId, "Не нашёл данные для записи (устарело).");
            return;
        }

        $tr = (string)($row['transcript'] ?? '');
        $calf = extract_calf_number($tr);
        if (!$calf) {
            tg_edit($config['bot_token'], $chatId, $flowMsgId, "Не понял номер телёнка из голосового. Напиши: /ask теленок 123 ...");
            return;
        }

        $user = $cb['from']['username'] ?? ($cb['from']['first_name'] ?? '');
        $value = $tr;

        if ($etype === 'temp') {
            $t = ai_extract_temp($tr);
            $value = $t !== null ? (string)$t : $tr;
        } elseif ($etype === 'weight') {
            $w = ai_extract_weight($tr);
            $value = $w !== null ? (string)$w : $tr;
        } elseif ($etype === 'shot' || $etype === 'treatment') {
            $etype = 'treatment';
            $value = $tr;
        } elseif ($etype === 'note') {
            $value = $tr;
        } else {
            tg_edit($config['bot_token'], $chatId, $flowMsgId, "Неизвестный тип записи.");
            return;
        }

        $calves->ensureCalf($calf);
        $calves->addEvent($calf, $etype, $value, $chatId, (string)$user);

        // cleanup pending
        $pdo->prepare("DELETE FROM ai_pending WHERE id=?")->execute([$pid]);

        tg_edit($config['bot_token'], $chatId, $flowMsgId, "✅ Записал: телёнок {$calf}, {$etype} = {$value}");
        return;
    }

    $ctx = [
        'config' => $config,
        'pdo' => $pdo,
        'states' => $states,
        'calves' => $calves,
        'alerts' => $alerts,
        'finance' => $finance ?? null,
        'payroll' => $payroll ?? null,
        'chatId' => $chatId,
        'chatType' => $chatType,
        'userId' => $userId,
        'user' => $cb['from']['username'] ?? ($cb['from']['first_name'] ?? null),
    ];

    $reg = actions_registry();

    // New unified callback format: cb:<route>|k=v
    $cbp = cb_parse($data);
    if ($cbp) {
        $route  = (string)$cbp['route'];
        $params = is_array($cbp['params'] ?? null) ? $cbp['params'] : [];

        if ($route === 'cancel') {
            $states->clear($chatId, $userId);
            flow_show($config, $chatId, $flowMsgId, "Ок, отменил ✅\n\n/menu — меню");
            return;
        }

        if ($route === 'screen') {
            $name = (string)($params['name'] ?? 'menu');
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowMsgId]);
            screen_show($config, $chatId, $flowMsgId, $name, $ctx, $params);
            return;
        }

        // -------- Finance --------
        if ($route === 'fin_add') {
            /** @var FinanceService|null $fin */
            $fin = $finance ?? null;
            if (!($fin instanceof FinanceService) || !$fin->isInstalled()) {
                flow_show($config, $chatId, $flowMsgId, "⚠️ Модуль расходов не установлен. Сначала применим SQL из db/migrations.\n\n/menu — меню");
                return;
            }
            $cats = $fin->listCategories('expense');
            $states->set($chatId, $userId, 'fin_add', 1, null, ['flow_msg_id' => $flowMsgId]);
            flow_show($config, $chatId, $flowMsgId, "💸 Добавить расход\n\nВыбери категорию:", kb_finance_pick_category($cats));
            return;
        }

        if ($route === 'fin_cat_pick') {
            $catId = (int)($params['id'] ?? 0);
            if ($catId <= 0) { flow_show($config, $chatId, $flowMsgId, 'Неверная категория.'); return; }
            $payload = ['flow_msg_id' => $flowMsgId, 'cat_id' => $catId];
            $states->set($chatId, $userId, 'fin_add', 2, null, $payload);
            flow_show($config, $chatId, $flowMsgId, "💸 Добавить расход\n\nВведи сумму (например 1200 или 1200.50)\n\n/cancel — отмена | /menu — меню");
            return;
        }

        if ($route === 'fin_skip_comment') {
            $st = $states->get($chatId, $userId);
            $payload = is_array($st['payload'] ?? null) ? $st['payload'] : [];
            if (!$st || (string)($st['action'] ?? '') !== 'fin_add' || (int)($st['step'] ?? 0) !== 3) {
                flow_show($config, $chatId, $flowMsgId, "Сессия устарела. /menu");
                return;
            }
            // finalize with empty comment
            $catId = (int)($payload['cat_id'] ?? 0);
            $amount = (float)($payload['amount'] ?? 0);
            /** @var FinanceService|null $fin */
            $fin = $finance ?? null;
            if (!($fin instanceof FinanceService)) { flow_show($config, $chatId, $flowMsgId, 'Финансы недоступны.'); return; }
            $fin->addExpense($catId, $amount, '', $userId);
            $states->clear($chatId, $userId);
            screen_show($config, $chatId, $flowMsgId, 'finance_menu', $ctx);
            return;
        }

        if ($route === 'fin_cat_add') {
            $states->set($chatId, $userId, 'fin_cat_add', 1, null, ['flow_msg_id' => $flowMsgId]);
            flow_show($config, $chatId, $flowMsgId, "🧾 Новая категория\n\nВведи название категории расходов (например: Солярка)\n\n/cancel — отмена | /menu — меню");
            return;
        }

        // -------- Payroll --------
        if ($route === 'pay_emp_add') {
            /** @var PayrollService|null $pay */
            $pay = $payroll ?? null;
            if (!($pay instanceof PayrollService) || !$pay->isInstalled()) {
                flow_show($config, $chatId, $flowMsgId, "⚠️ Модуль зарплаты не установлен. Сначала применим SQL из db/migrations.\n\n/menu — меню");
                return;
            }
            $states->set($chatId, $userId, 'pay_emp_add', 1, null, ['flow_msg_id' => $flowMsgId]);
            flow_show($config, $chatId, $flowMsgId, "👷 Добавить сотрудника\n\nВведи имя/фамилию (например: Иван)\n\n/cancel — отмена | /menu — меню");
            return;
        }

        if ($route === 'pay_shift') {
            /** @var PayrollService|null $pay */
            $pay = $payroll ?? null;
            if (!($pay instanceof PayrollService) || !$pay->isInstalled()) {
                flow_show($config, $chatId, $flowMsgId, "⚠️ Модуль зарплаты не установлен. Сначала применим SQL из db/migrations.\n\n/menu — меню");
                return;
            }
            $emps = $pay->listEmployees(true);
            if (!$emps) {
                flow_show($config, $chatId, $flowMsgId, "Сотрудников пока нет. Добавь сотрудника ➕", kb_payroll_menu());
                return;
            }
            $states->set($chatId, $userId, 'pay_shift', 1, null, ['flow_msg_id' => $flowMsgId]);
            flow_show($config, $chatId, $flowMsgId, "✅ Смена (сегодня)\n\nВыбери сотрудника:", kb_payroll_pick_employee($emps, 'pay_shift_emp_pick', 'payroll_menu'));
            return;
        }

        if ($route === 'pay_shift_emp_pick') {
            $empId = (int)($params['id'] ?? 0);
            /** @var PayrollService|null $pay */
            $pay = $payroll ?? null;
            if (!($pay instanceof PayrollService)) { flow_show($config, $chatId, $flowMsgId, 'Зарплата недоступна.'); return; }
            $emp = $pay->getEmployee($empId);
            if (!$emp) { flow_show($config, $chatId, $flowMsgId, 'Сотрудник не найден.'); return; }
            $states->set($chatId, $userId, 'pay_shift', 2, null, ['flow_msg_id' => $flowMsgId, 'emp_id' => $empId]);
            flow_show($config, $chatId, $flowMsgId, "✅ Смена (сегодня)\n\n{$emp['name']}\n\nСколько заработал?", kb_payroll_amount_buttons('pay_shift_amount', $empId));
            return;
        }

        if ($route === 'pay_shift_amount') {
            $empId = (int)($params['id'] ?? 0);
            $aRaw = (string)($params['a'] ?? '');
            $payload = ['flow_msg_id' => $flowMsgId, 'emp_id' => $empId];
            $states->set($chatId, $userId, 'pay_shift', 3, null, $payload);
            if ($aRaw === 'other') {
                flow_show($config, $chatId, $flowMsgId, "✅ Смена (сегодня)\n\nВведи сумму цифрами (например 800)\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $amount = (float)str_replace(',', '.', $aRaw);
            $payload['amount'] = $amount;
            $states->set($chatId, $userId, 'pay_shift', 4, null, $payload);
            flow_show($config, $chatId, $flowMsgId, "✅ Смена (сегодня)\n\nКомментарий (опционально), например: чистка/кормёжка\n\nМожно пропустить.", kb_payroll_comment_skip('pay_shift_comment_skip'));
            return;
        }

        if ($route === 'pay_shift_comment_skip') {
            $st = $states->get($chatId, $userId);
            $payload = is_array($st['payload'] ?? null) ? $st['payload'] : [];
            if (!$st || (string)($st['action'] ?? '') !== 'pay_shift' || (int)($st['step'] ?? 0) !== 4) {
                flow_show($config, $chatId, $flowMsgId, "Сессия устарела. /menu");
                return;
            }
            $empId = (int)($payload['emp_id'] ?? 0);
            $amount = (float)($payload['amount'] ?? 0);
            /** @var PayrollService|null $pay */
            $pay = $payroll ?? null;
            if (!($pay instanceof PayrollService)) { flow_show($config, $chatId, $flowMsgId, 'Зарплата недоступна.'); return; }
            $pay->addAccrual($empId, $amount, '', $userId, date('Y-m-d'));
            $states->clear($chatId, $userId);
            screen_show($config, $chatId, $flowMsgId, 'payroll_menu', $ctx);
            return;
        }

        if ($route === 'pay_payout') {
            /** @var PayrollService|null $pay */
            $pay = $payroll ?? null;
            /** @var FinanceService|null $fin */
            $fin = $finance ?? null;
            if (!($pay instanceof PayrollService) || !$pay->isInstalled() || !($fin instanceof FinanceService) || !$fin->isInstalled()) {
                flow_show($config, $chatId, $flowMsgId, "⚠️ Для выплат нужны таблицы зарплаты И расходов. Сначала применим SQL из db/migrations.\n\n/menu — меню");
                return;
            }
            $emps = $pay->listEmployees(true);
            if (!$emps) {
                flow_show($config, $chatId, $flowMsgId, "Сотрудников пока нет. Добавь сотрудника ➕", kb_payroll_menu());
                return;
            }
            $states->set($chatId, $userId, 'pay_payout', 1, null, ['flow_msg_id' => $flowMsgId]);
            flow_show($config, $chatId, $flowMsgId, "💰 Выплатить зарплату\n\nВыбери сотрудника:", kb_payroll_pick_employee($emps, 'pay_payout_emp_pick', 'payroll_menu'));
            return;
        }

        if ($route === 'pay_payout_emp_pick') {
            $empId = (int)($params['id'] ?? 0);
            /** @var PayrollService|null $pay */
            $pay = $payroll ?? null;
            if (!($pay instanceof PayrollService)) { flow_show($config, $chatId, $flowMsgId, 'Зарплата недоступна.'); return; }
            $emp = $pay->getEmployee($empId);
            if (!$emp) { flow_show($config, $chatId, $flowMsgId, 'Сотрудник не найден.'); return; }
            $debt = $pay->getBalance($empId);
            $states->set($chatId, $userId, 'pay_payout', 2, null, ['flow_msg_id' => $flowMsgId, 'emp_id' => $empId, 'debt' => $debt]);
            $debtTxt = number_format($debt, 2, '.', '');
            flow_show($config, $chatId, $flowMsgId, "💰 Выплата\n\n{$emp['name']}\nТекущий долг: {$debtTxt}\n\nСколько выдать?", kb_payroll_amount_buttons('pay_payout_amount', $empId));
            return;
        }

        if ($route === 'pay_payout_amount') {
            $empId = (int)($params['id'] ?? 0);
            $aRaw = (string)($params['a'] ?? '');
            $payload = ['flow_msg_id' => $flowMsgId, 'emp_id' => $empId];
            $states->set($chatId, $userId, 'pay_payout', 3, null, $payload);
            if ($aRaw === 'other') {
                flow_show($config, $chatId, $flowMsgId, "💰 Выплата\n\nВведи сумму цифрами (например 1000)\n\n/cancel — отмена | /menu — меню");
                return;
            }
            $amount = (float)str_replace(',', '.', $aRaw);
            $payload['amount'] = $amount;
            $states->set($chatId, $userId, 'pay_payout', 4, null, $payload);
            flow_show($config, $chatId, $flowMsgId, "💰 Выплата\n\nКомментарий (опционально), например: аванс/расчёт\n\nМожно пропустить.", kb_payroll_comment_skip('pay_payout_comment_skip'));
            return;
        }

        if ($route === 'pay_payout_comment_skip') {
            $st = $states->get($chatId, $userId);
            $payload = is_array($st['payload'] ?? null) ? $st['payload'] : [];
            if (!$st || (string)($st['action'] ?? '') !== 'pay_payout' || (int)($st['step'] ?? 0) !== 4) {
                flow_show($config, $chatId, $flowMsgId, "Сессия устарела. /menu");
                return;
            }
            $empId = (int)($payload['emp_id'] ?? 0);
            $amount = (float)($payload['amount'] ?? 0);
            /** @var PayrollService|null $pay */
            $pay = $payroll ?? null;
            /** @var FinanceService|null $fin */
            $fin = $finance ?? null;
            if (!($pay instanceof PayrollService) || !($fin instanceof FinanceService)) { flow_show($config, $chatId, $flowMsgId, 'Модуль недоступен.'); return; }

            $payoutId = $pay->addPayout($empId, $amount, '', $userId, date('Y-m-d'));
            // also write expense transaction under category "Зарплата"
            $salaryCat = $fin->ensureExpenseCategory('Зарплата');
            if ($salaryCat) {
                $fin->addExpense($salaryCat, $amount, 'Выплата зарплаты', $userId, $empId, null, 'payroll_payout', $payoutId);
            }

            $states->clear($chatId, $userId);
            screen_show($config, $chatId, $flowMsgId, 'payroll_menu', $ctx);
            return;
        }

        if ($route === 'input') {
            $mode = (string)($params['mode'] ?? 'search');
            $payload = ['flow_msg_id' => $flowMsgId, 'mode' => $mode];

            if ($mode === 'add') {
                $states->set($chatId, $userId, 'calf_add', 1, null, $payload);
                flow_show($config, $chatId, $flowMsgId, "➕ Добавить КРС\n\nВведи номер КРС цифрами (например 249)\n\n/cancel — отмена | /menu — меню");
                return;
            }

            // search
            $states->set($chatId, $userId, 'calf_search', 1, null, $payload);
            flow_show($config, $chatId, $flowMsgId, "🔎 Найти КРС\n\nВведи номер КРС цифрами (например 249)\n\n/cancel — отмена | /menu — меню");
            return;
        }

        if ($route === 'calf_add_skip_birth') {
            $st = $states->get($chatId, $userId);
            $flowId = get_flow_id($st);
            $payload = is_array($st['payload'] ?? null) ? $st['payload'] : [];
            $calf = (int)($payload['calf'] ?? 0);

            if ($flowId <= 0) $flowId = $flowMsgId;

            if (!$st || (string)($st['action'] ?? '') !== 'calf_add' || (int)($st['step'] ?? 0) !== 2 || $calf <= 0) {
                flow_show($config, $chatId, $flowId, "Сессия добавления устарела. /menu");
                return;
            }

            $ctx = [
                'config' => $config,
                'pdo' => $pdo,
                'states' => $states,
                'calves' => $calves,
                'alerts' => $alerts,
                'finance' => $finance ?? null,
                'payroll' => $payroll ?? null,
                'chatId' => $chatId,
                'chatType' => $chatType,
                'userId' => $userId,
                'user' => $cb['from']['username'] ?? ($cb['from']['first_name'] ?? null),
            ];

            $states->clear($chatId, $userId);
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            screen_show($config, $chatId, $flowId, 'calf_view', $ctx, ['n' => $calf]);
            return;
        }


        if ($route === 'qr_search') {
            $payload = ['flow_msg_id' => $flowMsgId, 'mode' => 'qr_search'];
            $states->set($chatId, $userId, 'calf_qr_search', 1, null, $payload);
            flow_show($config, $chatId, $flowMsgId, "🔳 Поиск по QR\n\nПришли QR-код текстом (как он у тебя закодирован).\nМожно просто вставить строку.\n\n/cancel — отмена | /menu — меню");
            return;
        }


        if ($route === 'scan_qr_open') {
            // In groups: open private chat bridge (no WebApp buttons in groups)
            if ($chatType !== '' && $chatType !== 'private') {
                $pmChatId = $userId; // private chat id equals user id
                $payload = [
                    'flow_msg_id' => 0,
                    'origin_chat_id' => $chatId,
                    'origin_flow_msg_id' => $flowMsgId,
                    'origin_user_id' => $userId,
                ];
                $states->set($pmChatId, $userId, 'scan_qr', 1, null, $payload);

                if (!empty($config['bot_username'])) {
                    $url = 'https://t.me/' . (string)$config['bot_username'] . '?start=scanqr';
                    flow_show(
                        $config,
                        $chatId,
                        $flowMsgId,
                        "📷 Скан QR

Чтобы открыть камеру, нажми кнопку ниже — сканер откроется в личном чате с ботом.
После скана я отправлю результат сюда ✅",
                        ['inline_keyboard' => [[['text' => '➡️ Открыть личку для скана', 'url' => $url]]]]
                    );
                } else {
                    flow_show(
                        $config,
                        $chatId,
                        $flowMsgId,
                        "📷 Скан QR

Открой личный чат с ботом и отправь команду:
/start scanqr

После скана я отправлю результат сюда ✅"
                    );
                }
                return;
            }

            // In private: show WebApp scanner button
            if (!empty($config['webapp_qr_url'])) {
                $states->set($chatId, $userId, 'scan_qr', 1, null, ['flow_msg_id' => $flowMsgId]);
                flow_show(
                    $config,
                    $chatId,
                    $flowMsgId,
                    "📷 Скан QR

Нажми кнопку ниже и отсканируй бирку.

/cancel — отмена | /menu — меню",
                    ['inline_keyboard' => [[['text' => '📷 Открыть сканер', 'web_app' => ['url' => (string)$config['webapp_qr_url']]]]]]
                );
                return;
            }

            // fallback
            $payload = ['flow_msg_id' => $flowMsgId, 'mode' => 'qr_search'];
            $states->set($chatId, $userId, 'calf_qr_search', 1, null, $payload);
            flow_show($config, $chatId, $flowMsgId, "🔳 Поиск по QR

Сканер не настроен. Пришли QR-код текстом.

/cancel — отмена | /menu — меню");
            return;
        }

        if ($route === 'qr_bind') {
            // Bind existing ear-tag QR to a calf
            $payload = ['flow_msg_id' => $flowMsgId];
            $states->set($chatId, $userId, 'qr_bind', 1, null, $payload);
            flow_show(
                $config,
                $chatId,
                $flowMsgId,
                "🔗 Привязка бирки (QR)\n\n1) Отсканируй бирку кнопкой 📷 или пришли QR-код текстом.\n2) Затем введёшь номер телёнка, к которому относится бирка.\n\n/cancel — отмена | /menu — меню",
                kb_qr_bind()
            );
            return;
        }

        if ($route === 'export_csv') {
            // Export calves with latest status + qr as CSV file
            $rows = $calves->exportCalvesWithQr(true);
            $csv = "number,status,qr\n";
            foreach ($rows as $r) {
                $n = (string)($r['number'] ?? '');
                $s = (string)($r['status'] ?? 'active');
                $q = (string)($r['qr'] ?? '');
                // basic CSV escaping
                $csv .= '"' . str_replace('"', '""', $n) . '",' .
                        '"' . str_replace('"', '""', $s) . '",' .
                        '"' . str_replace('"', '""', $q) . '"' . "\n";
            }

            $tmp = sys_get_temp_dir() . '/calves_qr_' . date('Ymd_His') . '.csv';
            file_put_contents($tmp, $csv);

            tg_send_document($config['bot_token'], $chatId, $tmp, basename($tmp), 'Экспорт телят (номер, статус, qr)');
            @unlink($tmp);

            // keep current master screen
            flow_show($config, $chatId, $flowMsgId, "⬇️ CSV отправил файлом.\n\n/menu — меню");
            return;
        }

        if ($route === 'qr_bind_yes' || $route === 'qr_bind_no') {
            $st = $states->get($chatId, $userId);
            $flowId = get_flow_id($st);
            $payload = $st['payload'] ?? null;
            $code = is_array($payload) ? (string)($payload['qr_code'] ?? '') : '';
            $newCalf = is_array($payload) ? (int)($payload['new_calf'] ?? 0) : 0;

            if ($flowId <= 0) $flowId = $flowMsgId;

            if (!$st || (string)($st['action'] ?? '') !== 'qr_bind_confirm' || $code === '' || $newCalf <= 0) {
                flow_show($config, $chatId, $flowId, "Сессия привязки сбилась. Нажми /menu");
                return;
            }

            if ($route === 'qr_bind_no') {
                // Go back to calf card (if exists) or menu
                $states->clear($chatId, $userId);
                if ($calves->existsCalf($newCalf)) {
                    screen_show($config, $chatId, $flowId, 'calf_view', $ctx, ['n' => $newCalf]);
                } else {
                    show_menu($config, $pdo, $states, $calves, $chatId, $userId, $chatType);
                }
                return;
            }

            // Yes: force bind (write qr event for new calf)
            $calves->setQrCode($newCalf, $code, $chatId, $ctx['user']);
            $states->clear($chatId, $userId);
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowId]);
            screen_show($config, $chatId, $flowId, 'calf_view', $ctx, ['n' => $newCalf]);
            return;
        }

        if ($route === 'action') {
            $action = (string)($params['id'] ?? '');
            if ($action === '' || !isset($reg[$action])) {
                flow_show($config, $chatId, $flowMsgId, "Неизвестная команда. /menu");
                return;
            }
            $calf = (int)($params['n'] ?? 0);
            $payload = ['flow_msg_id' => $flowMsgId];
            if ($calf > 0) {
                // Jump directly to step 2 (value input) if calf is preselected
                $states->set($chatId, $userId, $action, 2, $calf, $payload);

                if (!empty($reg[$action]['status_mode'])) {
                    screen_show($config, $chatId, $flowMsgId, 'calf_view', $ctx, ['n' => $calf]);
                    return;
                }

                $prompt = $reg[$action]['step2']($calf);
                flow_show($config, $chatId, $flowMsgId, $prompt . "\n\n/cancel — отмена | /menu — меню");
                return;
            }

            $states->set($chatId, $userId, $action, 1, null, $payload);
            $t = $reg[$action]['step1'](0);
            flow_show($config, $chatId, $flowMsgId, $t . "\n\n/cancel — отмена | /menu — меню");
            return;
        }

        if ($route === 'life') {
            $calf = (int)($params['n'] ?? 0);
            $status = (string)($params['s'] ?? 'active');
            if ($calf <= 0) {
                flow_show($config, $chatId, $flowMsgId, "Неверный номер.");
                return;
            }
            $calves->setLifeStatus($calf, $status, $chatId, $ctx['user']);
            screen_show($config, $chatId, $flowMsgId, 'calf_view', $ctx, ['n' => $calf]);
            return;
        }

        if ($route === 'qr') {
            $calf = (int)($params['n'] ?? 0);
            if ($calf <= 0) {
                flow_show($config, $chatId, $flowMsgId, "Неверный номер.");
                return;
            }
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowMsgId]);
            screen_show($config, $chatId, $flowMsgId, 'calf_qr', $ctx, ['n' => $calf]);
            return;
        }

        if ($route === 'qr_reset') {
            $calf = (int)($params['n'] ?? 0);
            if ($calf <= 0) {
                flow_show($config, $chatId, $flowMsgId, "Неверный номер.");
                return;
            }
            // generate a short code
            $code = 'C' . $calf . '-' . substr(strtoupper(base_convert((string)random_int(100000, 999999999), 10, 36)), 0, 6);
            $calves->setQrCode($calf, $code, $chatId, $ctx['user']);
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowMsgId]);
            screen_show($config, $chatId, $flowMsgId, 'calf_qr', $ctx, ['n' => $calf]);
            return;
        }

        if ($route === 'stats') {
            $calf = (int)($params['n'] ?? 0);
            if ($calf <= 0) {
                flow_show($config, $chatId, $flowMsgId, "Неверный номер.");
                return;
            }
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $flowMsgId]);
            screen_show($config, $chatId, $flowMsgId, 'calf_stats', $ctx, ['n' => $calf]);
            return;
        }

        if ($route === 'del') {
            $calf = (int)($params['n'] ?? 0);
            if ($calf <= 0) {
                flow_show($config, $chatId, $flowMsgId, "Неверный номер.");
                return;
            }
            flow_show($config, $chatId, $flowMsgId, "🗑 Удалить телёнка №{$calf}?\n\nЭто скроет его из списка (можно вернуть статусом 'Активен').", kb_confirm_delete($calf));
            return;
        }

        if ($route === 'del_confirm') {
            $calf = (int)($params['n'] ?? 0);
            $yes = (int)($params['yes'] ?? 0);
            if ($calf <= 0) {
                flow_show($config, $chatId, $flowMsgId, "Неверный номер.");
                return;
            }
            if ($yes !== 1) {
                screen_show($config, $chatId, $flowMsgId, 'calf_view', $ctx, ['n' => $calf]);
                return;
            }
            $calves->setLifeStatus($calf, 'removed', $chatId, $ctx['user']);
            screen_show($config, $chatId, $flowMsgId, 'calves_list', $ctx, ['p' => 0, 'all' => 0]);
            return;
        }

        if ($route === 'event_edit') {
            $eventId = (int)($params['id'] ?? 0);
            $calf = (int)($params['n'] ?? 0);
            $page = max(0, (int)($params['p'] ?? 0));
            if ($eventId <= 0) {
                flow_show($config, $chatId, $flowMsgId, 'Неверное событие.');
                return;
            }
            $ev = $calves->getEvent($eventId);
            if (!$ev) {
                flow_show($config, $chatId, $flowMsgId, 'Событие не найдено (возможно удалено).');
                return;
            }
            $payload = [
                'flow_msg_id' => $flowMsgId,
                'event_id' => $eventId,
                'return_calf' => (int)($ev['calf_number'] ?? $calf),
                'return_page' => $page,
            ];
            $states->set($chatId, $userId, 'event_edit', 1, (int)($ev['calf_number'] ?? $calf), $payload);
            $type = (string)($ev['type'] ?? '');
            $val  = (string)($ev['value'] ?? '');
            flow_show($config, $chatId, $flowMsgId, "✏️ Изменить событие\n\nТип: {$type}\nТекущее: {$val}\n\nВведи новое значение:\n\n/cancel — отмена | /menu — меню");
            return;
        }

        if ($route === 'event_del') {
            $eventId = (int)($params['id'] ?? 0);
            $calf = (int)($params['n'] ?? 0);
            $page = max(0, (int)($params['p'] ?? 0));
            if ($eventId <= 0) {
                flow_show($config, $chatId, $flowMsgId, 'Неверное событие.');
                return;
            }
            flow_show($config, $chatId, $flowMsgId, "🗑 Удалить это событие?\n\nУдаление необратимо.", kb_event_delete_confirm($calf, $eventId, $page));
            return;
        }

        if ($route === 'event_del_confirm') {
            $eventId = (int)($params['id'] ?? 0);
            $calf = (int)($params['n'] ?? 0);
            $page = max(0, (int)($params['p'] ?? 0));
            $yes = (int)($params['yes'] ?? 0);
            if ($yes !== 1) {
                screen_show($config, $chatId, $flowMsgId, 'event_view', $ctx, ['id' => $eventId, 'n' => $calf, 'p' => $page]);
                return;
            }
            $calves->deleteEvent($eventId);
            screen_show($config, $chatId, $flowMsgId, 'calf_events', $ctx, ['n' => $calf, 'p' => $page]);
            return;
        }

        if ($route === 'repeat') {
            $hours = (int)($params['h'] ?? 0);
            // reuse legacy handler below
            $data = 'rep:' . $hours;
        }
    }

    // Legacy callbacks (backward compatibility)
    if ($data === 'act:cancel') {
        $states->clear($chatId, $userId);
        flow_show($config, $chatId, $flowMsgId, "Ок, отменил ✅\n\n/menu — меню");
        return;
    }

    if (preg_match('/^act:([a-z0-9_\-]+)$/', $data, $m)) {
        $action = $m[1];

        if (!isset($reg[$action])) {
            flow_show($config, $chatId, $flowMsgId, "Неизвестная команда. /menu");
            return;
        }

        $states->set($chatId, $userId, $action, 1, null, ['flow_msg_id' => $flowMsgId]);

        $t = $reg[$action]['step1'](0);
        flow_show($config, $chatId, $flowMsgId, $t . "\n\n/cancel — отмена | /menu — меню");
        return;
    }

    if (preg_match('/^rep:(\d+)$/', $data, $m)) {
        $hours = (int)$m[1];
        $st = $states->get($chatId, $userId);

        if (!$st || $st['action'] !== 'treat' || (int)$st['step'] !== 3) {
            flow_show($config, $chatId, $flowMsgId, "Сессия устарела. /menu");
            return;
        }

        $payload = is_array($st['payload'] ?? null) ? $st['payload'] : [];
        $flowId  = (int)($payload['flow_msg_id'] ?? $flowMsgId);
        $calf    = (int)$st['calf_number'];
        $drugDose = (string)($payload['drugDose'] ?? '');

        $calves->ensureCalf($calf);
        $calves->addEvent(
            $calf,
            'treatment',
            $drugDose,
            $chatId,
            $cb['from']['username'] ?? ($cb['from']['first_name'] ?? null)
        );

        $extra = "";
        if ($hours > 0) {
            $due = (new DateTime('now'))->modify("+{$hours} hours")->format('Y-m-d H:i:s');
            $text = "⏰ Повтор укола для №{$calf}: {$drugDose} (через {$hours}ч)";
            $stmt = $pdo->prepare("INSERT INTO reminders(calf_number, due_at, text) VALUES (?,?,?)");
            $stmt->execute([$calf, $due, $text]);
            $extra = "\n\nНапоминание поставил ✅";
        } else {
            $extra = "\n\nПовтор не ставил ✅";
        }

        $states->clear($chatId, $userId);
        flow_show($config, $chatId, $flowId, "✅ Записал укол\n\n№{$calf}: {$drugDose}{$extra}");
        delete_later($config, $chatId, [$flowId], 5);
        return;
    }
}
