<?php

require_once __DIR__ . '/actions.php';

function ui_trunc(string $s, int $max = 22): string {
    $s = norm($s);
    if (u_strlen($s) <= $max) return $s;
    return u_substr($s, 0, $max - 1) . '…';
}

function ui_event_type_icon(string $type): string {
    $type = strtolower(trim($type));
    return match ($type) {
        'temp' => '🌡',
        'weight' => '⚖️',
        'treatment' => '💉',
        'note' => '📝',
        'life' => '🏷',
        'qr' => '🔳',
        'birth', 'dob', 'born' => '🎂',
        default => '•',
    };
}

/**
 * Short, human-friendly event line (no "treatment" word).
 * Example: "• 02.03.2026 02:34 — Азитронит 3мл — info_mast"
 */
function ui_event_short(array $e): string {
    $dt = format_dt($e['created_at'] ?? '');
    $type = (string)($e['type'] ?? '');
    $val  = norm((string)($e['value'] ?? ''));
    $who  = norm((string)($e['source_user'] ?? ''));

    $icon = ui_event_type_icon($type);

    $type = strtolower(trim($type));

    // For treatments: show only value (and who, if present)
    if ($type === 'treatment') {
        $s = "• {$dt} — {$val}";
        if ($who !== '') $s .= " — {$who}";
        return $s;
    }

    // Other types: keep icon + value
    $s = "• {$dt} — {$icon} {$val}";
    if ($type === 'note' && $who !== '') {
        // optional: show author for notes too
        // $s .= " — {$who}";
    }
    return $s;
}

function kb_main_menu(array $ctx = []): array {
    $rows = [];
    $rows[] = [
        ['text' => '🐄 КРС', 'callback_data' => cb_pack('screen', ['name' => 'menu_krs'])],
        ['text' => '💸 Расходы', 'callback_data' => cb_pack('screen', ['name' => 'finance_menu'])],
    ];
    $rows[] = [
        ['text' => '👷 Зарплата', 'callback_data' => cb_pack('screen', ['name' => 'payroll_menu'])],
        ['text' => '📊 Отчёты', 'callback_data' => cb_pack('screen', ['name' => 'reports_menu'])],
    ];
    $rows[] = [
        ['text' => '❌ Отмена', 'callback_data' => cb_pack('cancel')],
    ];
    return ['inline_keyboard' => $rows];
}

function kb_krs_menu(array $ctx = []): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '📋 Список КРС', 'callback_data' => cb_pack('screen', ['name' => 'calves_list', 'p' => 0])],
                ['text' => '➕ Добавить КРС', 'callback_data' => cb_pack('input', ['mode' => 'add'])],
            ],
            [
                ['text' => '🔎 Найти', 'callback_data' => cb_pack('screen', ['name' => 'krs_find'])],
                ['text' => '✍️ Внести данные', 'callback_data' => cb_pack('screen', ['name' => 'krs_data'])],
            ],
            [
                ['text' => '📦 Архив', 'callback_data' => cb_pack('screen', ['name' => 'calves_archive', 'p' => 0])],
                ['text' => '⬇️ Экспорт', 'callback_data' => cb_pack('export_csv')],
            ],
            [
                ['text' => '⬅️ Главное меню', 'callback_data' => cb_pack('screen', ['name' => 'menu'])],
                ['text' => '❌ Отмена', 'callback_data' => cb_pack('cancel')],
            ],
        ],
    ];
}

function kb_krs_find(array $ctx = []): array {
    global $config;

    $chatType = (string)($ctx['chatType'] ?? '');
    $chatIdCtx = (int)($ctx['chatId'] ?? 0);
    $isPrivate = ($chatType === 'private') || ($chatType === '' && $chatIdCtx > 0);

    $scanBtn = null;
    if ($isPrivate && !empty($config['webapp_qr_url'])) {
        $scanBtn = ['text' => '📷 Сканировать QR', 'web_app' => ['url' => (string)$config['webapp_qr_url']]];
    } else {
        $scanBtn = ['text' => '📷 Сканировать QR', 'callback_data' => cb_pack('scan_qr_open')];
    }

    return [
        'inline_keyboard' => [
            [
                ['text' => '⌨️ Ввести номер', 'callback_data' => cb_pack('input', ['mode' => 'search'])],
                $scanBtn,
            ],
            [
                ['text' => '⬅️ КРС', 'callback_data' => cb_pack('screen', ['name' => 'menu_krs'])],
                ['text' => '❌ Отмена', 'callback_data' => cb_pack('cancel')],
            ],
        ],
    ];
}

function kb_krs_data_entry(): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '📝 Заметка', 'callback_data' => cb_pack('action', ['id' => 'note'])],
                ['text' => '💉 Укол', 'callback_data' => cb_pack('action', ['id' => 'treat'])],
            ],
            [
                ['text' => '🌡 Температура', 'callback_data' => cb_pack('action', ['id' => 'temp'])],
                ['text' => '🔳 Вставить QR', 'callback_data' => cb_pack('qr_search')],
            ],
            [
                ['text' => '🔗 Привязать бирку', 'callback_data' => cb_pack('qr_bind')],
            ],
            [
                ['text' => '⬅️ КРС', 'callback_data' => cb_pack('screen', ['name' => 'menu_krs'])],
                ['text' => '❌ Отмена', 'callback_data' => cb_pack('cancel')],
            ],
        ],
    ];
}

function kb_back_menu(): array {
    return ['inline_keyboard' => [[['text' => '⬅️ Меню', 'callback_data' => cb_pack('screen', ['name' => 'menu'])]]]];
}

function kb_back_main(): array {
    return ['inline_keyboard' => [[['text' => '⬅️ Главное меню', 'callback_data' => cb_pack('screen', ['name' => 'menu'])]]]];
}

// ---------- Group panel (pinned) ----------
function kb_group_panel(): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '🐄 КРС', 'callback_data' => cb_pack('screen', ['name' => 'menu_krs'])],
                ['text' => '🔎 Найти', 'callback_data' => cb_pack('screen', ['name' => 'krs_find'])],
            ],
            [
                ['text' => '✍️ Внести данные', 'callback_data' => cb_pack('screen', ['name' => 'krs_data'])],
                ['text' => '🤖 ИИ', 'callback_data' => cb_pack('screen', ['name' => 'ai_help'])],
            ],
            [
                ['text' => '🏠 Меню', 'callback_data' => cb_pack('screen', ['name' => 'menu'])],
            ],
        ],
    ];
}

// ---------- Reply keyboard (menu near the paperclip/input field) ----------
function kb_reply_common(array $rows, string $placeholder): array {
    return [
        'keyboard' => $rows,
        'resize_keyboard' => true,
        'is_persistent' => true,
        'one_time_keyboard' => false,
        'input_field_placeholder' => $placeholder,
    ];
}

function kb_reply_root(): array {
    return kb_reply_common([
        [
            ['text' => '🐄 КРС'],
            ['text' => '🔎 Найти'],
        ],
        [
            ['text' => '✍️ Внести данные'],
            ['text' => '🤖 ИИ'],
        ],
        [
            ['text' => '💸 Расходы'],
            ['text' => '👷 Зарплата'],
        ],
        [
            ['text' => '📊 Отчёты'],
            ['text' => '📌 Панель'],
        ],
        [
            ['text' => '🏠 Меню'],
            ['text' => '⌨️ Скрыть клавиатуру'],
        ],
    ], 'Главное меню');
}

function kb_reply_krs(): array {
    return kb_reply_common([
        [
            ['text' => '📋 Список'],
            ['text' => '➕ Добавить'],
        ],
        [
            ['text' => '🔎 Найти'],
            ['text' => '✍️ Внести данные'],
        ],
        [
            ['text' => '📦 Архив'],
            ['text' => '🏠 Меню'],
        ],
        [
            ['text' => '⬅️ Назад'],
            ['text' => '⌨️ Скрыть клавиатуру'],
        ],
    ], 'Раздел КРС');
}

function kb_reply_finance(): array {
    return kb_reply_common([
        [
            ['text' => '➕ Добавить расход'],
            ['text' => '📒 Журнал 7 дней'],
        ],
        [
            ['text' => '📒 Журнал 30 дней'],
            ['text' => '🧾 Категории'],
        ],
        [
            ['text' => '🏠 Меню'],
            ['text' => '⬅️ Назад'],
        ],
        [
            ['text' => '⌨️ Скрыть клавиатуру'],
        ],
    ], 'Раздел расходов');
}

function kb_reply_payroll(): array {
    return kb_reply_common([
        [
            ['text' => '✅ Смена'],
            ['text' => '💰 Выплатить'],
        ],
        [
            ['text' => '👥 Сотрудники'],
            ['text' => '📊 Долги'],
        ],
        [
            ['text' => '🏠 Меню'],
            ['text' => '⬅️ Назад'],
        ],
        [
            ['text' => '⌨️ Скрыть клавиатуру'],
        ],
    ], 'Раздел зарплаты');
}

function kb_reply_ai(): array {
    return kb_reply_common([
        [
            ['text' => '🤖 ИИ'],
            ['text' => '🏠 Меню'],
        ],
        [
            ['text' => '⌨️ Скрыть клавиатуру'],
        ],
    ], 'Задай вопрос ИИ');
}

function kb_reply_remove(): array {
    return [
        'remove_keyboard' => true,
    ];
}

function kb_finance_menu(): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '➕ Добавить расход', 'callback_data' => cb_pack('fin_add')],
                ['text' => '📒 Журнал 7 дней', 'callback_data' => cb_pack('screen', ['name' => 'finance_journal', 'd' => 7, 'p' => 0])],
            ],
            [
                ['text' => '📒 Журнал 30 дней', 'callback_data' => cb_pack('screen', ['name' => 'finance_journal', 'd' => 30, 'p' => 0])],
                ['text' => '🧾 Категории', 'callback_data' => cb_pack('screen', ['name' => 'finance_categories'])],
            ],
            [
                ['text' => '⬅️ Главное меню', 'callback_data' => cb_pack('screen', ['name' => 'menu'])],
            ],
        ],
    ];
}

function kb_finance_categories(): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '➕ Добавить категорию', 'callback_data' => cb_pack('fin_cat_add')],
            ],
            [
                ['text' => '⬅️ Расходы', 'callback_data' => cb_pack('screen', ['name' => 'finance_menu'])],
            ],
        ],
    ];
}

function kb_finance_pick_category(array $cats): array {
    $rows = [];
    foreach ($cats as $c) {
        $id = (int)($c['id'] ?? 0);
        $name = (string)($c['name'] ?? '');
        if ($id <= 0 || $name === '') continue;
        $rows[] = [[
            'text' => ui_trunc($name, 26),
            'callback_data' => cb_pack('fin_cat_pick', ['id' => $id]),
        ]];
    }
    // back
    $rows[] = [[
        'text' => '⬅️ Назад',
        'callback_data' => cb_pack('screen', ['name' => 'finance_menu']),
    ]];
    return ['inline_keyboard' => $rows];
}

function kb_finance_comment_skip(): array {
    return ['inline_keyboard' => [
        [
            ['text' => '⏭ Пропустить', 'callback_data' => cb_pack('fin_skip_comment')],
        ],
        [
            ['text' => '❌ Отмена', 'callback_data' => cb_pack('cancel')],
        ],
    ]];
}

function kb_finance_journal(int $days, int $page, bool $hasAny): array {
    $rows = [];
    $nav = [];
    if ($page > 0) $nav[] = ['text' => '⬅️', 'callback_data' => cb_pack('screen', ['name' => 'finance_journal', 'd' => $days, 'p' => $page - 1])];
    $nav[] = ['text' => 'Стр. ' . ($page + 1), 'callback_data' => 'noop'];
    if ($hasAny) $nav[] = ['text' => '➡️', 'callback_data' => cb_pack('screen', ['name' => 'finance_journal', 'd' => $days, 'p' => $page + 1])];
    $rows[] = $nav;
    $rows[] = [[
        'text' => '⬅️ Расходы',
        'callback_data' => cb_pack('screen', ['name' => 'finance_menu']),
    ]];
    return ['inline_keyboard' => $rows];
}

function kb_payroll_menu(): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '✅ Отметить смену (сегодня)', 'callback_data' => cb_pack('pay_shift')],
                ['text' => '💰 Выплатить', 'callback_data' => cb_pack('pay_payout')],
            ],
            [
                ['text' => '👥 Сотрудники', 'callback_data' => cb_pack('screen', ['name' => 'payroll_employees'])],
                ['text' => '📊 Долги', 'callback_data' => cb_pack('screen', ['name' => 'payroll_debts'])],
            ],
            [
                ['text' => '⬅️ Главное меню', 'callback_data' => cb_pack('screen', ['name' => 'menu'])],
            ],
        ],
    ];
}

function kb_payroll_employees(array $emps): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '➕ Добавить сотрудника', 'callback_data' => cb_pack('pay_emp_add')],
            ],
            [
                ['text' => '⬅️ Зарплата', 'callback_data' => cb_pack('screen', ['name' => 'payroll_menu'])],
            ],
        ],
    ];
}

function kb_payroll_pick_employee(array $emps, string $route, string $backScreen = 'payroll_menu'): array {
    $rows = [];
    foreach ($emps as $e) {
        $id = (int)($e['id'] ?? 0);
        $name = (string)($e['name'] ?? '');
        if ($id <= 0 || $name === '') continue;
        $rows[] = [[
            'text' => ui_trunc($name, 28),
            'callback_data' => cb_pack($route, ['id' => $id]),
        ]];
    }
    $rows[] = [[
        'text' => '⬅️ Назад',
        'callback_data' => cb_pack('screen', ['name' => $backScreen]),
    ]];
    return ['inline_keyboard' => $rows];
}

function kb_payroll_amount_buttons(string $prefixRoute, int $employeeId): array {
    $amts = [500, 1000, 1500];
    $row = [];
    foreach ($amts as $a) {
        $row[] = ['text' => (string)$a, 'callback_data' => cb_pack($prefixRoute, ['id' => $employeeId, 'a' => $a])];
    }
    return [
        'inline_keyboard' => [
            $row,
            [
                ['text' => 'Другая сумма', 'callback_data' => cb_pack($prefixRoute, ['id' => $employeeId, 'a' => 'other'])],
            ],
            [
                ['text' => '❌ Отмена', 'callback_data' => cb_pack('cancel')],
            ],
        ],
    ];
}

function kb_payroll_comment_skip(string $skipRoute): array {
    return ['inline_keyboard' => [
        [
            ['text' => '⏭ Пропустить', 'callback_data' => cb_pack($skipRoute)],
        ],
        [
            ['text' => '❌ Отмена', 'callback_data' => cb_pack('cancel')],
        ],
    ]];
}

function kb_payroll_debts(array $rows): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '💰 Выплатить', 'callback_data' => cb_pack('pay_payout')],
                ['text' => '✅ Отметить смену', 'callback_data' => cb_pack('pay_shift')],
            ],
            [
                ['text' => '⬅️ Зарплата', 'callback_data' => cb_pack('screen', ['name' => 'payroll_menu'])],
            ],
        ],
    ];
}

function kb_qr_bind(): array {
    global $config;
    $rows = [];

    // Camera scan via WebApp if configured
    if (!empty($config['webapp_qr_url'])) {
        $rows[] = [[
            'text' => '📷 Сканировать бирку',
            'web_app' => ['url' => (string)$config['webapp_qr_url']],
        ]];
    }

    $rows[] = [[
        'text' => '🔳 Вставить QR код текстом',
        'callback_data' => 'noop',
    ]];

    $rows[] = [[
        'text' => '❌ Отмена',
        'callback_data' => cb_pack('cancel'),
    ]];

    return ['inline_keyboard' => $rows];
}

function kb_qr_bind_confirm(int $oldCalf, int $newCalf): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => "✅ Перепривязать", 'callback_data' => cb_pack('qr_bind_yes')],
                ['text' => "❌ Не надо", 'callback_data' => cb_pack('qr_bind_no')],
            ],
        ],
    ];
}

function kb_calves_list(array $items, int $page, bool $showAll = false): array {
    $rows = [];

    foreach ($items as $it) {
        $n = (int)($it['number'] ?? 0);
        if ($n <= 0) continue;
        $status = (string)($it['status'] ?? '');
        $badge = $status === 'sold' ? '💰' : ($status === 'dead' ? '⚰️' : ($status === 'removed' ? '🚫' : ''));
        $rows[] = [[
            'text' => "{$badge} №{$n}",
            'callback_data' => cb_pack('screen', ['name' => 'calf_view', 'n' => $n]),
        ]];
    }

    // quick actions under the list
    $rows[] = [
        ['text' => '🔎 Найти', 'callback_data' => cb_pack('screen', ['name' => 'krs_find'])],
        ['text' => '➕ Добавить КРС', 'callback_data' => cb_pack('input', ['mode' => 'add'])],
    ];

    // Pager + toggle
    $nav = [];
    if ($page > 0) $nav[] = ['text' => '⬅️', 'callback_data' => cb_pack('screen', ['name' => 'calves_list', 'p' => $page - 1, 'all' => $showAll ? 1 : 0])];
    $nav[] = ['text' => "Стр. " . ($page + 1), 'callback_data' => 'noop'];
    $nav[] = ['text' => '➡️', 'callback_data' => cb_pack('screen', ['name' => 'calves_list', 'p' => $page + 1, 'all' => $showAll ? 1 : 0])];
    $rows[] = $nav;

    $rows[] = [
        ['text' => $showAll ? '✅ Только активные' : '👀 Показать всех',
         'callback_data' => cb_pack('screen', ['name' => 'calves_list', 'p' => 0, 'all' => $showAll ? 0 : 1])],
    ];

    $rows[] = [
        ['text' => '⬅️ КРС', 'callback_data' => cb_pack('screen', ['name' => 'menu_krs'])],
    ];

    return ['inline_keyboard' => $rows];
}

function kb_calf_view(int $calf, string $status = 'active'): array {
    $rows = [];

    $rows[] = [
        ['text' => '📝 Заметка', 'callback_data' => cb_pack('action', ['id' => 'note', 'n' => $calf])],
        ['text' => '💉 Укол', 'callback_data' => cb_pack('action', ['id' => 'treat', 'n' => $calf])],
    ];

    $rows[] = [
        ['text' => '🌡 Температура', 'callback_data' => cb_pack('action', ['id' => 'temp', 'n' => $calf])],
        ['text' => '✏️ Редактировать', 'callback_data' => cb_pack('screen', ['name' => 'calf_edit', 'n' => $calf])],
    ];

    $rows[] = [
        ['text' => '📒 Журнал', 'callback_data' => cb_pack('screen', ['name' => 'calf_events', 'n' => $calf, 'p' => 0])],
        ['text' => '📊 Статистика', 'callback_data' => cb_pack('stats', ['n' => $calf])],
    ];

    $rows[] = [
        ['text' => '🔎 Найти', 'callback_data' => cb_pack('screen', ['name' => 'krs_find'])],
        ['text' => '🔳 QR-код', 'callback_data' => cb_pack('qr', ['n' => $calf])],
    ];

    // status buttons (show only what can be set)
    $statusBtns = [];
    if ($status !== 'active') $statusBtns[] = ['text' => '✅ Активен', 'callback_data' => cb_pack('life', ['n' => $calf, 's' => 'active'])];
    if ($status !== 'sold') $statusBtns[] = ['text' => '💰 Продан',  'callback_data' => cb_pack('life', ['n' => $calf, 's' => 'sold'])];
    if ($status !== 'dead') $statusBtns[] = ['text' => '⚰️ Падеж',  'callback_data' => cb_pack('life', ['n' => $calf, 's' => 'dead'])];
    if ($statusBtns) $rows[] = $statusBtns;

    $rows[] = [
        ['text' => '🗑 Удалить', 'callback_data' => cb_pack('del', ['n' => $calf])],
        ['text' => '⬅️ Список', 'callback_data' => cb_pack('screen', ['name' => 'calves_list', 'p' => 0])],
    ];

    $rows[] = [
        ['text' => '🐄 Меню', 'callback_data' => cb_pack('screen', ['name' => 'menu_krs'])],
    ];

    return ['inline_keyboard' => $rows];
}

function kb_calf_edit(int $calf): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '🎂 Изменить дату рождения', 'callback_data' => cb_pack('action', ['id' => 'birth', 'n' => $calf])],
                ['text' => '⚖️ Изменить вес', 'callback_data' => cb_pack('action', ['id' => 'weight', 'n' => $calf])],
            ],
            [
                ['text' => '⬅️ Карточка', 'callback_data' => cb_pack('screen', ['name' => 'calf_view', 'n' => $calf])],
            ],
        ],
    ];
}

function kb_confirm_delete(int $calf): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '✅ Да, удалить', 'callback_data' => cb_pack('del_confirm', ['n' => $calf, 'yes' => 1])],
                ['text' => '❌ Отмена', 'callback_data' => cb_pack('screen', ['name' => 'calf_view', 'n' => $calf])],
            ],
        ],
    ];
}

function kb_calf_events(int $calf, array $events, int $page, ?string $typeFilter = null): array {
    $rows = [];

    // Filters
    $rows[] = [
        ['text' => ($typeFilter === null ? '✅ Все' : 'Все'), 'callback_data' => cb_pack('screen', ['name' => 'calf_events', 'n' => $calf, 'p' => 0])],
        ['text' => ($typeFilter === 'temp' ? '✅ 🌡' : '🌡'), 'callback_data' => cb_pack('screen', ['name' => 'calf_events', 'n' => $calf, 'p' => 0, 't' => 'temp'])],
        ['text' => ($typeFilter === 'weight' ? '✅ ⚖️' : '⚖️'), 'callback_data' => cb_pack('screen', ['name' => 'calf_events', 'n' => $calf, 'p' => 0, 't' => 'weight'])],
        ['text' => ($typeFilter === 'treatment' ? '✅ 💉' : '💉'), 'callback_data' => cb_pack('screen', ['name' => 'calf_events', 'n' => $calf, 'p' => 0, 't' => 'treatment'])],
        ['text' => ($typeFilter === 'note' ? '✅ 📝' : '📝'), 'callback_data' => cb_pack('screen', ['name' => 'calf_events', 'n' => $calf, 'p' => 0, 't' => 'note'])],
        ['text' => ($typeFilter === 'birth' ? '✅ 🎂' : '🎂'), 'callback_data' => cb_pack('screen', ['name' => 'calf_events', 'n' => $calf, 'p' => 0, 't' => 'birth'])],
    ];

    foreach ($events as $e) {
        $id = (int)($e['id'] ?? 0);
        if ($id <= 0) continue;
        $txt = ui_trunc(ui_event_short($e), 42);
        $rows[] = [[
            'text' => $txt,
            'callback_data' => cb_pack('screen', ['name' => 'event_view', 'id' => $id, 'n' => $calf, 'p' => $page]),
        ]];
    }

    $nav = [];
    $base = ['name' => 'calf_events', 'n' => $calf];
    if ($typeFilter !== null) $base['t'] = $typeFilter;
    if ($page > 0) $nav[] = ['text' => '⬅️', 'callback_data' => cb_pack('screen', $base + ['p' => $page - 1])];
    $nav[] = ['text' => "Стр. " . ($page + 1), 'callback_data' => 'noop'];
    $nav[] = ['text' => '➡️', 'callback_data' => cb_pack('screen', $base + ['p' => $page + 1])];
    $rows[] = $nav;

    $rows[] = [
        ['text' => '➕ Событие', 'callback_data' => cb_pack('screen', ['name' => 'event_add', 'n' => $calf])],
        ['text' => '⬅️ Карточка', 'callback_data' => cb_pack('screen', ['name' => 'calf_view', 'n' => $calf])],
    ];

    return ['inline_keyboard' => $rows];
}

function kb_event_view(int $calf, int $eventId, int $page): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '✏️ Изменить', 'callback_data' => cb_pack('event_edit', ['id' => $eventId, 'n' => $calf, 'p' => $page])],
                ['text' => '🗑 Удалить', 'callback_data' => cb_pack('event_del', ['id' => $eventId, 'n' => $calf, 'p' => $page])],
            ],
            [
                ['text' => '⬅️ Назад', 'callback_data' => cb_pack('screen', ['name' => 'calf_events', 'n' => $calf, 'p' => $page])],
            ],
        ],
    ];
}

function kb_event_delete_confirm(int $calf, int $eventId, int $page): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '✅ Да, удалить', 'callback_data' => cb_pack('event_del_confirm', ['id' => $eventId, 'n' => $calf, 'p' => $page, 'yes' => 1])],
                ['text' => '❌ Отмена', 'callback_data' => cb_pack('screen', ['name' => 'event_view', 'id' => $eventId, 'n' => $calf, 'p' => $page])],
            ],
        ],
    ];
}

function kb_event_add(int $calf): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '🌡 Темп', 'callback_data' => cb_pack('action', ['id' => 'temp', 'n' => $calf])],
                ['text' => '⚖️ Вес', 'callback_data' => cb_pack('action', ['id' => 'weight', 'n' => $calf])],
            ],
            [
                ['text' => '💉 Укол', 'callback_data' => cb_pack('action', ['id' => 'treat', 'n' => $calf])],
                ['text' => '📝 Заметка', 'callback_data' => cb_pack('action', ['id' => 'note', 'n' => $calf])],
            ],
            [
                ['text' => '🎂 Дата рождения', 'callback_data' => cb_pack('action', ['id' => 'birth', 'n' => $calf])],
            ],
            [
                ['text' => '⬅️ Журнал', 'callback_data' => cb_pack('screen', ['name' => 'calf_events', 'n' => $calf, 'p' => 0])],
            ],
        ],
    ];
}

function kb_repeat(): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => "⏱ 12ч", 'callback_data' => cb_pack('repeat', ['h' => 12])],
                ['text' => "⏱ 24ч", 'callback_data' => cb_pack('repeat', ['h' => 24])],
                ['text' => "⏱ 48ч", 'callback_data' => cb_pack('repeat', ['h' => 48])],
            ],
            [
                ['text' => "Без повтора", 'callback_data' => cb_pack('repeat', ['h' => 0])],
                ['text' => "❌ Отмена", 'callback_data' => cb_pack('cancel')],
            ],
        ]
    ];
}
