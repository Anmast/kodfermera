<?php

/**
 * Screens = pure UI functions.
 * Each screen returns [text, kb]
 */

function screens_registry(): array {
    return [
        'menu' => function(array $ctx, array $params = []): array {
            return [
                'text' => "🏠 Главное меню",
                'kb'   => kb_main_menu($ctx),
            ];
        },

        'menu_krs' => function(array $ctx, array $params = []): array {
            return [
                'text' => "🐄 КРС",
                'kb'   => kb_krs_menu($ctx),
            ];
        },

        'krs_find' => function(array $ctx, array $params = []): array {
            return [
                'text' => "🔎 Найти",
                'kb'   => kb_krs_find($ctx),
            ];
        },

        'krs_data' => function(array $ctx, array $params = []): array {
            return [
                'text' => "✍️ Внести данные",
                'kb'   => kb_krs_data_entry(),
            ];
        },

        'ai_help' => function(array $ctx, array $params = []): array {
            $lines = [];
            $lines[] = "🤖 ИИ в группе";
            $lines[] = "";
            $lines[] = "Можно НЕ писать /ask. Достаточно написать сообщение с одним из триггеров:";
            $lines[] = "• Макс …";
            $lines[] = "• спроси у ИИ …";
            $lines[] = "• ИИ …";
            $lines[] = "• бот …";
            $lines[] = "";
            $lines[] = "Примеры:";
            $lines[] = "• Макс, сколько голов?";
            $lines[] = "• спроси у ИИ: кто самый старший";
            $lines[] = "";
            $lines[] = "Если хочешь явно: /ask вопрос";
            return [
                'text' => implode("\n", $lines),
                'kb'   => kb_back_menu(),
            ];
        },

        'calf_edit' => function(array $ctx, array $params = []): array {
            $n = (int)($params['n'] ?? 0);
            if ($n <= 0) return ['text' => 'Неверный номер телёнка.', 'kb' => kb_back_menu()];
            return [
                'text' => "✏️ Редактировать

КРС №{$n}",
                'kb'   => kb_calf_edit($n),
            ];
        },


        'finance_menu' => function(array $ctx, array $params = []): array {
            /** @var FinanceService|null $fin */
            $fin = $ctx['finance'] ?? null;
            $installed = ($fin instanceof FinanceService) && $fin->isInstalled();
            $warn = $installed ? '' : "\n\n⚠️ Финансовые таблицы ещё не установлены (см. db/migrations).";
            return [
                'text' => "💸 Расходы{$warn}\n\nВыбери действие:",
                'kb' => kb_finance_menu(),
            ];
        },

        'finance_categories' => function(array $ctx, array $params = []): array {
            /** @var FinanceService|null $fin */
            $fin = $ctx['finance'] ?? null;
            $cats = ($fin instanceof FinanceService) ? $fin->listCategories('expense') : [];
            $lines = ["🧾 Категории расходов"]; 
            if (!$cats) $lines[] = "\n(пока пусто)";
            else {
                $lines[] = "";
                foreach ($cats as $c) {
                    $lines[] = "• " . (string)($c['name'] ?? '');
                }
            }
            return [
                'text' => implode("\n", $lines),
                'kb' => kb_finance_categories(),
            ];
        },

        'finance_journal' => function(array $ctx, array $params = []): array {
            /** @var FinanceService|null $fin */
            $fin = $ctx['finance'] ?? null;
            $days = max(1, (int)($params['d'] ?? 7));
            $page = max(0, (int)($params['p'] ?? 0));
            $limit = 12;
            $items = ($fin instanceof FinanceService) ? $fin->listTransactions('expense', $days, $limit, $page * $limit) : [];
            $lines = ["📒 Журнал расходов", "Период: последние {$days} дн.", ""]; 
            if (!$items) {
                $lines[] = "(пусто)";
            } else {
                foreach ($items as $it) {
                    $dt = format_dt($it['tx_date'] ?? '');
                    $cat = (string)($it['category'] ?? '');
                    $amt = number_format((float)($it['amount'] ?? 0), 2, '.', '');
                    $cm  = (string)($it['comment'] ?? '');
                    $tail = $cm !== '' ? " — {$cm}" : '';
                    $lines[] = "• {$dt} — {$cat}: {$amt}{$tail}";
                }
            }
            return [
                'text' => implode("\n", $lines),
                'kb' => kb_finance_journal($days, $page, (bool)$items),
            ];
        },

        'payroll_menu' => function(array $ctx, array $params = []): array {
            /** @var PayrollService|null $pay */
            $pay = $ctx['payroll'] ?? null;
            $installed = ($pay instanceof PayrollService) && $pay->isInstalled();
            $warn = $installed ? '' : "\n\n⚠️ Таблицы зарплаты ещё не установлены (см. db/migrations).";
            return [
                'text' => "👷 Зарплата{$warn}\n\nВыбери действие:",
                'kb' => kb_payroll_menu(),
            ];
        },

        'payroll_employees' => function(array $ctx, array $params = []): array {
            /** @var PayrollService|null $pay */
            $pay = $ctx['payroll'] ?? null;
            $emps = ($pay instanceof PayrollService) ? $pay->listEmployees(true) : [];
            $lines = ["👥 Сотрудники"]; 
            if (!$emps) $lines[] = "\n(пока пусто)";
            else {
                $lines[] = "";
                foreach ($emps as $e) {
                    $lines[] = "• #" . (int)$e['id'] . " — " . (string)$e['name'];
                }
            }
            return [
                'text' => implode("\n", $lines),
                'kb' => kb_payroll_employees($emps),
            ];
        },

        'payroll_debts' => function(array $ctx, array $params = []): array {
            /** @var PayrollService|null $pay */
            $pay = $ctx['payroll'] ?? null;
            $rows = ($pay instanceof PayrollService) ? $pay->listDebts() : [];
            $lines = ["📊 Долги по сотрудникам", ""]; 
            if (!$rows) {
                $lines[] = "(пусто)";
            } else {
                foreach ($rows as $r) {
                    $debt = number_format((float)($r['debt'] ?? 0), 2, '.', '');
                    $lines[] = "• " . (string)$r['name'] . " — долг: {$debt}";
                }
            }
            return [
                'text' => implode("\n", $lines),
                'kb' => kb_payroll_debts($rows),
            ];
        },

        'reports_menu' => function(array $ctx, array $params = []): array {
            return [
                'text' => "📊 Отчёты\n\nСкоро добавим: сводка расходов/зарплаты за период.",
                'kb' => [
                    'inline_keyboard' => [
                        [
                            ['text' => '⬅️ Главное меню', 'callback_data' => cb_pack('screen', ['name' => 'menu'])],
                        ],
                    ],
                ],
            ];
        },

        'calves_list' => function(array $ctx, array $params = []): array {
            /** @var CalfService $calves */
            $calves = $ctx['calves'];
            $page = max(0, (int)($params['p'] ?? 0));
            $showAll = ((int)($params['all'] ?? 0) === 1);
            $limit = 8;
            $items = $calves->listCalves($limit, $page * $limit, $showAll);

            $title = $showAll ? '🐄 Все КРС' : '🐄 Список КРС';
            $text = $title . "\n\n";
            if (!$items) {
                $text .= "\n\n(пусто)";
            }
            return [
                'text' => $text,
                'kb' => kb_calves_list($items, $page, $showAll),
            ];
        },

        'calves_archive' => function(array $ctx, array $params = []): array {
            /** @var CalfService $calves */
            $calves = $ctx['calves'];
            $page = max(0, (int)($params['p'] ?? 0));
            $limit = 8;

            // Load with statuses and filter only non-active
            $items = $calves->listCalves($limit, $page * $limit, true);
            $items = array_values(array_filter($items, function($it){
                $s = (string)($it['status'] ?? 'active');
                return in_array($s, ['sold','dead','removed'], true);
            }));

            $text = "📦 Архив КРС (продан/падеж/удалён)\n\nВыбери номер телёнка:";
            if (!$items) $text .= "\n(пусто)";

            return [
                'text' => $text,
                'kb'   => kb_calves_list($items, $page, true),
            ];
        },

        'calf_view' => function(array $ctx, array $params = []): array {
            /** @var CalfService $calves */
            $calves = $ctx['calves'];
            $n = (int)($params['n'] ?? 0);
            if ($n <= 0) {
                return ['text' => 'Неверный номер телёнка.', 'kb' => kb_back_menu()];
            }

            if (!$calves->existsCalf($n)) {
                return ['text' => "Телёнка №{$n} нет. Добавь его кнопкой ➕ в меню.", 'kb' => kb_back_menu()];
            }

            $status = $calves->getLifeStatus($n);
            $statusTxt = match($status) {
                'sold' => '💰 Продан',
                'dead' => '⚰️ Падеж',
                'removed' => '🚫 Удалён',
                default => '✅ Активен',
            };

            $lastNote = $calves->lastValueByType($n, 'note');
            $birthRaw = $calves->getBirthDate($n);
            $birth = $birthRaw ? format_dt($birthRaw, false) : null;
            $qr = $calves->getQrCode($n);

            $lines = [];
            $lines[] = "🐄 Телёнок №{$n}";
            $lines[] = "Статус: {$statusTxt}";
            $lines[] = "🎂 Дата рождения: " . ($birth ?? '—');
            $lines[] = "📝 Заметка: " . ($lastNote ?? '—');
            $lines[] = "🔳 QR: " . ($qr ?? '—');

            $events = $calves->lastEvents($n, 3);
            $lines[] = "";
            $lines[] = "Последние события:";
            if (!$events) {
                $lines[] = "(пока нет)";
            } else {
                foreach ($events as $e) {
                    $lines[] = ui_event_short($e);
                }
            }

            return [
                'text' => implode("\n", $lines),
                'kb' => kb_calf_view($n, $status),
            ];
        },

        'calf_events' => function(array $ctx, array $params = []): array {
            /** @var CalfService $calves */
            $calves = $ctx['calves'];
            $n = (int)($params['n'] ?? 0);
            $page = max(0, (int)($params['p'] ?? 0));
            $typeFilter = isset($params['t']) ? (string)$params['t'] : null;
            if ($n <= 0) {
                return ['text' => 'Неверный номер телёнка.', 'kb' => kb_back_menu()];
            }

            if (!$calves->existsCalf($n)) {
                return ['text' => "Телёнка №{$n} нет.", 'kb' => kb_back_menu()];
            }

            $limit = 10;
            // allow only known filters
            $allowed = ['temp','weight','treatment','note','life','qr','birth'];
            if ($typeFilter !== null && !in_array($typeFilter, $allowed, true)) $typeFilter = null;
            $events = $calves->listEvents($n, $limit, $page * $limit, $typeFilter);
            $lines = [];
            $lines[] = "📒 Журнал событий";
            $lines[] = "Телёнок №{$n}";
            if ($typeFilter) $lines[] = "Фильтр: {$typeFilter}";
            $lines[] = "";
            if (!$events) {
                $lines[] = "(событий нет)";
            } else {
                foreach ($events as $e) {
                    $lines[] = ui_event_short($e);
                }
            }

            return [
                'text' => implode("\n", $lines),
                'kb' => kb_calf_events($n, $events, $page, $typeFilter),
            ];
        },

        'calf_qr' => function(array $ctx, array $params = []): array {
            /** @var CalfService $calves */
            $calves = $ctx['calves'];
            $n = (int)($params['n'] ?? 0);
            if ($n <= 0 || !$calves->existsCalf($n)) {
                return ['text' => 'Телёнок не найден.', 'kb' => kb_back_menu()];
            }

            $code = $calves->getQrCode($n);
            $lines = [];
            $lines[] = "🔳 QR-код телёнка";
            $lines[] = "Телёнок №{$n}";
            $lines[] = "";

            if (!$code) {
                $lines[] = "QR ещё не назначен.";
            } else {
                $lines[] = "Код: {$code}";

                // Optional deep link (works great if you print a QR code with this link)
                $botUser = trim((string)($ctx['config']['bot_username'] ?? ''));
                if ($botUser !== '') {
                    $lines[] = "";
                    $lines[] = "Ссылка для QR:";
                    $lines[] = "https://t.me/{$botUser}?start=qr_{$code}";
                }
            }

            return [
                'text' => implode("\n", $lines),
                'kb' => [
                    'inline_keyboard' => [
                        [
                            ['text' => '♻️ Сгенерировать новый', 'callback_data' => cb_pack('qr_reset', ['n' => $n])],
                            ['text' => '🔎 Поиск по QR', 'callback_data' => cb_pack('qr_search')],
                        ],
                        [
                            ['text' => '🔗 Привязать бирку (QR)', 'callback_data' => cb_pack('qr_bind')],
                        ],
                        [
                            ['text' => '⬅️ Карточка', 'callback_data' => cb_pack('screen', ['name' => 'calf_view', 'n' => $n])],
                        ],
                    ],
                ],
            ];
        },

        'calf_stats' => function(array $ctx, array $params = []): array {
            /** @var CalfService $calves */
            $calves = $ctx['calves'];
            $n = (int)($params['n'] ?? 0);
            if ($n <= 0 || !$calves->existsCalf($n)) {
                return ['text' => 'Телёнок не найден.', 'kb' => kb_back_menu()];
            }

            $warn = (float)($ctx['config']['temp_warn'] ?? 39.5);
            $crit = (float)($ctx['config']['temp_crit'] ?? 40.0);
            $t24 = $calves->tempStats24h($n);
            $weights = $calves->lastTwoWeights($n);

            $lines = [];
            $lines[] = "📊 Статистика";
            $lines[] = "Телёнок №{$n}";
            $lines[] = "";
            $lines[] = "🌡 Температура (24ч):";
            $lines[] = "• записей: " . (int)($t24['count'] ?? 0);
            if (($t24['count'] ?? 0) > 0) {
                $avg = $t24['avg'] !== null ? number_format((float)$t24['avg'], 1, '.', '') : '—';
                $min = $t24['min'] !== null ? number_format((float)$t24['min'], 1, '.', '') : '—';
                $max = $t24['max'] !== null ? number_format((float)$t24['max'], 1, '.', '') : '—';
                $badge = '';
                if ((float)$max >= $crit) $badge = ' 🚨';
                elseif ((float)$max >= $warn) $badge = ' 🔥';
                $lines[] = "• средняя: {$avg}";
                $lines[] = "• мин: {$min}";
                $lines[] = "• макс: {$max}{$badge}";
            }

            $lines[] = "";
            $lines[] = "⚖️ Вес:";
            if (!$weights) {
                $lines[] = "• записей нет";
            } else {
                $w1 = (float)($weights[0]['value'] ?? 0);
                $d1 = format_dt($weights[0]['created_at'] ?? '');
                $lines[] = "• {$d1}: {$w1}";
                if (isset($weights[1])) {
                    $w2 = (float)($weights[1]['value'] ?? 0);
                    $d2 = format_dt($weights[1]['created_at'] ?? '');
                    $delta = $w1 - $w2;
                    $sign = $delta >= 0 ? '+' : '';
                    $lines[] = "• {$d2}: {$w2}";
                    $lines[] = "Δ: {$sign}" . number_format($delta, 1, '.', '') . " кг";
                }
            }

            return [
                'text' => implode("\n", $lines),
                'kb' => [
                    'inline_keyboard' => [
                        [
                            ['text' => '⬅️ Карточка', 'callback_data' => cb_pack('screen', ['name' => 'calf_view', 'n' => $n])],
                            ['text' => '📒 Журнал', 'callback_data' => cb_pack('screen', ['name' => 'calf_events', 'n' => $n, 'p' => 0])],
                        ],
                    ],
                ],
            ];
        },

        'event_view' => function(array $ctx, array $params = []): array {
            /** @var CalfService $calves */
            $calves = $ctx['calves'];
            $id = (int)($params['id'] ?? 0);
            $n = (int)($params['n'] ?? 0);
            $page = max(0, (int)($params['p'] ?? 0));
            if ($id <= 0) {
                return ['text' => 'Событие не найдено.', 'kb' => kb_back_menu()];
            }

            $ev = $calves->getEvent($id);
            if (!$ev) {
                return ['text' => 'Событие не найдено (возможно уже удалено).', 'kb' => kb_back_menu()];
            }

            $calf = (int)($ev['calf_number'] ?? $n);
            $type = (string)($ev['type'] ?? '');
            $val  = (string)($ev['value'] ?? '');
            $dt   = format_dt($ev['created_at'] ?? '');

            $lines = [];
            $lines[] = "🧾 Событие #{$id}";
            $lines[] = "Телёнок №{$calf}";
            $lines[] = "Тип: {$type}";
            $lines[] = "Дата: {$dt}";
            $lines[] = "";
            $lines[] = "Значение: {$val}";

            return [
                'text' => implode("\n", $lines),
                'kb' => kb_event_view($calf, $id, $page),
            ];
        },

        'event_add' => function(array $ctx, array $params = []): array {
            $n = (int)($params['n'] ?? 0);
            if ($n <= 0) {
                return ['text' => 'Неверный номер телёнка.', 'kb' => kb_back_menu()];
            }
            return [
                'text' => "➕ Добавить событие\n\nТелёнок №{$n}\n\nВыбери тип события кнопкой:",
                'kb' => kb_event_add($n),
            ];
        },
    ];
}

function screen_get(string $name): ?callable {
    $reg = screens_registry();
    return $reg[$name] ?? null;
}
