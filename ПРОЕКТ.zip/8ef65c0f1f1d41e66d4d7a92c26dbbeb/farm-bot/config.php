<?php
return [
    'bot_token' => '7974406545:AAHt-o0twJvRAhqfhafL8lP6Ymt8S7QVW8s',

    // Optional: bot username (without @). If set, QR screen will show deep-link for printable QR codes.
    // Example: 'MyFarmBot'
    'bot_username' => 'FarmChatGPT_bot',

    'chat_work'    => -1003535415050,   // рабочая группа
    'chat_control' => -1003790559764,   // контроль
    'chat_dialog'  => -1003748652810,   // диалог (ОБЯЗАТЕЛЬНО с минусом)

    'db' => [
        'dsn' => 'mysql:host=localhost;dbname=bantoha_kodferme;charset=utf8mb4',
        'user' => 'bantoha_kodferme',
        'pass' => 'UzQPYZH5%dGe',
    ],

    'temp_warn' => 39.5,
    'temp_crit' => 40.0,

    // Optional: HTTPS URL of QR scan WebApp (Telegram WebApp). Example:
    // https://YOUR-DOMAIN/qr/index.html
    'webapp_qr_url' => 'https://kodfermera.ru/farm-bot/qr/index.html',

    // OpenAI settings (optional) for /ask, voice transcription, and photo analysis
    'openai' => [
        // Put your API key here if you want AI features.
        'api_key' => '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',
        // Responses API model for answers (text + vision)
        'model' => 'gpt-4o-mini',
        // Speech-to-text model
        'stt_model' => 'gpt-4o-mini-transcribe',
    ],

];
