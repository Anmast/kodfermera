<?php
// farm-bot/router.php

$config = require __DIR__ . '/config.php';
$pdo    = require __DIR__ . '/db.php';

require __DIR__ . '/telegram.php';
require __DIR__ . '/services/Parser.php';
require __DIR__ . '/services/CalfService.php';
require __DIR__ . '/services/AlertService.php';
require __DIR__ . '/services/StateService.php';

$calves = new CalfService($pdo);
$alerts = new AlertService($config);
$states = new StateService($pdo);

/**
 * INLINE клавиатуры
 */
function menu_keyboard(): string {
    $kb = [
        'inline_keyboard' => [
            [
                ['text' => "🌡 Температура", 'callback_data' => 'act:temp'],
                ['text' => "💉 Укол",        'callback_data' => 'act:treat'],
            ],
            [
                ['text' => "📝 Заметка",     'callback_data' => 'act:note'],
                ['text' => "⚖️ Вес",         'callback_data' => 'act:weight'],
            ],
            [
                ['text' => "📋 Статус",      'callback_data' => 'act:status'],
            ],
            [
                ['text' => "❌ Отмена",      'callback_data' => 'act:cancel'],
            ],
        ]
    ];
    return json_encode($kb, JSON_UNESCAPED_UNICODE);
}

function repeat_keyboard(): string {
    $kb = [
        'inline_keyboard' => [
            [
                ['text' => "⏱ 12ч", 'callback_data' => 'rep:12'],
                ['text' => "⏱ 24ч", 'callback_data' => 'rep:24'],
                ['text' => "⏱ 48ч", 'callback_data' => 'rep:48'],
            ],
            [
                ['text' => "Без повтора", 'callback_data' => 'rep:0'],
                ['text' => "❌ Отмена", 'callback_data' => 'act:cancel'],
            ],
        ]
    ];
    return json_encode($kb, JSON_UNESCAPED_UNICODE);
}

/**
 * Безопасное удаление сообщения (не валим роутер, если нельзя удалить)
 */
function safe_delete(array $config, int $chatId, int $messageId): void {
    if ($messageId <= 0) return;
    try {
        tg_delete($config['bot_token'], $chatId, $messageId);
    } catch (\Throwable $e) {
        // ignore
    }
}

/**
 * Удалить позже, не задерживая ответ Telegram webhook'у
 */
function delete_later(array $config, int $chatId, array $messageIds, int $seconds = 5): void {
    if (function_exists('fastcgi_finish_request')) {
        @fastcgi_finish_request();
    }
    sleep(max(0, $seconds));
    foreach ($messageIds as $mid) {
        safe_delete($config, $chatId, (int)$mid);
    }
}

/**
 * flow message id из state payload
 */
function get_flow_id(?array $state): int {
    if (!$state) return 0;
    $payload = $state['payload'] ?? null;
    if (!is_array($payload)) return 0;
    return (int)($payload['flow_msg_id'] ?? 0);
}

/**
 * Показать текст в мастер-сообщении (редактирование),
 * если flowMsgId=0 — отправляем новое и возвращаем его id.
 */
function flow_show(array $config, int $chatId, int $flowMsgId, string $text, ?string $replyMarkup = null): int {
    $extra = [];
    if ($replyMarkup) $extra['reply_markup'] = $replyMarkup;

    if ($flowMsgId > 0) {
        tg_edit($config['bot_token'], $chatId, $flowMsgId, $text, $extra);
        return $flowMsgId;
    }

    $res = tg_send($config['bot_token'], $chatId, $text, $extra);
    return (int)($res['result']['message_id'] ?? 0);
}

/**
 * Нормализация ввода
 */
function normalize_text(string $s): string {
    $s = trim($s);
    $s = preg_replace('/\s+/u', ' ', $s);
    return $s;
}

// ===================== входящий апдейт =====================
$update = json_decode(file_get_contents("php://input"), true);
if (!$update) exit;

@file_put_contents(__DIR__.'/logs/in.log', date('c')." keys=".implode(',', array_keys($update))."\n", FILE_APPEND);

$msg =
    $update['message']
    ?? $update['edited_message']
    ?? $update['channel_post']
    ?? $update['edited_channel_post']
    ?? null;

$callback = $update['callback_query'] ?? null;

// ===================== CALLBACK (нажатия кнопок) =====================
if ($callback) {
    $chatId    = (int)$callback['message']['chat']['id'];
    $userId    = (int)$callback['from']['id'];
    $data      = (string)$callback['data'];
    $cbId      = (string)$callback['id'];
    $flowMsgId = (int)$callback['message']['message_id'];

    tg_answer_callback($config['bot_token'], $cbId, '');

    // Отмена
    if ($data === 'act:cancel') {
        $states->clear($chatId, $userId);
        flow_show($config, $chatId, $flowMsgId, "Ок, отменил ✅\n\n/menu — открыть меню");
        exit;
    }

    // Выбор действия
    if (preg_match('/^act:(temp|treat|note|weight|status)$/', $data, $m)) {
        $action = $m[1];

        // сохраняем flow_msg_id, чтобы дальше всегда редактировать это сообщение
        $states->set($chatId, $userId, $action, 1, null, ['flow_msg_id' => $flowMsgId]);

        $map = [
            'temp'   => "🌡 Температура\n\nВведи номер телёнка (например 249)",
            'treat'  => "💉 Укол\n\nВведи номер телёнка (например 249)",
            'note'   => "📝 Заметка\n\nВведи номер телёнка (например 249)",
            'weight' => "⚖️ Вес\n\nВведи номер телёнка (например 249)",
            'status' => "📋 Статус\n\nВведи номер телёнка (например 249)",
        ];

        flow_show($config, $chatId, $flowMsgId, $map[$action] . "\n\n/cancel — отмена | /menu — меню");
        exit;
    }

    // Выбор повтора для укола
    if (preg_match('/^rep:(\d+)$/', $data, $m)) {
        $hours = (int)$m[1];
        $st = $states->get($chatId, $userId);

        if (!$st || $st['action'] !== 'treat' || (int)$st['step'] !== 3) {
            flow_show($config, $chatId, $flowMsgId, "Сессия устарела. /menu");
            exit;
        }

        $payload = is_array($st['payload'] ?? null) ? $st['payload'] : [];
        $flowId  = (int)($payload['flow_msg_id'] ?? $flowMsgId);
        $calf    = (int)$st['calf_number'];
        $drugDose = (string)($payload['drugDose'] ?? '');

        // записываем укол
        $calves->ensureCalf($calf);
        $calves->addEvent(
            $calf,
            'treatment',
            $drugDose,
            $chatId,
            $callback['from']['username'] ?? ($callback['from']['first_name'] ?? null)
        );

        // напоминание
        $extra = "";
        if ($hours > 0) {
            $due = (new DateTime('now'))->modify("+{$hours} hours")->format('Y-m-d H:i:s');
            $text = "⏰ Повтор укола для №{$calf}: {$drugDose} (через {$hours}ч)";
            $stmt = $pdo->prepare("INSERT INTO reminders(calf_number, due_at, text) VALUES (?,?,?)");
            $stmt->execute([$calf, $due, $text]);
            $extra = "\n\nНапоминание поставил ✅";
        } else {
            $extra = "\n\nПовтор не ставил ✅";
        }

        // показываем итог (обновляем мастер-сообщение), удаляем через 5 сек
        $states->clear($chatId, $userId);
        flow_show($config, $chatId, $flowId, "✅ Записал укол\n\n№{$calf}: {$drugDose}{$extra}");
        delete_later($config, $chatId, [$flowId], 5);
        exit;
    }

    exit;
}

// ===================== MESSAGE (обычные сообщения) =====================
if (!$msg) exit;

$chatId     = (int)$msg['chat']['id'];
$userId     = (int)($msg['from']['id'] ?? 0);
$userMsgId  = (int)($msg['message_id'] ?? 0);
$text       = (string)($msg['text'] ?? '');
$user       = $msg['from']['username'] ?? ($msg['from']['first_name'] ?? null);

$parsed = Parser::parseText($text);
@file_put_contents(__DIR__.'/logs/parsed.log', date('c')." chat={$chatId} text=[".$text."] parsed=".json_encode($parsed, JSON_UNESCAPED_UNICODE)."\n", FILE_APPEND);

// ==== /menu и /cancel должны удалять сообщение пользователя (чистим чат)
if ($parsed['type'] === 'sys' && in_array($parsed['cmd'], ['menu','cancel'], true)) {
    safe_delete($config, $chatId, $userMsgId);
}

// ==== /id и ping можно тоже удалять (по желанию) — оставлю включенным:
if ($parsed['type'] === 'sys' && in_array($parsed['cmd'], ['id','ping'], true)) {
    safe_delete($config, $chatId, $userMsgId);
}

// ===================== sys: id/ping/cancel/menu =====================
if ($parsed['type'] === 'sys' && $parsed['cmd'] === 'id') {
    tg_send($config['bot_token'], $chatId, "chat_id: {$chatId}");
    exit;
}

if ($parsed['type'] === 'sys' && $parsed['cmd'] === 'ping') {
    tg_send($config['bot_token'], $chatId, "pong");
    exit;
}

if ($parsed['type'] === 'sys' && $parsed['cmd'] === 'cancel') {
    $states->clear($chatId, $userId);
    // Если есть мастер-сообщение — обновим его, иначе просто ничего
    $st = $states->get($chatId, $userId);
    $flowId = get_flow_id($st);
    if ($flowId > 0) {
        flow_show($config, $chatId, $flowId, "Ок, отменил ✅\n\n/menu — меню");
    } else {
        tg_send($config['bot_token'], $chatId, "Ок, отменил ✅\n/menu — меню");
    }
    exit;
}

/**
 * ВАЖНО: /menu должен НЕ плодить сообщения.
 * Если мастер-сообщение уже есть — редактируем.
 * Если нет — создаём одно и сохраняем flow_msg_id в state (idle).
 */
if ($parsed['type'] === 'sys' && $parsed['cmd'] === 'menu') {
    $st = $states->get($chatId, $userId);
    $flowId = get_flow_id($st);

    // сбрасываем текущую сессию, но сохраняем flow_msg_id
    $newFlow = $flowId;

    if ($newFlow > 0) {
        $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $newFlow]);
        flow_show($config, $chatId, $newFlow, "Выбери действие:", menu_keyboard());
    } else {
        $newFlow = flow_show($config, $chatId, 0, "Выбери действие:", menu_keyboard());
        if ($newFlow > 0) {
            $states->set($chatId, $userId, 'idle', 0, null, ['flow_msg_id' => $newFlow]);
        }
    }

    exit;
}

// ===================== Пошаговый режим (state) =====================
$st = $states->get($chatId, $userId);
if ($st) {
    // Любой ввод пользователя в шаговом режиме — удаляем его сообщение
    safe_delete($config, $chatId, $userMsgId);

    $action  = (string)$st['action'];
    $step    = (int)$st['step'];
    $payload = is_array($st['payload'] ?? null) ? $st['payload'] : [];
    $flowId  = (int)($payload['flow_msg_id'] ?? 0);

    // step 1: ждём номер телёнка
    if ($step === 1) {
        $num = trim($text);
        if (!preg_match('/^\d+$/', $num)) {
            flow_show($config, $chatId, $flowId, "Нужен номер телёнка цифрами, например: 249\n\n/cancel — отмена | /menu — меню");
            exit;
        }

        $calf = (int)$num;
        $payload['flow_msg_id'] = $flowId;
        $states->set($chatId, $userId, $action, 2, $calf, $payload);

        // статус — сразу показываем и удаляем через 5 сек
        if ($action === 'status') {
            $lastTemp = $calves->lastTemp($calf);
            $events   = $calves->lastEvents($calf, 8);

            $lines = ["🐄 Телёнок №{$calf}"];
            $lines[] = "Последняя температура: " . ($lastTemp !== null ? $lastTemp : "нет данных");
            $lines[] = "";
            $lines[] = "Последние события:";
            foreach ($events as $e) {
                $lines[] = "• {$e['created_at']} — {$e['type']}: {$e['value']}";
            }

            $states->clear($chatId, $userId);
            flow_show($config, $chatId, $flowId, implode("\n", $lines));
            delete_later($config, $chatId, [$flowId], 5);
            exit;
        }

        $prompt = match ($action) {
            'temp'   => "🌡 Температура\n\nВведи температуру для №{$calf} (например 39.8)",
            'treat'  => "💉 Укол\n\nВведи препарат и дозу для №{$calf} (например: азитронит 3мл)",
            'note'   => "📝 Заметка\n\nВведи заметку для №{$calf} (например: плохо ест)",
            'weight' => "⚖️ Вес\n\nВведи вес для №{$calf} (например 42.5)",
            default  => "Введи значение…",
        };

        flow_show($config, $chatId, $flowId, $prompt . "\n\n/cancel — отмена | /menu — меню");
        exit;
    }

    // step 2: ждём значение
    if ($step === 2) {
        $calf  = (int)$st['calf_number'];
        $value = normalize_text($text);

        // температура
        if ($action === 'temp') {
            if (!preg_match('/^[0-9]+([.,][0-9]+)?$/', $value)) {
                flow_show($config, $chatId, $flowId, "Температура должна быть числом, например 39.8\n\n/cancel — отмена | /menu — меню");
                exit;
            }
            $temp = (float)str_replace(',', '.', $value);

            $calves->ensureCalf($calf);
            $calves->addEvent($calf, 'temp', (string)$temp, $chatId, $user);

            $alert = $alerts->checkTemp($calf, $temp);
            if ($alert && (int)$config['chat_control'] !== 0) {
                tg_send($config['bot_token'], (int)$config['chat_control'], $alert);
            }

            $states->clear($chatId, $userId);
            flow_show($config, $chatId, $flowId, "✅ Записал: №{$calf} температура {$temp}");
            delete_later($config, $chatId, [$flowId], 5);
            exit;
        }

        // укол → шаг 3 (кнопки повтора)
        if ($action === 'treat') {
            if (mb_strlen($value) < 2) {
                flow_show($config, $chatId, $flowId, "Слишком коротко. Пример: азитронит 3мл\n\n/cancel — отмена | /menu — меню");
                exit;
            }

            $payload['flow_msg_id'] = $flowId;
            $payload['drugDose'] = $value;

            $states->set($chatId, $userId, 'treat', 3, $calf, $payload);

            flow_show(
                $config,
                $chatId,
                $flowId,
                "💉 Укол\n\n№{$calf}: {$value}\n\nНужен повтор?\nВыбери кнопкой:",
                repeat_keyboard()
            );
            exit;
        }

        // заметка
        if ($action === 'note') {
            $calves->ensureCalf($calf);
            $calves->addEvent($calf, 'note', $value, $chatId, $user);

            $states->clear($chatId, $userId);
            flow_show($config, $chatId, $flowId, "✅ Заметка по №{$calf} сохранена.");
            delete_later($config, $chatId, [$flowId], 5);
            exit;
        }

        // вес
        if ($action === 'weight') {
            if (!preg_match('/^[0-9]+([.,][0-9]+)?$/', $value)) {
                flow_show($config, $chatId, $flowId, "Вес должен быть числом, например 42.5\n\n/cancel — отмена | /menu — меню");
                exit;
            }
            $w = (float)str_replace(',', '.', $value);

            $calves->ensureCalf($calf);
            $calves->addEvent($calf, 'weight', (string)$w, $chatId, $user);

            $states->clear($chatId, $userId);
            flow_show($config, $chatId, $flowId, "✅ Вес №{$calf}: {$w}");
            delete_later($config, $chatId, [$flowId], 5);
            exit;
        }

        // неизвестно
        $states->clear($chatId, $userId);
        flow_show($config, $chatId, $flowId, "Сессия сбилась. /menu");
        exit;
    }

    // step 3 treat: ждём кнопку rep
    if ($step === 3 && $action === 'treat') {
        // если пользователь что-то написал вместо кнопки — удаляем и напоминаем
        flow_show($config, $chatId, $flowId, "Выбери повтор кнопкой выше 👆\n\n/cancel — отмена | /menu — меню", repeat_keyboard());
        exit;
    }
}

// ===================== Если не в сессии — игнор или подсказка =====================
// В рабочей группе лучше не флудить ответами:
$isWork = ((int)$config['chat_work'] !== 0 && $chatId === (int)$config['chat_work']);
if ($isWork) {
    // можно удалить обычный текст, если хочешь “стерильный чат”:
    // safe_delete($config, $chatId, $userMsgId);
    exit;
}

// В остальных — подсказываем
tg_send($config['bot_token'], $chatId, "Нажми /menu");
