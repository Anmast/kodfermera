<?php
require __DIR__ . '/app/bootstrap.php';
require __DIR__ . '/app/handlers_callback.php';
require __DIR__ . '/app/handlers_message.php';

$update = json_decode(file_get_contents("php://input"), true);
if (!$update) exit;

@file_put_contents(__DIR__.'/logs/in.log', date('c')." keys=".implode(',', array_keys($update))."\n", FILE_APPEND);

if (!empty($update['callback_query'])) {
    handle_callback($update['callback_query']);
    exit;
}

$msg =
    $update['message']
    ?? $update['edited_message']
    ?? $update['channel_post']
    ?? $update['edited_channel_post']
    ?? null;

if ($msg) {
    handle_message($msg);
}
