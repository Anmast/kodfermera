# Архитектура проекта

## Корень домена (`public_html/`)
- `bot/webhook.php` — webhook Telegram, подключает `/farm-bot/router.php`
- `farm-bot/` — основная логика Telegram-бота
- `site/` — публичная часть сайта
- `api/` — API публичной части

## Внутри `farm-bot/`
### Точки входа
- `router.php` — вход Telegram updates
- `telegram.php` — Telegram Bot API helpers
- `config.php` — конфиг
- `db.php` — подключение к MySQL

### Папка `app/`
- `bootstrap.php` — сборка зависимостей
- `handlers_message.php` — сообщения, системные команды, шаговые сценарии, AI-триггеры
- `handlers_callback.php` — inline callbacks
- `flow.php` — master-message и синхронизация нижней клавиатуры
- `screens.php` — экраны (`text + kb`)
- `ui.php` — все клавиатуры и форматирование
- `utils.php` — общие хелперы, KV, throttle, reply-keyboard modes
- `actions.php` — стандартные действия по телятам

### Папка `services/`
- `CalfService.php` — телята, события, QR, статус, дата рождения
- `StateService.php` — `user_states`
- `SchemaService.php` — создание/смягчение таблиц
- `AiService.php` — OpenAI
- `AiDbAgent.php` — AI доступ к базе
- `ChatLogService.php` — контекст чата
- `FinanceService.php` — расходы
- `PayrollService.php` — зарплата
- `AlertService.php` — алерты
- `Parser.php` — распознавание текстовых кнопок/команд

### Остальное
- `webapp/qr/` — камера телефона для скана QR
- `jobs/` — cron
- `logs/` — логи
- `docs/` — документация

## Модульные зоны для патчей
- **Telegram UI**: `app/*`, `services/Parser.php`, иногда `telegram.php`
- **AI**: `services/AiService.php`, `services/AiDbAgent.php`, `app/handlers_message.php`
- **Финансы/зарплата**: `services/FinanceService.php`, `services/PayrollService.php`, связанные экраны и callback-обработчики
- **QR / WebApp**: `webapp/qr/*`, QR-роуты в `app/*`
- **Публичный сайт**: `site/*`, `api/*`
