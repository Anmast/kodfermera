# Патчи по модулям

## Рекомендуемые типы патчей
### 1. Telegram UI
Что обычно меняется:
- `farm-bot/app/handlers_message.php`
- `farm-bot/app/handlers_callback.php`
- `farm-bot/app/ui.php`
- `farm-bot/app/screens.php`
- `farm-bot/app/flow.php`
- `farm-bot/app/utils.php`
- `farm-bot/services/Parser.php`

Название:
- `patch-tg-ui-stepXX.zip`

### 2. AI / DB Agent
- `farm-bot/services/AiService.php`
- `farm-bot/services/AiDbAgent.php`
- `farm-bot/services/ChatLogService.php`
- `farm-bot/app/handlers_message.php`

Название:
- `patch-ai-stepXX.zip`

### 3. Финансы / зарплата
- `farm-bot/services/FinanceService.php`
- `farm-bot/services/PayrollService.php`
- `farm-bot/app/screens.php`
- `farm-bot/app/handlers_message.php`
- `farm-bot/app/handlers_callback.php`

Название:
- `patch-finance-stepXX.zip`

### 4. QR / камера
- `farm-bot/webapp/qr/*`
- QR-связанные роуты в `app/handlers_*`

Название:
- `patch-qr-stepXX.zip`

### 5. Публичный сайт
- `site/*`
- `api/*`

Название:
- `patch-web-stepXX.zip`

## Правила
1. Не включать `config.php` с секретами
2. Класть в zip реальные пути, как на сервере
3. Добавлять краткий changelog в `VERSION.txt` или отдельный md
4. Перед заливкой делать backup
