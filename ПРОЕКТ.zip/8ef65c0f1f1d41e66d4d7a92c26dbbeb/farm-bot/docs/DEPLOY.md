# Деплой и настройка

## Webhook
Webhook расположен в `public_html/bot/webhook.php`.
Он подключает бот из `../farm-bot`.

Проверка доступности:
- Открой `https://<domain>/bot/webhook.php` — должен вернуть `OK`.

## Cron
Если используются напоминания:
- `farm-bot/jobs/reminders.php`

## База данных
При старте `app/bootstrap.php` вызывает `SchemaService->ensure()`:
- создаёт недостающие таблицы
- пытается смягчить старую схему (`events.type` ENUM → VARCHAR(32))

Если ты уже сделал:
- `ALTER TABLE events MODIFY type VARCHAR(32) NOT NULL;`
то `SchemaService` больше не мешает.

