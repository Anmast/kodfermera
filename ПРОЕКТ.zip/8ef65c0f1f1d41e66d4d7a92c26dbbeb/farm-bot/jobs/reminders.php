<?php
// farm-bot/jobs/reminders.php

$config = require __DIR__ . '/../config.php';
$pdo    = require __DIR__ . '/../db.php';
require __DIR__ . '/../telegram.php';

date_default_timezone_set('Europe/Riga');

$limit = 50;

$stmt = $pdo->prepare("
  SELECT id, calf_number, due_at, text
  FROM reminders
  WHERE sent = 0 AND due_at <= NOW()
  ORDER BY due_at ASC
  LIMIT {$limit}
");
$stmt->execute();
$rows = $stmt->fetchAll();

if (!$rows) {
    echo "NO DUE\n";
    exit;
}

$controlChat = (int)($config['chat_control'] ?? 0);
if ($controlChat === 0) {
    echo "NO CONTROL CHAT\n";
    exit;
}

$markSent = $pdo->prepare("UPDATE reminders SET sent = 1 WHERE id = ?");

$sentCount = 0;
$failCount = 0;

foreach ($rows as $r) {
    $dueAtStr = (string)$r['due_at'];
    $unix = strtotime($dueAtStr);
    if ($unix === false) $unix = time();

    // Bot API 9.5: localized date/time (auto adapts to each recipient)
    $when = tg_time_html((int)$unix, 'wDT');

    $msg = "⏰ <b>Напоминание</b>\n".
           htmlspecialchars((string)$r['text'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8').
           "\n⏱ Время: {$when}";

    $res = tg_send($config['bot_token'], $controlChat, $msg, [
        'parse_mode' => 'HTML',
        // Protect from forwarding/copying
        'protect_content' => true,
        'disable_web_page_preview' => true,
    ]);

    // помечаем отправленным только если ok=true
    if (is_array($res) && ($res['ok'] ?? false) === true) {
        $markSent->execute([(int)$r['id']]);
        $sentCount++;
    } else {
        // остаётся sent=0, попробуем в следующий запуск
        $failCount++;
    }
}

echo "SENT={$sentCount} FAIL={$failCount}\n";
