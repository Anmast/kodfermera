<?php
require __DIR__ . '/_bootstrap.php';

$now = time();
$ttl = 120; // 2 ������
$token = random_token(24);

$pdo = pdo();
$stmt = $pdo->prepare("INSERT INTO login_tokens(token, created_at, expires_at) VALUES(:t, :c, :e)");
$stmt->execute([
    ':t' => $token,
    ':c' => $now,
    ':e' => $now + $ttl,
]);

$link = "https://t.me/" . BOT_USERNAME . "?start=" . $token;

json_out([
    'ok' => true,
    'token' => $token,
    'expires_in' => $ttl,
    'tg_link' => $link,
]);