<?php
declare(strict_types=1);

session_start();

const DB_PATH = __DIR__ . '/../db/app.sqlite';

// !!! ������ ����� ����
const BOT_TOKEN = '8796337792:AAFTi-tRDj4Fpbb2gxzBD1kJUmVaU65PcUM';

// ��� QR-������ (�������� ���� ��� @)
const BOT_USERNAME = 'tegrammQR_bot';

function pdo(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $pdo;
}

function json_out(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function random_token(int $bytes = 24): string {
    return rtrim(strtr(base64_encode(random_bytes($bytes)), '+/', '-_'), '=');
}