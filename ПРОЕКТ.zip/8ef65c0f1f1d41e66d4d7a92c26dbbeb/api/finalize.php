<?php
require __DIR__ . '/_bootstrap.php';

$token = $_POST['token'] ?? '';
if (!is_string($token) || $token === '') {
    json_out(['ok' => false, 'error' => 'token_required'], 400);
}

$pdo = pdo();
$pdo->beginTransaction();

$stmt = $pdo->prepare("SELECT token, expires_at, consumed_at, tg_user_id, tg_username, tg_first_name, tg_last_name
                       FROM login_tokens WHERE token = :t");
$stmt->execute([':t' => $token]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    $pdo->rollBack();
    json_out(['ok' => false, 'error' => 'token_not_found'], 404);
}

$now = time();
if ((int)$row['expires_at'] < $now) {
    $pdo->rollBack();
    json_out(['ok' => false, 'error' => 'token_expired'], 403);
}

if (!empty($row['consumed_at'])) {
    $pdo->rollBack();
    json_out(['ok' => false, 'error' => 'token_used'], 403);
}

if (empty($row['tg_user_id'])) {
    $pdo->rollBack();
    json_out(['ok' => false, 'error' => 'not_confirmed_yet'], 409);
}

// �������� ����� ��������������
$upd = $pdo->prepare("UPDATE login_tokens SET consumed_at = :u WHERE token = :t AND consumed_at IS NULL");
$upd->execute([':u' => $now, ':t' => $token]);

$pdo->commit();

// ������ ������
$_SESSION['user'] = [
    'id' => (int)$row['tg_user_id'],
    'username' => $row['tg_username'],
    'first_name' => $row['tg_first_name'],
    'last_name' => $row['tg_last_name'],
];

json_out(['ok' => true, 'status' => 'logged_in']);