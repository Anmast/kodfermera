<?php
require __DIR__ . '/_bootstrap.php';

$token = $_GET['token'] ?? '';
if (!is_string($token) || $token === '') {
    json_out(['ok' => false, 'error' => 'token_required'], 400);
}

$pdo = pdo();
$stmt = $pdo->prepare("SELECT token, expires_at, consumed_at, tg_user_id, tg_username, tg_first_name, tg_last_name
                       FROM login_tokens WHERE token = :t");
$stmt->execute([':t' => $token]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) json_out(['ok' => false, 'error' => 'token_not_found'], 404);

$now = time();
if ((int)$row['expires_at'] < $now) {
    json_out(['ok' => true, 'status' => 'expired']);
}

if (!empty($row['consumed_at'])) {
    json_out(['ok' => true, 'status' => 'used']);
}

if (!empty($row['tg_user_id'])) {
    json_out([
        'ok' => true,
        'status' => 'confirmed',
        'user' => [
            'id' => (int)$row['tg_user_id'],
            'username' => $row['tg_username'],
            'first_name' => $row['tg_first_name'],
            'last_name' => $row['tg_last_name'],
        ]
    ]);
}

json_out(['ok' => true, 'status' => 'pending']);