<?php
declare(strict_types=1);

$dbFile = __DIR__ . '/app.sqlite';
$pdo = new PDO('sqlite:' . $dbFile);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$pdo->exec("
CREATE TABLE IF NOT EXISTS login_tokens (
  token TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  consumed_at INTEGER NULL,

  tg_user_id INTEGER NULL,
  tg_username TEXT NULL,
  tg_first_name TEXT NULL,
  tg_last_name TEXT NULL
);

CREATE INDEX IF NOT EXISTS idx_login_tokens_expires ON login_tokens(expires_at);
");

echo "OK: DB initialized at " . htmlspecialchars($dbFile, ENT_QUOTES); 