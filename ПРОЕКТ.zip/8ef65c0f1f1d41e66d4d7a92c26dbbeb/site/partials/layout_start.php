<?php declare(strict_types=1); ?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= site_e($title) ?></title>
  <link rel="icon" href="/site/assets/logo.jpg">
  <link rel="stylesheet" href="/site/assets/app.css">
</head>
<body class="<?= site_e($bodyClass) ?>">
<div class="app-shell">
  <aside class="sidebar">
    <a href="<?= site_url('/') ?>" class="brand">
      <img src="/site/assets/logo.jpg" alt="Код Фермера" class="brand-logo">
      <div>
        <div class="brand-title">Код Фермера</div>
        <div class="brand-subtitle">Панель хозяйства</div>
      </div>
    </a>

    <nav class="nav">
      <a href="<?= site_url('/') ?>" class="nav-link <?= $pageId === 'home' ? 'active' : '' ?>">Главная</a>
      <a href="<?= site_url('/cattle') ?>" class="nav-link <?= $pageId === 'cattle' ? 'active' : '' ?>">КРС</a>
      <a href="<?= site_url('/expenses') ?>" class="nav-link <?= $pageId === 'expenses' ? 'active' : '' ?>">Расходы</a>
      <a href="<?= site_url('/admin') ?>" class="nav-link <?= $pageId === 'admin' ? 'active' : '' ?>">Админка</a>
    </nav>

    <div class="sidebar-card">
      <div class="sidebar-card-title">Быстрый контроль</div>
      <ul class="sidebar-list">
        <li>На главной — последние изменения и тревожные сигналы.</li>
        <li>В КРС — поиск, фильтры и быстрый просмотр карточек.</li>
        <li>В расходах — аналитика, категории и выгрузка CSV.</li>
        <li>Админка — для оперативного внесения данных.</li>
      </ul>
    </div>
  </aside>

  <main class="content">
    <?php if (is_array($flash)): ?>
      <div class="flash flash-<?= site_e((string)($flash['type'] ?? 'ok')) ?>"><?= site_e((string)($flash['message'] ?? '')) ?></div>
    <?php endif; ?>
