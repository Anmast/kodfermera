<?php
declare(strict_types=1);

require __DIR__ . '/lib.php';
site_check_access();

$pdo = site_pdo();
if (!site_ensure_finance_tables($pdo)) {
    http_response_code(404);
    echo 'finance_not_installed';
    exit;
}

$days = max(1, min(3650, (int)($_GET['days'] ?? 90)));
$category = trim((string)($_GET['category'] ?? ''));

$where = ["t.type='expense'", "t.tx_date >= (NOW() - INTERVAL :days DAY)"];
if ($category !== '') {
    $where[] = "COALESCE(c.name, 'Без категории') = :category";
}
$sql = "SELECT DATE_FORMAT(t.tx_date, '%Y-%m-%d %H:%i:%s') AS tx_date, COALESCE(c.name, 'Без категории') AS category, ROUND(t.amount,2) AS amount, COALESCE(t.comment,'') AS comment\n" .
    "FROM finance_transactions t\n" .
    "LEFT JOIN finance_categories c ON c.id=t.category_id\n" .
    "WHERE " . implode(' AND ', $where) . "\n" .
    "ORDER BY t.tx_date DESC, t.id DESC";
$st = $pdo->prepare($sql);
$st->bindValue(':days', $days, PDO::PARAM_INT);
if ($category !== '') {
    $st->bindValue(':category', $category, PDO::PARAM_STR);
}
$st->execute();
$rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="expenses-' . date('Ymd-His') . '.csv"');

echo "Дата;Категория;Сумма;Комментарий\n";
foreach ($rows as $row) {
    $line = [
        $row['tx_date'],
        $row['category'],
        number_format((float)$row['amount'], 2, '.', ''),
        str_replace(["\r", "\n", ';'], [' ', ' ', ','], (string)$row['comment']),
    ];
    echo implode(';', $line) . "\n";
}
