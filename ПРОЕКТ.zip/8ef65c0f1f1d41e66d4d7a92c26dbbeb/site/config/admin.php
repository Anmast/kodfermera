<?php
return [
    'login' => 'admin',
    'password_hash' => '$2y$12$902f3J1ZoGeSgMq38FLdvu6B5tarZNPGyTJCLBMAF2atPPN4WZ.N.',
    'session_key' => 'kodfermera_admin_auth',
    'csrf_key' => 'kodfermera_admin_csrf',
];
