<?php
declare(strict_types=1);

return [
    '/' => ['id' => 'home', 'title' => 'Код Фермера — Главная', 'view' => 'home'],
    '/cattle' => ['id' => 'cattle', 'title' => 'Код Фермера — КРС', 'view' => 'cattle', 'body_class' => 'page-cattle'],
    '/expenses' => ['id' => 'expenses', 'title' => 'Код Фермера — Расходы', 'view' => 'expenses'],
    '/admin' => ['id' => 'admin', 'title' => 'Код Фермера — Админка', 'view' => 'admin', 'body_class' => 'page-admin'],
    '/404' => ['id' => '404', 'title' => 'Страница не найдена', 'view' => '404'],
];
