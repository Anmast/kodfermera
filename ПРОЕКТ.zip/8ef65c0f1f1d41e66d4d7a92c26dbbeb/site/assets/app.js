(function(){
  document.querySelectorAll('form[method="get"] select').forEach(function(el){
    el.addEventListener('change', function(){
      if (window.innerWidth > 900 && el.form && !el.closest('.segmented')) {
        el.form.submit();
      }
    });
  });
})();
