<?php

declare(strict_types=1);

function site_pdo(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $pdo = require dirname(__DIR__) . '/farm-bot/db.php';
    return $pdo;
}

function site_secret_required(): string
{
    $secretFile = __DIR__ . '/_secret.php';
    if (!is_file($secretFile)) {
        return '';
    }
    try {
        $secret = require $secretFile;
        return is_string($secret) ? $secret : '';
    } catch (Throwable $e) {
        return '';
    }
}

function site_current_key(): string
{
    return trim((string)($_GET['key'] ?? $_POST['key'] ?? ''));
}

function site_check_access(): void
{
    $required = site_secret_required();
    if ($required === '') {
        return;
    }
    $key = site_current_key();
    if (!hash_equals($required, $key)) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Forbidden';
        exit;
    }
}

function site_e(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function site_number($value, int $decimals = 1, string $suffix = ''): string
{
    if ($value === null || $value === '') {
        return '—';
    }
    $num = (float)$value;
    $formatted = number_format($num, $decimals, ',', ' ');
    $formatted = preg_replace('/,0+$/', '', $formatted) ?? $formatted;
    return $formatted . $suffix;
}

function site_money($value): string
{
    if ($value === null || $value === '') {
        return '—';
    }
    return number_format((float)$value, 2, ',', ' ') . ' ₽';
}

function site_format_dt(?string $value): string
{
    $value = trim((string)$value);
    if ($value === '') {
        return '—';
    }
    $ts = strtotime($value);
    if ($ts === false) {
        return $value;
    }
    return date('d.m.Y H:i', $ts);
}

function site_format_date(?string $value): string
{
    $value = trim((string)$value);
    if ($value === '') {
        return '—';
    }
    $ts = strtotime($value);
    if ($ts === false) {
        return $value;
    }
    return date('d.m.Y', $ts);
}

function site_query(array $params = []): string
{
    $merged = $_GET;
    foreach ($params as $key => $value) {
        if ($value === null || $value === '') {
            unset($merged[$key]);
        } else {
            $merged[$key] = (string)$value;
        }
    }
    $qs = http_build_query($merged);
    return $qs ? ('?' . $qs) : '';
}

function site_url(string $path, array $params = []): string
{
    $params = array_merge(site_current_key() !== '' ? ['key' => site_current_key()] : [], $params);
    $qs = http_build_query(array_filter($params, static fn($v) => $v !== null && $v !== ''));
    return $path . ($qs !== '' ? ('?' . $qs) : '');
}

function site_table_exists(PDO $pdo, string $table): bool
{
    try {
        $st = $pdo->prepare("SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1");
        $st->execute([$table]);
        return (bool)$st->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

function site_has_finance(PDO $pdo): bool
{
    return site_table_exists($pdo, 'finance_transactions') && site_table_exists($pdo, 'finance_categories');
}

function site_status_expr(string $field = 'n.number'): string
{
    return "COALESCE((SELECT e.value FROM events e WHERE e.calf_number={$field} AND e.type='life' ORDER BY e.created_at DESC, e.id DESC LIMIT 1), 'active')";
}

function site_cattle_source_sql(): string
{
    return "(
        SELECT number FROM calves
        UNION
        SELECT DISTINCT calf_number AS number FROM events WHERE calf_number IS NOT NULL
    )";
}

function site_parse_birth(?string $raw, ?string $fallback = null): ?DateTimeImmutable
{
    $raw = trim((string)$raw);
    if ($raw !== '') {
        $dt = DateTimeImmutable::createFromFormat('Y-m-d', $raw)
            ?: DateTimeImmutable::createFromFormat('d.m.Y', $raw)
            ?: DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $raw);
        if ($dt instanceof DateTimeImmutable) {
            return $dt;
        }
    }
    $fallback = trim((string)$fallback);
    if ($fallback !== '') {
        $ts = strtotime($fallback);
        if ($ts !== false) {
            return (new DateTimeImmutable())->setTimestamp($ts);
        }
    }
    return null;
}

function site_event_label(string $type): string
{
    return match (mb_strtolower($type)) {
        'weight' => 'Вес',
        'temp' => 'Температура',
        'treatment' => 'Лечение',
        'note' => 'Заметка',
        'life' => 'Статус',
        'birth', 'dob', 'born' => 'Дата рождения',
        'qr' => 'QR',
        default => $type,
    };
}

function site_status_label(string $status): string
{
    return match ($status) {
        'sold' => 'Продан',
        'dead' => 'Падёж',
        'removed' => 'Архив',
        default => 'Активный',
    };
}

function site_status_class(string $status): string
{
    return match ($status) {
        'sold' => 'status-sold',
        'dead' => 'status-dead',
        'removed' => 'status-removed',
        default => 'status-active',
    };
}

function site_temp_class(?float $temp): string
{
    if ($temp === null) {
        return 'temp-normal';
    }
    if ($temp >= 40.0) {
        return 'temp-crit';
    }
    if ($temp >= 39.5) {
        return 'temp-warn';
    }
    return 'temp-normal';
}

function site_fetch_cattle(PDO $pdo, array $filters = []): array
{
    $source = site_cattle_source_sql();
    $statusExpr = site_status_expr('n.number');

    $sql = "SELECT
        n.number,
        {$statusExpr} AS status,
        (SELECT e.value FROM events e WHERE e.calf_number=n.number AND e.type='weight' ORDER BY e.created_at DESC, e.id DESC LIMIT 1) AS last_weight,
        (SELECT e.value FROM events e WHERE e.calf_number=n.number AND e.type='weight' ORDER BY e.created_at DESC, e.id DESC LIMIT 1 OFFSET 1) AS prev_weight,
        (SELECT e.created_at FROM events e WHERE e.calf_number=n.number AND e.type='weight' ORDER BY e.created_at DESC, e.id DESC LIMIT 1) AS last_weight_at,
        (SELECT e.value FROM events e WHERE e.calf_number=n.number AND e.type='temp' ORDER BY e.created_at DESC, e.id DESC LIMIT 1) AS last_temp,
        (SELECT e.created_at FROM events e WHERE e.calf_number=n.number AND e.type='temp' ORDER BY e.created_at DESC, e.id DESC LIMIT 1) AS last_temp_at,
        (SELECT e.value FROM events e WHERE e.calf_number=n.number AND e.type='treatment' ORDER BY e.created_at DESC, e.id DESC LIMIT 1) AS treatment,
        (SELECT e.value FROM events e WHERE e.calf_number=n.number AND e.type='note' ORDER BY e.created_at DESC, e.id DESC LIMIT 1) AS note,
        (SELECT e.value FROM events e WHERE e.calf_number=n.number AND e.type='qr' ORDER BY e.created_at DESC, e.id DESC LIMIT 1) AS qr,
        (SELECT e.value FROM events e WHERE e.calf_number=n.number AND e.type IN ('birth','dob','born') ORDER BY e.created_at DESC, e.id DESC LIMIT 1) AS birth,
        (SELECT MIN(e.created_at) FROM events e WHERE e.calf_number=n.number) AS first_seen,
        (SELECT MAX(e.created_at) FROM events e WHERE e.calf_number=n.number) AS last_seen
    FROM {$source} n";

    $where = [];
    $args = [];

    $search = trim((string)($filters['q'] ?? ''));
    if ($search !== '') {
        $digits = preg_replace('/\D+/', '', $search);
        if ($digits !== '') {
            $where[] = 'CAST(n.number AS CHAR) LIKE ?';
            $args[] = '%' . $digits . '%';
        }
    }

    $status = trim((string)($filters['status'] ?? 'active'));
    if ($status !== '' && $status !== 'all') {
        $where[] = "{$statusExpr} = ?";
        $args[] = $status;
    }

    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }

    $sql .= ' ORDER BY n.number DESC LIMIT 500';

    $st = $pdo->prepare($sql);
    $st->execute($args);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $today = new DateTimeImmutable('today');
    $items = [];

    foreach ($rows as $row) {
        $birth = site_parse_birth($row['birth'] ?? null, $row['first_seen'] ?? null);
        $ageDays = $birth ? (int)$birth->diff($today)->format('%a') : null;
        $weight = $row['last_weight'] !== null ? (float)$row['last_weight'] : null;
        $prevWeight = $row['prev_weight'] !== null ? (float)$row['prev_weight'] : null;
        $temp = $row['last_temp'] !== null ? (float)$row['last_temp'] : null;

        $items[] = [
            'number' => (int)$row['number'],
            'status' => (string)($row['status'] ?? 'active'),
            'age_days' => $ageDays,
            'birth' => $row['birth'],
            'last_weight' => $weight,
            'prev_weight' => $prevWeight,
            'weight_delta' => ($weight !== null && $prevWeight !== null) ? round($weight - $prevWeight, 1) : null,
            'last_weight_at' => $row['last_weight_at'],
            'last_temp' => $temp,
            'last_temp_at' => $row['last_temp_at'],
            'treatment' => $row['treatment'],
            'note' => $row['note'],
            'qr' => $row['qr'],
            'last_seen' => $row['last_seen'],
        ];
    }

    $sort = trim((string)($filters['sort'] ?? 'number_desc'));
    usort($items, static function (array $a, array $b) use ($sort): int {
        return match ($sort) {
            'number_asc' => $a['number'] <=> $b['number'],
            'age_desc' => ($b['age_days'] ?? -1) <=> ($a['age_days'] ?? -1),
            'age_asc' => ($a['age_days'] ?? PHP_INT_MAX) <=> ($b['age_days'] ?? PHP_INT_MAX),
            'weight_desc' => ($b['last_weight'] ?? -1) <=> ($a['last_weight'] ?? -1),
            'weight_asc' => ($a['last_weight'] ?? PHP_INT_MAX) <=> ($b['last_weight'] ?? PHP_INT_MAX),
            default => $b['number'] <=> $a['number'],
        };
    });

    return $items;
}

function site_fetch_recent_events(PDO $pdo, int $limit = 20): array
{
    $limit = max(1, min(100, $limit));
    $sql = "SELECT id, calf_number, type, value, created_at FROM events WHERE calf_number IS NOT NULL ORDER BY created_at DESC, id DESC LIMIT {$limit}";
    return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function site_fetch_dashboard(PDO $pdo, int $days = 30): array
{
    $cattle = site_fetch_cattle($pdo, ['status' => 'all', 'sort' => 'number_desc']);
    $counts = ['total' => count($cattle), 'active' => 0, 'sold' => 0, 'dead' => 0, 'removed' => 0];
    foreach ($cattle as $item) {
        $status = $item['status'];
        if (!isset($counts[$status])) {
            $status = 'active';
        }
        $counts[$status]++;
    }

    $signals = [];
    foreach ($cattle as $item) {
        if ($item['last_temp'] !== null && $item['last_temp'] >= 39.8) {
            $signals[] = [
                'level' => $item['last_temp'] >= 40.0 ? 'critical' : 'warn',
                'title' => 'Температура выше нормы',
                'text' => 'Телёнок №' . $item['number'] . ' — ' . site_number($item['last_temp'], 1, ' °C'),
            ];
        }
        if ($item['weight_delta'] !== null && $item['weight_delta'] < 0) {
            $signals[] = [
                'level' => 'warn',
                'title' => 'Снижение веса',
                'text' => 'Телёнок №' . $item['number'] . ' — ' . site_number($item['weight_delta'], 1, ' кг'),
            ];
        }
    }

    $finance = [
        'installed' => site_has_finance($pdo),
        'days' => $days,
        'total' => 0.0,
        'avg_daily' => 0.0,
        'by_category' => [],
        'items' => [],
    ];

    if ($finance['installed']) {
        $days = max(1, min(365, $days));
        $union = site_expense_union_sql($pdo, $days, null);
        $sqlCats = "SELECT x.category, ROUND(SUM(x.amount),2) AS total FROM (" . $union['sql'] . ") x GROUP BY x.category ORDER BY total DESC";
        $stCats = $pdo->prepare($sqlCats);
        $stCats->execute($union['args']);
        $finance['by_category'] = $stCats->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($finance['by_category'] as $row) {
            $finance['total'] += (float)$row['total'];
        }
        $finance['total'] = round($finance['total'], 2);
        $finance['avg_daily'] = round($finance['total'] / max(1, $days), 2);

        $sqlLast = "SELECT x.id, x.tx_date, x.amount, x.comment, x.category FROM (" . $union['sql'] . ") x ORDER BY x.tx_date DESC, x.id DESC LIMIT 12";
        $stLast = $pdo->prepare($sqlLast);
        $stLast->execute($union['args']);
        $finance['items'] = $stLast->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    return [
        'counts' => $counts,
        'recent' => site_fetch_recent_events($pdo, 12),
        'signals' => array_slice($signals, 0, 8),
        'finance' => $finance,
        'cattle' => $cattle,
    ];
}

function site_expense_union_sql(PDO $pdo, int $days, ?string $category = null): array
{
        $days = max(1, min(3650, $days));
    $whereFinance = ["t.type='expense'", "t.tx_date >= (NOW() - INTERVAL {$days} DAY)"];
    $args = [];
    if ($category !== null && $category !== '') {
        $whereFinance[] = "COALESCE(c.name, 'Без категории') = ?";
        $args[] = $category;
    }
    $financeWhereSql = implode(' AND ', $whereFinance);

    $sql = "
        SELECT x.id, x.tx_date, x.amount, x.comment, x.calf_number, x.category
        FROM (
            SELECT CAST(t.id AS CHAR(32)) AS id, t.tx_date, ROUND(t.amount,2) AS amount, t.comment, t.calf_number, COALESCE(c.name, 'Без категории') AS category
            FROM finance_transactions t
            LEFT JOIN finance_categories c ON c.id=t.category_id
            WHERE {$financeWhereSql}
    ";

    if (site_table_exists($pdo, 'payroll_payouts') && site_table_exists($pdo, 'employees')) {
        $salaryWhere = [
            "COALESCE(p.created_at, CONCAT(p.payout_date,' 00:00:00')) >= (NOW() - INTERVAL {$days} DAY)",
            "NOT EXISTS (SELECT 1 FROM finance_transactions t2 WHERE t2.source_type='payroll_payout' AND t2.source_id=p.id)",
        ];
        if ($category !== null && $category !== '') {
            $salaryWhere[] = "'Зарплата' = ?";
            $args[] = $category;
        }
        $salaryWhereSql = implode(' AND ', $salaryWhere);
        $sql .= "

            UNION ALL

            SELECT CAST(CONCAT('payroll_', p.id) AS CHAR(32)) AS id,
                   COALESCE(p.created_at, CONCAT(p.payout_date,' 00:00:00')) AS tx_date,
                   ROUND(p.amount,2) AS amount,
                   TRIM(CONCAT('Выплата зарплаты', CASE WHEN e.name IS NOT NULL AND e.name <> '' THEN CONCAT(': ', e.name) ELSE '' END, CASE WHEN p.comment IS NOT NULL AND p.comment <> '' THEN CONCAT(' — ', p.comment) ELSE '' END)) AS comment,
                   NULL AS calf_number,
                   'Зарплата' AS category
            FROM payroll_payouts p
            LEFT JOIN employees e ON e.id=p.employee_id
            WHERE {$salaryWhereSql}
        ";
    }

    $sql .= "
        ) x
    ";

    return ['sql' => $sql, 'args' => $args];
}

function site_fetch_expenses(PDO $pdo, int $days = 90, ?string $category = null): array
{
    if (!site_has_finance($pdo)) {
        return ['installed' => false, 'items' => [], 'categories' => [], 'series' => [], 'total' => 0.0];
    }

    $days = max(1, min(3650, $days));
    $union = site_expense_union_sql($pdo, $days, $category);

    $sqlItems = $union['sql'] . " ORDER BY x.tx_date DESC, x.id DESC LIMIT 500";
    $st = $pdo->prepare($sqlItems);
    $st->execute($union['args']);
    $items = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $unionCats = site_expense_union_sql($pdo, $days, null);
    $sqlCats = "SELECT x.category, ROUND(SUM(x.amount),2) AS total FROM (" . $unionCats['sql'] . ") x GROUP BY x.category ORDER BY total DESC";
    $stCats = $pdo->prepare($sqlCats);
    $stCats->execute($unionCats['args']);
    $categories = $stCats->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $sqlSeries = "SELECT DATE(x.tx_date) AS d, ROUND(SUM(x.amount),2) AS total FROM (" . $union['sql'] . ") x GROUP BY DATE(x.tx_date) ORDER BY DATE(x.tx_date) ASC";
    $st = $pdo->prepare($sqlSeries);
    $st->execute($union['args']);
    $series = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $total = 0.0;
    foreach ($items as $item) {
        $total += (float)$item['amount'];
    }

    return [
        'installed' => true,
        'items' => $items,
        'categories' => $categories,
        'series' => $series,
        'total' => round($total, 2),
    ];
}
