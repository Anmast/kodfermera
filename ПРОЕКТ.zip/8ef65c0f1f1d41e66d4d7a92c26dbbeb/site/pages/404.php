<section class="hero compact">
  <div>
    <span class="eyebrow">404</span>
    <h1>Страница не найдена.</h1>
    <p>Проверь адрес или вернись на главную.</p>
    <a class="btn btn-primary" href="<?= site_url('/') ?>">На главную</a>
  </div>
</section>
