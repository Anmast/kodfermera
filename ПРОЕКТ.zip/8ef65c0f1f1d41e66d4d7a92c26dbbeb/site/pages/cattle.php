<?php
$pdo = site_pdo();
$filters = [
    'q' => trim((string)($_GET['q'] ?? '')),
    'status' => trim((string)($_GET['status'] ?? 'active')),
    'sort' => trim((string)($_GET['sort'] ?? 'number_desc')),
];
$view = trim((string)($_GET['view'] ?? 'cards'));
if (!in_array($view, ['cards', 'table'], true)) {
    $view = 'cards';
}
$cattle = site_fetch_cattle($pdo, $filters);
$weights = array_values(array_filter(array_map(static fn($item) => $item['last_weight'], $cattle), static fn($v) => $v !== null));
$ages = array_values(array_filter(array_map(static fn($item) => $item['age_days'], $cattle), static fn($v) => $v !== null));
$tempAlerts = count(array_filter($cattle, static fn($item) => $item['last_temp'] !== null && $item['last_temp'] >= 39.8));
?>
<section class="hero">
  <div>
    <span class="eyebrow">КРС</span>
    <h1>Удобный обзор по телятам: поиск, карточки и компактная таблица.</h1>
    <p>Сразу видно возраст, вес, температуру, лечение и последнюю активность по каждому телёнку.</p>
  </div>
  <div class="hero-side-card">
    <div class="hero-side-title">Что видно сразу</div>
    <div class="hero-side-list">
      <span>возраст</span>
      <span>вес и динамика</span>
      <span>температура</span>
      <span>лечение</span>
      <span>QR</span>
      <span>последняя активность</span>
    </div>
  </div>
</section>

<section class="stats-grid four">
  <article class="stat-card">
    <div class="stat-label">В выборке</div>
    <div class="stat-value"><?= count($cattle) ?></div>
    <div class="stat-sub">По текущим фильтрам</div>
  </article>
  <article class="stat-card">
    <div class="stat-label">Средний вес</div>
    <div class="stat-value"><?= $weights ? site_number(array_sum($weights) / count($weights), 1, ' кг') : '—' ?></div>
    <div class="stat-sub">По доступным записям</div>
  </article>
  <article class="stat-card">
    <div class="stat-label">Средний возраст</div>
    <div class="stat-value"><?= $ages ? round(array_sum($ages) / count($ages)) . ' дн.' : '—' ?></div>
    <div class="stat-sub">По доступным записям</div>
  </article>
  <article class="stat-card">
    <div class="stat-label">Температурный риск</div>
    <div class="stat-value"><?= $tempAlerts ?></div>
    <div class="stat-sub">39.8 °C и выше</div>
  </article>
</section>

<section class="card">
  <form class="toolbar-form" method="get" action="<?= site_url('/cattle', []) ?>">
    <?php if (site_current_key() !== ''): ?><input type="hidden" name="key" value="<?= site_e(site_current_key()) ?>"><?php endif; ?>
    <div class="toolbar-grid">
      <input type="text" name="q" value="<?= site_e($filters['q']) ?>" class="input input-grow" placeholder="Поиск по номеру или части номера">
      <select name="status" class="input">
        <option value="all" <?= $filters['status'] === 'all' ? 'selected' : '' ?>>Все статусы</option>
        <option value="active" <?= $filters['status'] === 'active' ? 'selected' : '' ?>>Активные</option>
        <option value="sold" <?= $filters['status'] === 'sold' ? 'selected' : '' ?>>Проданные</option>
        <option value="dead" <?= $filters['status'] === 'dead' ? 'selected' : '' ?>>Падёж</option>
        <option value="removed" <?= $filters['status'] === 'removed' ? 'selected' : '' ?>>Архив</option>
      </select>
      <select name="sort" class="input">
        <option value="number_desc" <?= $filters['sort'] === 'number_desc' ? 'selected' : '' ?>>Новые номера</option>
        <option value="number_asc" <?= $filters['sort'] === 'number_asc' ? 'selected' : '' ?>>Старые номера</option>
        <option value="age_desc" <?= $filters['sort'] === 'age_desc' ? 'selected' : '' ?>>Старше сверху</option>
        <option value="age_asc" <?= $filters['sort'] === 'age_asc' ? 'selected' : '' ?>>Младше сверху</option>
        <option value="weight_desc" <?= $filters['sort'] === 'weight_desc' ? 'selected' : '' ?>>Тяжелее сверху</option>
        <option value="weight_asc" <?= $filters['sort'] === 'weight_asc' ? 'selected' : '' ?>>Легче сверху</option>
      </select>
      <div class="segmented">
        <button type="submit" name="view" value="cards" class="segmented-btn <?= $view === 'cards' ? 'active' : '' ?>">Карточки</button>
        <button type="submit" name="view" value="table" class="segmented-btn <?= $view === 'table' ? 'active' : '' ?>">Таблица</button>
      </div>
      <button class="btn btn-primary" type="submit">Применить</button>
    </div>
  </form>
  <div class="toolbar-meta">
    <div class="helper">Открой карточки для быстрого просмотра или переключись на таблицу для плотного списка.</div>
    <div class="chip">Найдено: <?= count($cattle) ?></div>
  </div>
</section>

<?php if ($view === 'cards'): ?>
  <section class="cattle-cards">
    <?php foreach ($cattle as $item): ?>
      <article class="cattle-card">
        <div class="cattle-card-top">
          <div>
            <div class="cattle-number">№<?= (int)$item['number'] ?></div>
            <div class="cattle-date">Последняя активность: <?= site_format_dt($item['last_seen']) ?></div>
          </div>
          <span class="status-badge <?= site_status_class((string)$item['status']) ?>"><?= site_e(site_status_label((string)$item['status'])) ?></span>
        </div>

        <div class="metric-grid">
          <div class="metric-box"><span>Возраст</span><strong><?= $item['age_days'] !== null ? (int)$item['age_days'] . ' дн.' : '—' ?></strong></div>
          <div class="metric-box"><span>Вес</span><strong><?= site_number($item['last_weight'], 1, ' кг') ?></strong></div>
          <div class="metric-box"><span>Температура</span><strong class="<?= site_temp_class($item['last_temp']) ?>"><?= site_number($item['last_temp'], 1, ' °C') ?></strong></div>
          <div class="metric-box"><span>Δ вес</span><strong><?= $item['weight_delta'] !== null ? (($item['weight_delta'] > 0 ? '+' : '') . site_number($item['weight_delta'], 1, ' кг')) : '—' ?></strong></div>
        </div>

        <div class="cattle-info-grid">
          <div class="info-row"><span>Лечение</span><strong><?= site_e((string)($item['treatment'] ?: '—')) ?></strong></div>
          <div class="info-row"><span>Заметка</span><strong><?= site_e((string)($item['note'] ?: '—')) ?></strong></div>
          <div class="info-row"><span>QR</span><strong><?= site_e((string)($item['qr'] ?: '—')) ?></strong></div>
          <div class="info-row"><span>Дата рождения</span><strong><?= $item['birth'] ? site_format_date((string)$item['birth']) : '—' ?></strong></div>
        </div>
      </article>
    <?php endforeach; ?>
    <?php if (!$cattle): ?>
      <div class="empty-state card">По текущим фильтрам ничего не найдено.</div>
    <?php endif; ?>
  </section>
<?php else: ?>
  <section class="table-card">
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>№</th>
            <th>Статус</th>
            <th>Возраст</th>
            <th>Вес</th>
            <th>Δ вес</th>
            <th>Темп.</th>
            <th>Лечение</th>
            <th>Заметка</th>
            <th>Последняя активность</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($cattle as $item): ?>
            <tr>
              <td><strong>№<?= (int)$item['number'] ?></strong></td>
              <td><span class="status-badge <?= site_status_class((string)$item['status']) ?>"><?= site_e(site_status_label((string)$item['status'])) ?></span></td>
              <td><?= $item['age_days'] !== null ? (int)$item['age_days'] . ' дн.' : '—' ?></td>
              <td><?= site_number($item['last_weight'], 1, ' кг') ?></td>
              <td><?= $item['weight_delta'] !== null ? (($item['weight_delta'] > 0 ? '+' : '') . site_number($item['weight_delta'], 1, ' кг')) : '—' ?></td>
              <td><span class="<?= site_temp_class($item['last_temp']) ?>"><?= site_number($item['last_temp'], 1, ' °C') ?></span></td>
              <td><?= site_e((string)($item['treatment'] ?: '—')) ?></td>
              <td><?= site_e((string)($item['note'] ?: '—')) ?></td>
              <td><?= site_format_dt($item['last_seen']) ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$cattle): ?>
            <tr><td colspan="9" class="empty-state">По текущим фильтрам ничего не найдено.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
<?php endif; ?>
