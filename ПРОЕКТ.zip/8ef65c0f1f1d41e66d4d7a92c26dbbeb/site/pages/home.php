<?php
$pdo = site_pdo();
$data = site_fetch_dashboard($pdo, 30);
?>
<section class="hero">
  <div>
    <span class="eyebrow">Главная</span>
    <h1>Панель хозяйства: КРС, расходы и последние изменения в одном месте.</h1>
    <p>На главной вынесены ключевые цифры, недавние события по телятам и финансовая картина за последние 30 дней.</p>
  </div>
  <div class="hero-side-card">
    <div class="hero-side-title">Что видно сразу</div>
    <div class="hero-side-list">
      <span>активное поголовье</span>
      <span>последние события</span>
      <span>расходы по категориям</span>
      <span>сигналы внимания</span>
    </div>
  </div>
</section>

<section class="stats-grid four">
  <article class="stat-card">
    <div class="stat-label">Всего КРС</div>
    <div class="stat-value"><?= (int)$data['counts']['total'] ?></div>
    <div class="stat-sub">Активных: <?= (int)$data['counts']['active'] ?></div>
  </article>
  <article class="stat-card">
    <div class="stat-label">Продано</div>
    <div class="stat-value"><?= (int)$data['counts']['sold'] ?></div>
    <div class="stat-sub">Архив: <?= (int)$data['counts']['removed'] ?></div>
  </article>
  <article class="stat-card">
    <div class="stat-label">Падёж</div>
    <div class="stat-value"><?= (int)$data['counts']['dead'] ?></div>
    <div class="stat-sub">Контроль журнала</div>
  </article>
  <article class="stat-card">
    <div class="stat-label">Расходы за 30 дней</div>
    <div class="stat-value"><?= site_money($data['finance']['total']) ?></div>
    <div class="stat-sub">Среднее в день: <?= site_money($data['finance']['avg_daily']) ?></div>
  </article>
</section>

<section class="grid-two">
  <article class="card">
    <div class="card-head"><h2>Последние изменения по телятам</h2><span class="chip">Журнал</span></div>
    <div class="list-stack">
      <?php foreach ($data['recent'] as $event): ?>
        <div class="list-item">
          <div class="list-title">Телёнок №<?= (int)$event['calf_number'] ?> — <?= site_e(site_event_label((string)$event['type'])) ?></div>
          <div class="list-text"><?= site_e((string)$event['value']) ?></div>
          <div class="list-meta"><?= site_format_dt((string)$event['created_at']) ?></div>
        </div>
      <?php endforeach; ?>
      <?php if (!$data['recent']): ?>
        <div class="empty-state">Событий пока нет.</div>
      <?php endif; ?>
    </div>
  </article>

  <article class="card">
    <div class="card-head"><h2>Сигналы внимания</h2><span class="chip">Контроль</span></div>
    <div class="list-stack">
      <?php foreach ($data['signals'] as $signal): ?>
        <div class="list-item <?= $signal['level'] === 'critical' ? 'signal-critical' : 'signal-warn' ?>">
          <div class="list-title"><?= site_e((string)$signal['title']) ?></div>
          <div class="list-text"><?= site_e((string)$signal['text']) ?></div>
        </div>
      <?php endforeach; ?>
      <?php if (!$data['signals']): ?>
        <div class="empty-state">Сейчас тревожных сигналов нет.</div>
      <?php endif; ?>
    </div>
  </article>
</section>

<section class="grid-two">
  <article class="card">
    <div class="card-head"><h2>Расходы по категориям</h2><span class="chip">30 дней</span></div>
    <div class="bars">
      <?php if ($data['finance']['installed'] && $data['finance']['by_category']): ?>
        <?php $maxBar = max(array_map(static fn($row) => (float)$row['total'], $data['finance']['by_category'])); ?>
        <?php foreach ($data['finance']['by_category'] as $row): ?>
          <?php $width = $maxBar > 0 ? max(8, (int)round(((float)$row['total'] / $maxBar) * 100)) : 8; ?>
          <div class="bar-row">
            <div class="bar-head"><span><?= site_e((string)$row['category']) ?></span><strong><?= site_money($row['total']) ?></strong></div>
            <div class="bar-track"><div class="bar-fill" style="width: <?= $width ?>%"></div></div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="empty-state">Финансовый раздел пока пуст или ещё не активирован.</div>
      <?php endif; ?>
    </div>
  </article>

  <article class="card">
    <div class="card-head"><h2>Последние расходы</h2><span class="chip">Финансы</span></div>
    <div class="list-stack">
      <?php foreach ($data['finance']['items'] as $item): ?>
        <div class="list-item">
          <div class="list-title"><?= site_e((string)$item['category']) ?> — <?= site_money($item['amount']) ?></div>
          <div class="list-text"><?= site_e((string)$item['comment']) ?></div>
          <div class="list-meta"><?= site_format_dt((string)$item['tx_date']) ?></div>
        </div>
      <?php endforeach; ?>
      <?php if (!$data['finance']['items']): ?>
        <div class="empty-state">Расходов пока нет.</div>
      <?php endif; ?>
    </div>
  </article>
</section>
