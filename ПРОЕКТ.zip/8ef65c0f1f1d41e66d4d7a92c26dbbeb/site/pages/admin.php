<?php
$pdo = site_pdo();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'admin_login') {
        $login = trim((string)($_POST['login'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        if (site_admin_login($login, $password)) {
            site_flash_set('ok', 'Вход выполнен.');
            header('Location: ' . site_url('/admin'));
            exit;
        }
        site_flash_set('error', 'Неверный логин или пароль.');
        header('Location: ' . site_url('/admin'));
        exit;
    }

    if (!site_admin_is_logged_in()) {
        site_flash_set('error', 'Сначала войди в админку.');
        header('Location: ' . site_url('/admin'));
        exit;
    }

    if (!site_admin_validate_csrf((string)($_POST['csrf'] ?? ''))) {
        site_flash_set('error', 'Сессия устарела. Обнови страницу и попробуй снова.');
        header('Location: ' . site_url('/admin'));
        exit;
    }

    try {
        switch ($action) {
            case 'save_event':
                $eventId = (int)($_POST['event_id'] ?? 0);
                $calfNumber = (int)($_POST['calf_number'] ?? 0);
                $type = trim((string)($_POST['type'] ?? ''));
                $value = trim((string)($_POST['value'] ?? ''));
                $createdAt = trim((string)($_POST['created_at'] ?? ''));
                $allowed = ['weight', 'temp', 'treatment', 'note', 'birth', 'dob', 'born', 'life', 'qr'];
                if ($calfNumber <= 0 || $value === '' || !in_array($type, $allowed, true)) {
                    throw new RuntimeException('Заполни номер, тип и значение для записи по КРС.');
                }
                $createdAtSql = $createdAt !== '' ? date('Y-m-d H:i:s', strtotime($createdAt)) : null;
                if ($eventId > 0) {
                    $sql = 'UPDATE events SET calf_number=?, type=?, value=?' . ($createdAtSql ? ', created_at=?' : '') . ' WHERE id=?';
                    $args = [$calfNumber, $type, $value];
                    if ($createdAtSql) {
                        $args[] = $createdAtSql;
                    }
                    $args[] = $eventId;
                    $pdo->prepare($sql)->execute($args);
                    site_flash_set('ok', 'Запись по КРС обновлена.');
                } else {
                    $pdo->prepare('INSERT IGNORE INTO calves(number) VALUES (?)')->execute([$calfNumber]);
                    if ($createdAtSql) {
                        $pdo->prepare('INSERT INTO events(calf_number, type, value, created_at) VALUES (?,?,?,?)')->execute([$calfNumber, $type, $value, $createdAtSql]);
                    } else {
                        $pdo->prepare('INSERT INTO events(calf_number, type, value) VALUES (?,?,?)')->execute([$calfNumber, $type, $value]);
                    }
                    site_flash_set('ok', 'Запись по КРС добавлена.');
                }
                break;

            case 'delete_event':
                $eventId = (int)($_POST['event_id'] ?? 0);
                if ($eventId <= 0) {
                    throw new RuntimeException('Не выбран event_id для удаления.');
                }
                $pdo->prepare('DELETE FROM events WHERE id=?')->execute([$eventId]);
                site_flash_set('ok', 'Событие удалено.');
                break;

            case 'save_expense':
                if (!site_has_finance($pdo)) {
                    throw new RuntimeException('Финансовые таблицы ещё не установлены.');
                }
                $expenseId = (int)($_POST['expense_id'] ?? 0);
                $txDate = trim((string)($_POST['tx_date'] ?? ''));
                $amount = (float)str_replace(',', '.', (string)($_POST['amount'] ?? '0'));
                $comment = trim((string)($_POST['comment'] ?? ''));
                $calfNumber = (int)($_POST['calf_number'] ?? 0);
                $categoryId = (int)($_POST['category_id'] ?? 0);
                $newCategory = trim((string)($_POST['new_category'] ?? ''));
                if ($amount <= 0) {
                    throw new RuntimeException('Укажи сумму расхода больше нуля.');
                }
                if ($categoryId <= 0 && $newCategory === '') {
                    throw new RuntimeException('Выбери категорию или введи новую.');
                }
                if ($categoryId <= 0 && $newCategory !== '') {
                    $st = $pdo->prepare("SELECT id FROM finance_categories WHERE type='expense' AND name=? LIMIT 1");
                    $st->execute([$newCategory]);
                    $categoryId = (int)($st->fetchColumn() ?: 0);
                    if ($categoryId <= 0) {
                        $pdo->prepare("INSERT INTO finance_categories(name, type, is_system) VALUES (?, 'expense', 0)")->execute([$newCategory]);
                        $categoryId = (int)$pdo->lastInsertId();
                    }
                }
                $txDateSql = $txDate !== '' ? date('Y-m-d H:i:s', strtotime($txDate)) : date('Y-m-d H:i:s');
                if ($expenseId > 0) {
                    $pdo->prepare("UPDATE finance_transactions SET tx_date=?, category_id=?, amount=?, comment=?, calf_number=? WHERE id=? AND type='expense'")
                        ->execute([$txDateSql, $categoryId, $amount, $comment, $calfNumber > 0 ? $calfNumber : null, $expenseId]);
                    site_flash_set('ok', 'Расход обновлён.');
                } else {
                    $pdo->prepare("INSERT INTO finance_transactions(tx_date, type, category_id, amount, comment, calf_number, created_by) VALUES (?, 'expense', ?, ?, ?, ?, 0)")
                        ->execute([$txDateSql, $categoryId, $amount, $comment, $calfNumber > 0 ? $calfNumber : null]);
                    site_flash_set('ok', 'Расход добавлен.');
                }
                break;

            case 'delete_expense':
                if (!site_has_finance($pdo)) {
                    throw new RuntimeException('Финансовые таблицы ещё не установлены.');
                }
                $expenseId = (int)($_POST['expense_id'] ?? 0);
                if ($expenseId <= 0) {
                    throw new RuntimeException('Не выбран expense_id для удаления.');
                }
                $pdo->prepare("DELETE FROM finance_transactions WHERE id=? AND type='expense'")->execute([$expenseId]);
                site_flash_set('ok', 'Расход удалён.');
                break;
        }
    } catch (Throwable $e) {
        site_flash_set('error', $e->getMessage());
    }

    header('Location: ' . site_url('/admin'));
    exit;
}

if (!site_admin_is_logged_in()):
?>
<section class="hero compact">
  <div>
    <span class="eyebrow">Админка</span>
    <h1>Вход в админку.</h1>
    <p>После входа будет доступно управление записями по КРС и расходам.</p>
  </div>
  <div class="hero-note">Защищённый раздел</div>
</section>

<section class="auth-card card">
  <form method="post" class="auth-form">
    <input type="hidden" name="action" value="admin_login">
    <label class="field">
      <span>Логин</span>
      <input class="input" type="text" name="login" autocomplete="username" placeholder="admin">
    </label>
    <label class="field">
      <span>Пароль</span>
      <input class="input" type="password" name="password" autocomplete="current-password" placeholder="Введи пароль">
    </label>
    <button class="btn btn-primary" type="submit">Войти</button>
  </form>
</section>
<?php
return;
endif;

$csrf = site_admin_csrf_token();
$counts = site_fetch_dashboard($pdo, 30)['counts'];
$recentEvents = site_fetch_recent_events($pdo, 15);
$recentExpenses = site_has_finance($pdo)
    ? $pdo->query("SELECT t.id, t.tx_date, ROUND(t.amount,2) AS amount, t.comment, COALESCE(c.name, 'Без категории') AS category FROM finance_transactions t LEFT JOIN finance_categories c ON c.id=t.category_id WHERE t.type='expense' ORDER BY t.tx_date DESC, t.id DESC LIMIT 15")->fetchAll(PDO::FETCH_ASSOC)
    : [];
$categories = site_has_finance($pdo)
    ? $pdo->query("SELECT id, name FROM finance_categories WHERE type='expense' ORDER BY is_system DESC, name ASC")->fetchAll(PDO::FETCH_ASSOC)
    : [];
?>
<section class="hero compact">
  <div>
    <span class="eyebrow">Админка</span>
    <h1>Рабочая панель для быстрого внесения и правки данных по КРС и расходам.</h1>
    <p>Используй эту страницу для оперативного внесения данных, когда нужно быстро обновить хозяйственный учёт.</p>
  </div>
  <div class="hero-note"><a class="btn btn-ghost" href="<?= site_url('/admin/logout') ?>">Выйти</a></div>
</section>

<section class="stats-grid four">
  <article class="stat-card"><div class="stat-label">Всего КРС</div><div class="stat-value"><?= (int)$counts['total'] ?></div><div class="stat-sub">Активных: <?= (int)$counts['active'] ?></div></article>
  <article class="stat-card"><div class="stat-label">Продано</div><div class="stat-value"><?= (int)$counts['sold'] ?></div><div class="stat-sub">Архив и выбытие</div></article>
  <article class="stat-card"><div class="stat-label">Падёж</div><div class="stat-value"><?= (int)$counts['dead'] ?></div><div class="stat-sub">По событиям life</div></article>
  <article class="stat-card"><div class="stat-label">Категорий расходов</div><div class="stat-value"><?= count($categories) ?></div><div class="stat-sub">Если финансы включены</div></article>
</section>

<section class="grid-two">
  <article class="card admin-form-card">
    <div class="card-head"><h2>Запись по КРС</h2><span class="chip">Добавить / изменить</span></div>
    <form method="post" class="form-grid">
      <input type="hidden" name="csrf" value="<?= site_e($csrf) ?>">
      <input type="hidden" name="action" value="save_event">
      <input type="hidden" name="event_id" value="">
      <label class="field">
        <span>Номер телёнка</span>
        <input class="input" type="number" name="calf_number" min="1" required>
      </label>
      <label class="field">
        <span>Тип записи</span>
        <select class="input" name="type">
          <option value="weight">Вес</option>
          <option value="temp">Температура</option>
          <option value="treatment">Лечение</option>
          <option value="note">Заметка</option>
          <option value="birth">Дата рождения</option>
          <option value="life">Статус</option>
          <option value="qr">QR</option>
        </select>
      </label>
      <label class="field field-wide">
        <span>Значение</span>
        <input class="input" type="text" name="value" required placeholder="Например, 38.9 или Азитронит 3 мл">
      </label>
      <label class="field field-wide">
        <span>Дата и время записи</span>
        <input class="input" type="datetime-local" name="created_at">
      </label>
      <button class="btn btn-primary field-wide" type="submit">Сохранить запись</button>
    </form>
    <div class="helper">Для типа <strong>life</strong> используй значения: <code>active</code>, <code>sold</code>, <code>dead</code>, <code>removed</code>.</div>
  </article>

  <article class="card admin-form-card">
    <div class="card-head"><h2>Расход</h2><span class="chip">Добавить / изменить</span></div>
    <?php if (site_has_finance($pdo)): ?>
      <form method="post" class="form-grid">
        <input type="hidden" name="csrf" value="<?= site_e($csrf) ?>">
        <input type="hidden" name="action" value="save_expense">
        <input type="hidden" name="expense_id" value="">
        <label class="field">
          <span>Дата и время</span>
          <input class="input" type="datetime-local" name="tx_date">
        </label>
        <label class="field">
          <span>Сумма</span>
          <input class="input" type="number" name="amount" min="0" step="0.01" required>
        </label>
        <label class="field">
          <span>Категория</span>
          <select class="input" name="category_id">
            <option value="">Выбери категорию</option>
            <?php foreach ($categories as $category): ?>
              <option value="<?= (int)$category['id'] ?>"><?= site_e((string)$category['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label class="field">
          <span>Новая категория</span>
          <input class="input" type="text" name="new_category" placeholder="Если категории ещё нет">
        </label>
        <label class="field">
          <span>Номер телёнка</span>
          <input class="input" type="number" name="calf_number" min="1">
        </label>
        <label class="field field-wide">
          <span>Комментарий</span>
          <input class="input" type="text" name="comment" placeholder="Например, комбикорм, цемент, доставка">
        </label>
        <button class="btn btn-primary field-wide" type="submit">Сохранить расход</button>
      </form>
    <?php else: ?>
      <div class="empty-state">Финансовый раздел пока не активирован.</div>
    <?php endif; ?>
  </article>
</section>

<section class="grid-two">
  <article class="card">
    <div class="card-head"><h2>Последние записи по КРС</h2><span class="chip">События</span></div>
    <div class="list-stack">
      <?php foreach ($recentEvents as $event): ?>
        <div class="list-item list-item-actions">
          <div>
            <div class="list-title">Телёнок №<?= (int)$event['calf_number'] ?> — <?= site_e(site_event_label((string)$event['type'])) ?></div>
            <div class="list-text"><?= site_e((string)$event['value']) ?></div>
            <div class="list-meta"><?= site_format_dt((string)$event['created_at']) ?></div>
          </div>
          <form method="post" onsubmit="return confirm('Удалить событие?');">
            <input type="hidden" name="csrf" value="<?= site_e($csrf) ?>">
            <input type="hidden" name="action" value="delete_event">
            <input type="hidden" name="event_id" value="<?= (int)$event['id'] ?>">
            <button class="btn btn-danger" type="submit">Удалить</button>
          </form>
        </div>
      <?php endforeach; ?>
      <?php if (!$recentEvents): ?>
        <div class="empty-state">Событий пока нет.</div>
      <?php endif; ?>
    </div>
  </article>

  <article class="card">
    <div class="card-head"><h2>Последние расходы</h2><span class="chip">Финансы</span></div>
    <div class="list-stack">
      <?php foreach ($recentExpenses as $expense): ?>
        <div class="list-item list-item-actions">
          <div>
            <div class="list-title"><?= site_e((string)$expense['category']) ?> — <?= site_money($expense['amount']) ?></div>
            <div class="list-text"><?= site_e((string)$expense['comment']) ?></div>
            <div class="list-meta"><?= site_format_dt((string)$expense['tx_date']) ?></div>
          </div>
          <form method="post" onsubmit="return confirm('Удалить расход?');">
            <input type="hidden" name="csrf" value="<?= site_e($csrf) ?>">
            <input type="hidden" name="action" value="delete_expense">
            <input type="hidden" name="expense_id" value="<?= (int)$expense['id'] ?>">
            <button class="btn btn-danger" type="submit">Удалить</button>
          </form>
        </div>
      <?php endforeach; ?>
      <?php if (!$recentExpenses): ?>
        <div class="empty-state">Расходов пока нет.</div>
      <?php endif; ?>
    </div>
  </article>
</section>
