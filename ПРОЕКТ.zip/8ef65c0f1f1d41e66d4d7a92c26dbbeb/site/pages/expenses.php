<?php
$pdo = site_pdo();
$days = (int)($_GET['days'] ?? 90);
$category = trim((string)($_GET['category'] ?? ''));
$export = isset($_GET['export']) && $_GET['export'] === 'csv';
$data = site_fetch_expenses($pdo, $days, $category !== '' ? $category : null);

if ($export && $data['installed']) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="expenses-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'wb');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Дата', 'Категория', 'Сумма', 'Комментарий', 'Телёнок'], ';');
    foreach ($data['items'] as $item) {
        fputcsv($out, [$item['tx_date'], $item['category'], $item['amount'], $item['comment'], $item['calf_number']], ';');
    }
    fclose($out);
    exit;
}
?>
<section class="hero">
  <div>
    <span class="eyebrow">Расходы</span>
    <h1>Финансовая картина по хозяйству: категории, динамика и выгрузка в CSV.</h1>
    <p>Можно быстро отфильтровать период, посмотреть структуру расходов и скачать текущую выборку для дальнейшей работы.</p>
  </div>
  <div class="hero-side-card">
    <div class="hero-side-title">В работе пригодится</div>
    <div class="hero-side-list">
      <span>контроль стройки</span>
      <span>ветрасходы</span>
      <span>корма</span>
      <span>CSV выгрузка</span>
    </div>
  </div>
</section>

<section class="card">
  <form class="toolbar-form" method="get" action="<?= site_url('/expenses', []) ?>">
    <?php if (site_current_key() !== ''): ?><input type="hidden" name="key" value="<?= site_e(site_current_key()) ?>"><?php endif; ?>
    <div class="toolbar-grid expenses-toolbar">
      <select name="days" class="input">
        <?php foreach ([30, 60, 90, 180, 365] as $option): ?>
          <option value="<?= $option ?>" <?= $days === $option ? 'selected' : '' ?>>За <?= $option ?> дней</option>
        <?php endforeach; ?>
      </select>
      <select name="category" class="input">
        <option value="">Все категории</option>
        <?php foreach ($data['categories'] as $row): ?>
          <option value="<?= site_e((string)$row['category']) ?>" <?= $category === (string)$row['category'] ? 'selected' : '' ?>><?= site_e((string)$row['category']) ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn-primary" type="submit">Показать</button>
      <button class="btn" type="submit" name="export" value="csv">Скачать CSV</button>
    </div>
  </form>
</section>

<?php if (!$data['installed']): ?>
  <section class="card empty-state">Финансовый раздел пока не активирован.</section>
<?php else: ?>
  <section class="stats-grid three">
    <article class="stat-card"><div class="stat-label">Итого</div><div class="stat-value"><?= site_money($data['total']) ?></div><div class="stat-sub">По текущим фильтрам</div></article>
    <article class="stat-card"><div class="stat-label">Категорий</div><div class="stat-value"><?= count($data['categories']) ?></div><div class="stat-sub">С активностью за период</div></article>
    <article class="stat-card"><div class="stat-label">Записей</div><div class="stat-value"><?= count($data['items']) ?></div><div class="stat-sub">Доступно для выгрузки</div></article>
  </section>

  <section class="grid-two">
    <article class="card">
      <div class="card-head"><h2>Категории расходов</h2><span class="chip">Диаграмма полосами</span></div>
      <div class="bars">
        <?php if ($data['categories']): ?>
          <?php $maxBar = max(array_map(static fn($row) => (float)$row['total'], $data['categories'])); ?>
          <?php foreach ($data['categories'] as $row): ?>
            <?php $width = $maxBar > 0 ? max(8, (int)round(((float)$row['total'] / $maxBar) * 100)) : 8; ?>
            <div class="bar-row">
              <div class="bar-head"><span><?= site_e((string)$row['category']) ?></span><strong><?= site_money($row['total']) ?></strong></div>
              <div class="bar-track"><div class="bar-fill" style="width: <?= $width ?>%"></div></div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="empty-state">Нет расходов за выбранный период.</div>
        <?php endif; ?>
      </div>
    </article>

    <article class="card">
      <div class="card-head"><h2>Динамика по дням</h2><span class="chip">Сумма в день</span></div>
      <div class="bars compact-bars">
        <?php if ($data['series']): ?>
          <?php $maxBar = max(array_map(static fn($row) => (float)$row['total'], $data['series'])); ?>
          <?php foreach ($data['series'] as $row): ?>
            <?php $width = $maxBar > 0 ? max(8, (int)round(((float)$row['total'] / $maxBar) * 100)) : 8; ?>
            <div class="bar-row">
              <div class="bar-head"><span><?= site_format_date((string)$row['d']) ?></span><strong><?= site_money($row['total']) ?></strong></div>
              <div class="bar-track"><div class="bar-fill alt" style="width: <?= $width ?>%"></div></div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="empty-state">Нет данных по дням.</div>
        <?php endif; ?>
      </div>
    </article>
  </section>

  <section class="table-card">
    <div class="card-head"><h2>Список расходов</h2><span class="chip">Последние сверху</span></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>Дата</th>
            <th>Категория</th>
            <th>Сумма</th>
            <th>Комментарий</th>
            <th>Телёнок</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($data['items'] as $item): ?>
            <tr>
              <td><?= site_format_dt((string)$item['tx_date']) ?></td>
              <td><?= site_e((string)$item['category']) ?></td>
              <td><?= site_money($item['amount']) ?></td>
              <td><?= site_e((string)$item['comment']) ?></td>
              <td><?= $item['calf_number'] ? '№' . (int)$item['calf_number'] : '—' ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$data['items']): ?>
            <tr><td colspan="5" class="empty-state">За выбранный период расходов нет.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
<?php endif; ?>
