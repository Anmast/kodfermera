<?php

declare(strict_types=1);

require __DIR__ . '/lib.php';
site_check_access();

$pdo = site_pdo();
$action = strtolower(trim((string)($_GET['action'] ?? $_POST['action'] ?? 'dashboard')));

function site_req_int(string $key, int $default, int $min, int $max): int
{
    $v = (int)($_GET[$key] ?? $_POST[$key] ?? $default);
    return max($min, min($max, $v));
}

function site_expense_category_sql(): string
{
    return "COALESCE(c.name, 'Без категории')";
}

function site_dashboard(PDO $pdo): void
{
    $days = site_req_int('days', 30, 1, 365);
    $counts = ['total' => 0, 'active' => 0, 'sold' => 0, 'dead' => 0, 'removed' => 0];

    $cattleSql = site_cattle_source_sql();
    $statusExpr = site_status_expr('c');

    try {
        $sql = "SELECT c.number, {$statusExpr} AS status FROM {$cattleSql} c ORDER BY c.number DESC";
        foreach ($pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $counts['total']++;
            $status = (string)($row['status'] ?? 'active');
            if (!array_key_exists($status, $counts)) {
                $status = 'active';
            }
            $counts[$status]++;
        }
    } catch (Throwable $e) {
        site_error('Не удалось получить статистику КРС', 500, ['details' => $e->getMessage()]);
    }

    $recent = [];
    try {
        $st = $pdo->prepare(
            "SELECT e.id, e.calf_number, e.type, e.value, e.created_at\n" .
            "FROM events e\n" .
            "WHERE e.calf_number IS NOT NULL\n" .
            "ORDER BY e.created_at DESC, e.id DESC\n" .
            "LIMIT 20"
        );
        $st->execute();
        $recent = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
    }

    $finance = [
        'installed' => site_ensure_finance_tables($pdo),
        'days' => $days,
        'total' => 0.0,
        'by_category' => [],
        'last' => [],
        'avg_daily' => 0.0,
    ];

    if ($finance['installed']) {
        try {
            $union = site_expense_union_sql($pdo, $days, null);

            $sqlCats = "SELECT x.category, ROUND(SUM(x.amount),2) AS total FROM (" . $union['sql'] . ") x GROUP BY x.category ORDER BY total DESC";
            $st = $pdo->prepare($sqlCats);
            $st->execute($union['args']);
            $finance['by_category'] = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($finance['by_category'] as $row) {
                $finance['total'] += (float)$row['total'];
            }
            $finance['total'] = round($finance['total'], 2);
            $finance['avg_daily'] = round($finance['total'] / max(1, $days), 2);

            $sqlLast = "SELECT x.id, x.tx_date, x.amount, x.comment, x.category FROM (" . $union['sql'] . ") x ORDER BY x.tx_date DESC, x.id DESC LIMIT 12";
            $st = $pdo->prepare($sqlLast);
            $st->execute($union['args']);
            $finance['last'] = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $e) {
        }
    }

    $signals = [];
    try {
        $sql = "SELECT\n" .
            "c.number,\n" .
            "(SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='temp' ORDER BY e.created_at DESC LIMIT 1) AS last_temp,\n" .
            "(SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='weight' ORDER BY e.created_at DESC LIMIT 1) AS last_weight,\n" .
            "(SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='weight' ORDER BY e.created_at DESC LIMIT 1,1) AS prev_weight\n" .
            "FROM {$cattleSql} c\n" .
            "ORDER BY c.number DESC LIMIT 200";
        foreach ($pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $n = (int)$row['number'];
            $temp = $row['last_temp'] !== null ? (float)$row['last_temp'] : null;
            $weight = $row['last_weight'] !== null ? (float)$row['last_weight'] : null;
            $prevWeight = $row['prev_weight'] !== null ? (float)$row['prev_weight'] : null;
            if ($temp !== null && $temp >= 39.8) {
                $signals[] = ['level' => $temp >= 40.0 ? 'critical' : 'warn', 'title' => 'Температура выше нормы', 'text' => 'Телёнок №' . $n . ' — ' . $temp . ' °C'];
            }
            if ($weight !== null && $prevWeight !== null && $weight < $prevWeight) {
                $signals[] = ['level' => 'warn', 'title' => 'Потеря веса', 'text' => 'Телёнок №' . $n . ' — было ' . $prevWeight . ' кг, стало ' . $weight . ' кг'];
            }
        }
    } catch (Throwable $e) {
    }

    site_json([
        'ok' => true,
        'counts' => $counts,
        'recent' => $recent,
        'finance' => $finance,
        'signals' => array_slice($signals, 0, 8),
    ]);
}

function site_cattle(PDO $pdo): void
{
    $q = trim((string)($_GET['q'] ?? ''));
    $status = trim((string)($_GET['status'] ?? 'all'));
    $sort = trim((string)($_GET['sort'] ?? 'number_desc'));

    $cattleSql = site_cattle_source_sql();
    $statusExpr = site_status_expr('c');

    $sql = "SELECT\n" .
        "c.number,\n" .
        "{$statusExpr} AS status,\n" .
        "(SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='weight' ORDER BY e.created_at DESC LIMIT 1) AS last_weight,\n" .
        "(SELECT e.created_at FROM events e WHERE e.calf_number=c.number AND e.type='weight' ORDER BY e.created_at DESC LIMIT 1) AS last_weight_at,\n" .
        "(SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='weight' ORDER BY e.created_at DESC LIMIT 1,1) AS prev_weight,\n" .
        "(SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='temp' ORDER BY e.created_at DESC LIMIT 1) AS last_temp,\n" .
        "(SELECT e.created_at FROM events e WHERE e.calf_number=c.number AND e.type='temp' ORDER BY e.created_at DESC LIMIT 1) AS last_temp_at,\n" .
        "(SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type IN ('birth','dob','born') ORDER BY e.created_at DESC LIMIT 1) AS birth,\n" .
        "(SELECT MIN(e.created_at) FROM events e WHERE e.calf_number=c.number) AS first_seen,\n" .
        "(SELECT MAX(e.created_at) FROM events e WHERE e.calf_number=c.number) AS last_seen,\n" .
        "(SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='note' ORDER BY e.created_at DESC LIMIT 1) AS note,\n" .
        "(SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='treatment' ORDER BY e.created_at DESC LIMIT 1) AS treatment,\n" .
        "(SELECT e.value FROM events e WHERE e.calf_number=c.number AND e.type='qr' ORDER BY e.created_at DESC LIMIT 1) AS qr\n" .
        "FROM {$cattleSql} c";

    $where = [];
    $args = [];
    if ($q !== '') {
        $digits = preg_replace('/\D+/', '', $q);
        if ($digits !== '') {
            $where[] = 'CAST(c.number AS CHAR) LIKE ?';
            $args[] = '%' . $digits . '%';
        }
    }
    if ($status !== '' && $status !== 'all') {
        $where[] = $statusExpr . ' = ?';
        $args[] = $status;
    }
    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY c.number DESC LIMIT 500';

    try {
        $st = $pdo->prepare($sql);
        $st->execute($args);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        site_error('Не удалось загрузить список КРС', 500, ['details' => $e->getMessage()]);
    }

    $today = new DateTimeImmutable('today');
    $items = [];
    foreach ($rows as $row) {
        $birth = site_parse_birth($row['birth'] ?? null, $row['first_seen'] ?? null);
        $ageDays = $birth ? (int)$birth->diff($today)->format('%a') : null;
        $lastWeight = $row['last_weight'] !== null ? (float)$row['last_weight'] : null;
        $prevWeight = $row['prev_weight'] !== null ? (float)$row['prev_weight'] : null;
        $items[] = [
            'number' => (int)$row['number'],
            'status' => (string)($row['status'] ?? 'active'),
            'last_weight' => $lastWeight,
            'weight_delta' => ($lastWeight !== null && $prevWeight !== null) ? round($lastWeight - $prevWeight, 2) : null,
            'last_weight_at' => $row['last_weight_at'],
            'last_temp' => $row['last_temp'] !== null ? (float)$row['last_temp'] : null,
            'last_temp_at' => $row['last_temp_at'],
            'age_days' => $ageDays,
            'birth' => $row['birth'],
            'last_seen' => $row['last_seen'],
            'note' => $row['note'],
            'treatment' => $row['treatment'],
            'qr' => $row['qr'],
        ];
    }

    usort($items, static function (array $a, array $b) use ($sort): int {
        return match ($sort) {
            'number_asc' => $a['number'] <=> $b['number'],
            'weight_desc' => ($b['last_weight'] ?? -INF) <=> ($a['last_weight'] ?? -INF),
            'weight_asc' => ($a['last_weight'] ?? INF) <=> ($b['last_weight'] ?? INF),
            'age_desc' => ($b['age_days'] ?? -INF) <=> ($a['age_days'] ?? -INF),
            'age_asc' => ($a['age_days'] ?? INF) <=> ($b['age_days'] ?? INF),
            default => $b['number'] <=> $a['number'],
        };
    });

    site_json(['ok' => true, 'items' => $items]);
}

function site_calf_detail(PDO $pdo): void
{
    $number = (int)($_GET['number'] ?? 0);
    if ($number <= 0) {
        site_error('bad_number', 400);
    }

    $st = $pdo->prepare(
        "SELECT id, type, value, created_at FROM events WHERE calf_number=? ORDER BY created_at DESC, id DESC LIMIT 50"
    );
    $st->execute([$number]);
    $events = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $st = $pdo->prepare("SELECT created_at, value FROM events WHERE calf_number=? AND type='weight' ORDER BY created_at ASC LIMIT 30");
    $st->execute([$number]);
    $weights = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $st = $pdo->prepare("SELECT created_at, value FROM events WHERE calf_number=? AND type='temp' ORDER BY created_at ASC LIMIT 30");
    $st->execute([$number]);
    $temps = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

    site_json(['ok' => true, 'events' => $events, 'weights' => $weights, 'temps' => $temps]);
}

function site_expenses(PDO $pdo): void
{
    $days = site_req_int('days', 90, 1, 365);
    $category = trim((string)($_GET['category'] ?? ''));

    if (!site_ensure_finance_tables($pdo)) {
        site_json(['ok' => true, 'installed' => false, 'total' => 0.0, 'items' => [], 'categories' => [], 'series' => []]);
    }

    $data = site_fetch_expenses($pdo, $days, $category !== '' ? $category : null);
    site_json([
        'ok' => true,
        'installed' => (bool)($data['installed'] ?? false),
        'total' => (float)($data['total'] ?? 0),
        'items' => $data['items'] ?? [],
        'categories' => $data['categories'] ?? [],
        'series' => $data['series'] ?? [],
    ]);
}

function site_admin_init(PDO $pdo): void
{
    $dashboard = [];
    ob_start();
    // We won't reuse dashboard JSON directly; just gather smaller chunks.
    $cattleSql = site_cattle_source_sql();
    $statusExpr = site_status_expr('c');

    $counts = ['total' => 0, 'active' => 0, 'sold' => 0, 'dead' => 0, 'removed' => 0];
    $sql = "SELECT c.number, {$statusExpr} AS status FROM {$cattleSql} c ORDER BY c.number DESC";
    foreach ($pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $counts['total']++;
        $status = (string)($row['status'] ?? 'active');
        if (!array_key_exists($status, $counts)) {
            $status = 'active';
        }
        $counts[$status]++;
    }

    $recentEvents = $pdo->query(
        "SELECT id, calf_number, type, value, created_at FROM events WHERE calf_number IS NOT NULL ORDER BY created_at DESC, id DESC LIMIT 20"
    )->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $recentExpenses = [];
    $categories = [];
    if (site_ensure_finance_tables($pdo)) {
        $recentExpenses = $pdo->query(
            "SELECT t.id, t.tx_date, ROUND(t.amount,2) AS amount, t.comment, t.calf_number, " . site_expense_category_sql() . " AS category\n" .
            "FROM finance_transactions t\n" .
            "LEFT JOIN finance_categories c ON c.id=t.category_id\n" .
            "WHERE t.type='expense'\n" .
            "ORDER BY t.tx_date DESC, t.id DESC\n" .
            "LIMIT 20"
        )->fetchAll(PDO::FETCH_ASSOC) ?: [];

        $categories = $pdo->query(
            "SELECT id, name FROM finance_categories WHERE type='expense' ORDER BY is_system DESC, name ASC"
        )->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    site_json([
        'ok' => true,
        'counts' => $counts,
        'finance_installed' => site_ensure_finance_tables($pdo),
        'recent_events' => $recentEvents,
        'recent_expenses' => $recentExpenses,
        'categories' => $categories,
    ]);
}

function site_admin_event_save(PDO $pdo): void
{
    $data = site_request_data();
    $eventId = site_post_int($data, 'event_id');
    $calfNumber = site_post_int($data, 'calf_number');
    $type = site_post_string($data, 'type');
    $value = site_post_string($data, 'value');
    $createdAt = site_validate_datetime(site_post_string($data, 'created_at'));

    if ($calfNumber <= 0 || $type === '' || $value === '') {
        site_error('Заполни номер, тип и значение.');
    }

    $allowed = ['weight', 'temp', 'treatment', 'note', 'birth', 'dob', 'born', 'life', 'qr'];
    if (!in_array($type, $allowed, true)) {
        site_error('Недопустимый тип записи.');
    }

    if ($eventId > 0) {
        $sql = "UPDATE events SET calf_number=?, type=?, value=?" . ($createdAt ? ', created_at=?' : '') . " WHERE id=?";
        $args = [$calfNumber, $type, $value];
        if ($createdAt) {
            $args[] = $createdAt;
        }
        $args[] = $eventId;
        $st = $pdo->prepare($sql);
        $st->execute($args);
    } else {
        $pdo->prepare("INSERT IGNORE INTO calves(number) VALUES (?)")->execute([$calfNumber]);
        if ($createdAt) {
            $st = $pdo->prepare("INSERT INTO events(calf_number, type, value, created_at) VALUES (?,?,?,?)");
            $st->execute([$calfNumber, $type, $value, $createdAt]);
        } else {
            $st = $pdo->prepare("INSERT INTO events(calf_number, type, value) VALUES (?,?,?)");
            $st->execute([$calfNumber, $type, $value]);
        }
        $eventId = (int)$pdo->lastInsertId();
    }

    site_json(['ok' => true, 'event_id' => $eventId, 'message' => 'Запись по КРС сохранена.']);
}

function site_admin_event_delete(PDO $pdo): void
{
    $data = site_request_data();
    $eventId = site_post_int($data, 'event_id');
    if ($eventId <= 0) {
        site_error('Не указан ID события.');
    }
    $st = $pdo->prepare("DELETE FROM events WHERE id=?");
    $st->execute([$eventId]);
    site_json(['ok' => true, 'message' => 'Событие удалено.']);
}

function site_admin_expense_save(PDO $pdo): void
{
    if (!site_ensure_finance_tables($pdo)) {
        site_error('Финансовые таблицы не установлены.', 400);
    }

    $data = site_request_data();
    $expenseId = site_post_int($data, 'expense_id');
    $txDate = site_validate_datetime(site_post_string($data, 'tx_date')) ?: date('Y-m-d H:i:s');
    $amount = site_post_float($data, 'amount');
    $comment = site_post_string($data, 'comment');
    $calfNumber = site_post_int($data, 'calf_number');
    $categoryId = site_post_int($data, 'category_id');
    $newCategory = site_post_string($data, 'new_category');

    if ($amount <= 0) {
        site_error('Укажи сумму расхода.');
    }

    if ($categoryId <= 0 && $newCategory === '') {
        site_error('Выбери категорию или введи новую.');
    }

    if ($categoryId <= 0 && $newCategory !== '') {
        $st = $pdo->prepare("SELECT id FROM finance_categories WHERE type='expense' AND name=? LIMIT 1");
        $st->execute([$newCategory]);
        $categoryId = (int)($st->fetchColumn() ?: 0);
        if ($categoryId <= 0) {
            $st = $pdo->prepare("INSERT INTO finance_categories(name, type, is_system) VALUES (?, 'expense', 0)");
            $st->execute([$newCategory]);
            $categoryId = (int)$pdo->lastInsertId();
        }
    }

    if ($expenseId > 0) {
        $st = $pdo->prepare(
            "UPDATE finance_transactions SET tx_date=?, category_id=?, amount=?, comment=?, calf_number=? WHERE id=? AND type='expense'"
        );
        $st->execute([$txDate, $categoryId, $amount, $comment !== '' ? $comment : null, $calfNumber > 0 ? $calfNumber : null, $expenseId]);
    } else {
        $st = $pdo->prepare(
            "INSERT INTO finance_transactions(tx_date, type, category_id, amount, comment, calf_number, created_by) VALUES (?, 'expense', ?, ?, ?, ?, 0)"
        );
        $st->execute([$txDate, $categoryId, $amount, $comment !== '' ? $comment : null, $calfNumber > 0 ? $calfNumber : null]);
        $expenseId = (int)$pdo->lastInsertId();
    }

    site_json(['ok' => true, 'expense_id' => $expenseId, 'message' => 'Расход сохранён.']);
}

function site_admin_expense_delete(PDO $pdo): void
{
    if (!site_ensure_finance_tables($pdo)) {
        site_error('Финансовые таблицы не установлены.', 400);
    }

    $data = site_request_data();
    $expenseId = site_post_int($data, 'expense_id');
    if ($expenseId <= 0) {
        site_error('Не указан ID расхода.');
    }
    $st = $pdo->prepare("DELETE FROM finance_transactions WHERE id=? AND type='expense'");
    $st->execute([$expenseId]);
    site_json(['ok' => true, 'message' => 'Расход удалён.']);
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        switch ($action) {
            case 'admin_event_save':
                site_admin_event_save($pdo);
                break;
            case 'admin_event_delete':
                site_admin_event_delete($pdo);
                break;
            case 'admin_expense_save':
                site_admin_expense_save($pdo);
                break;
            case 'admin_expense_delete':
                site_admin_expense_delete($pdo);
                break;
            default:
                site_error('unknown_action', 404);
        }
    }

    switch ($action) {
        case 'dashboard':
            site_dashboard($pdo);
            break;
        case 'cattle':
            site_cattle($pdo);
            break;
        case 'calf_detail':
            site_calf_detail($pdo);
            break;
        case 'expenses':
            site_expenses($pdo);
            break;
        case 'admin_init':
            site_admin_init($pdo);
            break;
        default:
            site_error('unknown_action', 404);
    }
} catch (Throwable $e) {
    site_error('server_error', 500, ['details' => $e->getMessage()]);
}
