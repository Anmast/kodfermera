<?php

declare(strict_types=1);

require __DIR__ . '/lib.php';
require __DIR__ . '/auth.php';

site_check_access();
site_admin_session_start();

$uriPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
if ($scriptDir !== '' && $scriptDir !== '/' && str_starts_with($uriPath, $scriptDir)) {
    $uriPath = substr($uriPath, strlen($scriptDir)) ?: '/';
}
$uriPath = '/' . ltrim($uriPath, '/');

if ($uriPath === '/admin/logout') {
    site_admin_logout();
    site_flash_set('ok', 'Выход выполнен.');
    header('Location: ' . site_url('/admin'));
    exit;
}

$routes = [
    '/' => ['file' => 'home.php', 'title' => 'Код Фермера — Главная', 'page' => 'home'],
    '/cattle' => ['file' => 'cattle.php', 'title' => 'Код Фермера — КРС', 'page' => 'cattle'],
    '/expenses' => ['file' => 'expenses.php', 'title' => 'Код Фермера — Расходы', 'page' => 'expenses'],
    '/admin' => ['file' => 'admin.php', 'title' => 'Код Фермера — Админка', 'page' => 'admin'],
];

$route = $routes[$uriPath] ?? ['file' => '404.php', 'title' => 'Страница не найдена', 'page' => '404'];
$title = $route['title'];
$pageId = $route['page'];
$key = site_current_key();
$bodyClass = 'page-' . $pageId;
$flash = site_flash_get();

require __DIR__ . '/partials/layout_start.php';
require __DIR__ . '/pages/' . $route['file'];
require __DIR__ . '/partials/layout_end.php';
