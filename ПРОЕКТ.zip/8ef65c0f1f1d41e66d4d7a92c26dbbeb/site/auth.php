<?php

declare(strict_types=1);

function site_admin_config(): array
{
    static $config = null;
    if (is_array($config)) {
        return $config;
    }
    $config = require __DIR__ . '/config/admin.php';
    return $config;
}

function site_admin_session_start(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('kodfermera_admin');
    session_start();
}

function site_admin_is_logged_in(): bool
{
    site_admin_session_start();
    $cfg = site_admin_config();
    return !empty($_SESSION[$cfg['session_key']]);
}

function site_admin_login(string $login, string $password): bool
{
    site_admin_session_start();
    $cfg = site_admin_config();
    $ok = hash_equals((string)$cfg['login'], trim($login)) && password_verify($password, (string)$cfg['password_hash']);
    if ($ok) {
        $_SESSION[$cfg['session_key']] = [
            'login' => $cfg['login'],
            'at' => time(),
        ];
    }
    return $ok;
}

function site_admin_logout(): void
{
    site_admin_session_start();
    $cfg = site_admin_config();
    unset($_SESSION[$cfg['session_key']], $_SESSION[$cfg['csrf_key']], $_SESSION['site_flash']);
}

function site_admin_csrf_token(): string
{
    site_admin_session_start();
    $cfg = site_admin_config();
    if (empty($_SESSION[$cfg['csrf_key']])) {
        $_SESSION[$cfg['csrf_key']] = bin2hex(random_bytes(16));
    }
    return (string)$_SESSION[$cfg['csrf_key']];
}

function site_admin_validate_csrf(?string $token): bool
{
    site_admin_session_start();
    $cfg = site_admin_config();
    $current = (string)($_SESSION[$cfg['csrf_key']] ?? '');
    return $current !== '' && is_string($token) && hash_equals($current, $token);
}

function site_flash_set(string $type, string $message): void
{
    site_admin_session_start();
    $_SESSION['site_flash'] = ['type' => $type, 'message' => $message];
}

function site_flash_get(): ?array
{
    site_admin_session_start();
    $flash = $_SESSION['site_flash'] ?? null;
    unset($_SESSION['site_flash']);
    return is_array($flash) ? $flash : null;
}
